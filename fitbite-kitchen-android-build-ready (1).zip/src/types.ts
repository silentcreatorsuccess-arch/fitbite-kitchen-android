export type CurrencyCode = 'PHP' | 'USD' | 'EUR' | 'GBP' | 'CAD' | 'AUD' | 'JPY' | 'SGD';

export type UnitSystem = 'metric' | 'us_customary';

export type BudgetTier = 'budget' | 'mid' | 'premium';

export type FitnessGoal = 
  | 'calorie_deficit'
  | 'omad'
  | 'new_to_balanced'
  | 'build_muscle'
  | 'general_healthy'
  // Backward compatibility aliases
  | 'weight_management'
  | 'high_protein'
  | 'muscle_building'
  | 'general_health';

export type SecondaryInterest = 
  | 'budget_friendly'
  | 'vegetarian'
  | 'weight_management'
  | 'high_protein'
  | 'quick_recipes';

export type CuisineType = 
  | 'filipino'
  | 'american'
  | 'mediterranean'
  | 'asian'
  | 'other';

export type IngredientCategory = 
  | 'produce'
  | 'meat_seafood'
  | 'pantry_grains'
  | 'dairy_alt'
  | 'seasoning_oil';

export interface Ingredient {
  id: string;
  name: string;
  category: IngredientCategory;
  // Standard metric values
  amountMetric: number;
  unitMetric: string; // 'g', 'ml', 'tbsp', 'tsp', 'pc', 'clove', 'cup'
  // US Customary display
  amountCustomary: number;
  unitCustomary: string; // 'oz', 'fl oz', 'cup', 'lb', 'tbsp', 'tsp', 'pc'
  // Base cost estimate in PHP
  estimatedCostPhp: number;
  substituteNote?: string;
}

export interface BudgetSwap {
  id: string;
  originalIngredient: string;
  swapIngredient: string;
  savingsPhpPerServing: number;
  reason: string;
  culinaryTip: string;
}

export interface Recipe {
  id: string;
  title: string;
  filipinoName?: string;
  description: string;
  cuisine: CuisineType;
  prepTimeMinutes: number;
  cookTimeMinutes: number;
  servings: number;
  difficulty: 'Beginner' | 'Intermediate';
  budgetTier: BudgetTier;
  fitnessGoals: FitnessGoal[];
  dietaryTags: ('High Protein' | 'Low Carb' | 'Budget Friendly' | 'Quick & Easy' | 'Gluten-Free' | 'Vegetarian' | 'High Fiber')[];
  // Per serving estimates
  calories: number;
  proteinGrams: number;
  carbsGrams: number;
  fatGrams: number;
  fiberGrams: number;
  baseCostPhp: number; // Estimated base cost per serving in PHP
  ingredients: Ingredient[];
  instructions: string[];
  swaps: BudgetSwap[];
  beginnerTip: string;
  imageEmoji: string;
  imageUrl?: string;
  imageAlt?: string;
  hasRealPhoto: boolean; // true if verified real food photograph; false if pending authentic photo
  photoCredit?: {
    photographer: string;
    source: string;
    sourceUrl: string;
  };
  accentColor: string;
  // Enhanced culinary guide features
  commonMistakes?: string[];
  servingSuggestions?: string;
  storageAdvice?: string;
  reheatingAdvice?: string;
}

export interface UserSettings {
  countryCode: string;
  countryName: string;
  currency: CurrencyCode;
  unitSystem: UnitSystem;
  dailyCalorieTarget: number;
  dailyWaterTargetMl: number;
  maxBudgetPerServing: number; // In user's selected currency
  dietaryPreference: 'all' | 'high_protein' | 'low_carb' | 'vegetarian' | 'pescatarian';
  activeFitnessGoal: FitnessGoal | 'all';
  primaryGoal?: FitnessGoal;
  secondaryInterests?: SecondaryInterest[];
  hasCompletedOnboarding: boolean;
  customIngredientPrices: Record<string, number>; // ingredientId -> custom price in PHP
  customRecipePhotos?: Record<string, string>; // recipeId -> dataUrl or custom photo URL
  enableCalorieTracker?: boolean;
  enableWaterTracker?: boolean;
}

export type MealType = 'breakfast' | 'lunch' | 'dinner' | 'snack';

export interface MealPlanItem {
  id: string;
  dayIndex: number; // 0 for Monday, 6 for Sunday (or day of week)
  mealType: MealType;
  recipeId: string;
  recipeTitle: string;
  servings: number;
  calories: number;
  costPhp: number;
}

export interface LoggedMealEntry {
  id: string;
  timestamp: string; // ISO string
  dateString: string; // YYYY-MM-DD
  mealType: MealType;
  foodName: string;
  servings: number;
  calories: number;
  proteinGrams: number;
  carbsGrams: number;
  fatGrams: number;
  recipeId?: string;
}

export interface WaterLogEntry {
  id: string;
  timestamp: string;
  amountMl: number;
}

export interface ShoppingListItem {
  id: string;
  name: string;
  category: IngredientCategory;
  quantityMetric: string;
  quantityCustomary: string;
  estimatedCostPhp: number;
  checked: boolean;
  fromRecipes: string[];
}
