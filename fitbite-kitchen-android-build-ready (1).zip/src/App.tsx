/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  UserSettings, 
  Recipe, 
  LoggedMealEntry, 
  WaterLogEntry, 
  MealPlanItem, 
  ShoppingListItem 
} from './types';
import { RECIPES } from './data/recipes';
import { 
  getStoredSettings, 
  saveStoredSettings, 
  getStoredLoggedMeals, 
  saveStoredLoggedMeals, 
  getStoredWaterLogs, 
  saveStoredWaterLogs, 
  getStoredMealPlan, 
  saveStoredMealPlan, 
  getStoredShoppingList, 
  saveStoredShoppingList,
  DEFAULT_SETTINGS 
} from './utils/storage';
import { Navbar } from './components/Navbar';
import { BottomNav } from './components/BottomNav';
import { OnboardingModal } from './components/OnboardingModal';
import { HomeView } from './components/HomeView';
import { RecipeListView } from './components/RecipeListView';
import { RecipeDetailModal } from './components/RecipeDetailModal';
import { MealPlannerView } from './components/MealPlannerView';
import { CalorieTrackerView } from './components/CalorieTrackerView';
import { WaterTrackerView } from './components/WaterTrackerView';
import { BudgetSwapsView } from './components/BudgetSwapsView';
import { CookingTipsView } from './components/CookingTipsView';
import { SettingsView } from './components/SettingsView';
import { CheckCircle2 } from 'lucide-react';

export default function App() {
  const [settings, setSettings] = useState<UserSettings>(() => getStoredSettings());
  const [recipes, setRecipes] = useState<Recipe[]>(RECIPES);
  const [loggedMeals, setLoggedMeals] = useState<LoggedMealEntry[]>(() => getStoredLoggedMeals());
  const [waterLogs, setWaterLogs] = useState<WaterLogEntry[]>(() => getStoredWaterLogs());
  const [mealPlan, setMealPlan] = useState<MealPlanItem[]>(() => getStoredMealPlan());
  const [shoppingList, setShoppingList] = useState<ShoppingListItem[]>(() => getStoredShoppingList());

  const [activeTab, setActiveTab] = useState<string>('home');
  const [selectedRecipe, setSelectedRecipe] = useState<Recipe | null>(null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Sync to local storage
  useEffect(() => {
    saveStoredSettings(settings);
  }, [settings]);

  useEffect(() => {
    saveStoredLoggedMeals(loggedMeals);
  }, [loggedMeals]);

  useEffect(() => {
    saveStoredWaterLogs(waterLogs);
  }, [waterLogs]);

  useEffect(() => {
    saveStoredMealPlan(mealPlan);
  }, [mealPlan]);

  useEffect(() => {
    saveStoredShoppingList(shoppingList);
  }, [shoppingList]);

  const showToast = (message: string) => {
    setToastMessage(message);
    setTimeout(() => {
      setToastMessage(null);
    }, 2800);
  };

  // Setting updates
  const handleUpdateSettings = (partial: Partial<UserSettings>) => {
    setSettings(prev => ({ ...prev, ...partial }));
  };

  // Onboarding completion
  const handleCompleteOnboarding = (updated: Partial<UserSettings>) => {
    setSettings(prev => ({
      ...prev,
      ...updated,
      hasCompletedOnboarding: true
    }));
    showToast(`Welcome! Settings set to ${updated.countryName || 'your region'}`);
  };

  // Reset all data
  const handleResetAllData = () => {
    localStorage.clear();
    setSettings(DEFAULT_SETTINGS);
    setLoggedMeals([]);
    setWaterLogs([]);
    setMealPlan([]);
    setShoppingList([]);
    showToast('All local app data has been reset');
  };

  // Recipe Ingredient Price Customization
  const handleUpdateIngredientPrice = (ingredientId: string, newPricePhp: number) => {
    setSettings(prev => ({
      ...prev,
      customIngredientPrices: {
        ...prev.customIngredientPrices,
        [ingredientId]: newPricePhp
      }
    }));
    showToast('Custom ingredient price saved locally!');
  };

  // Water Tracker Actions
  const handleAddWater = (amountMl: number) => {
    const newEntry: WaterLogEntry = {
      id: `w-${Date.now()}`,
      timestamp: new Date().toISOString(),
      amountMl
    };
    setWaterLogs(prev => [...prev, newEntry]);
    showToast(`Added ${amountMl} mL of water!`);
  };

  const handleDeleteWaterEntry = (id: string) => {
    setWaterLogs(prev => prev.filter(w => w.id !== id));
    showToast('Water entry removed');
  };

  const handleUndoLastWater = () => {
    if (waterLogs.length === 0) return;
    const lastItem = waterLogs[waterLogs.length - 1];
    setWaterLogs(prev => prev.slice(0, prev.length - 1));
    showToast(`Removed last ${lastItem.amountMl} mL`);
  };

  const handleResetTodayWater = () => {
    setWaterLogs([]);
    showToast('Today\'s water log reset');
  };

  const handleUpdateWaterGoal = (newGoalMl: number) => {
    setSettings(prev => ({ ...prev, dailyWaterTargetMl: newGoalMl }));
    showToast(`Daily water goal updated to ${newGoalMl} mL`);
  };

  // Calorie Tracker Actions
  const handleAddMealEntry = (entry: Omit<LoggedMealEntry, 'id'>) => {
    const newMeal: LoggedMealEntry = {
      ...entry,
      id: `meal-${Date.now()}`
    };
    setLoggedMeals(prev => [...prev, newMeal]);
    showToast(`Logged "${entry.foodName}" (${entry.calories} kcal)`);
  };

  const handleUpdateMealEntry = (id: string, updated: Partial<LoggedMealEntry>) => {
    setLoggedMeals(prev => prev.map(m => m.id === id ? { ...m, ...updated } : m));
    showToast('Meal entry updated');
  };

  const handleDeleteMealEntry = (id: string) => {
    setLoggedMeals(prev => prev.filter(m => m.id !== id));
    showToast('Meal entry deleted');
  };

  const handleUpdateDailyCalorieTarget = (newTargetKcal: number) => {
    setSettings(prev => ({ ...prev, dailyCalorieTarget: newTargetKcal }));
    showToast(`Daily calorie target updated to ${newTargetKcal} kcal`);
  };

  // Meal Planner Actions
  const handleAddMealToPlan = (item: Omit<MealPlanItem, 'id'>) => {
    const newItem: MealPlanItem = {
      ...item,
      id: `plan-${Date.now()}`
    };
    setMealPlan(prev => [...prev, newItem]);
    showToast(`Added "${item.recipeTitle}" to meal plan!`);
  };

  const handleRemoveMealFromPlan = (id: string) => {
    setMealPlan(prev => prev.filter(p => p.id !== id));
    showToast('Removed meal from planner');
  };

  const handleUpdateShoppingList = (items: ShoppingListItem[]) => {
    setShoppingList(items);
  };

  // Log Recipe directly from Recipe Detail or Card
  const handleLogRecipeAsMeal = (recipe: Recipe, servings: number) => {
    const scale = servings / recipe.servings;
    const currentHour = new Date().getHours();
    const mealType = currentHour < 11 ? 'breakfast' : currentHour < 16 ? 'lunch' : 'dinner';

    handleAddMealEntry({
      timestamp: new Date().toISOString(),
      dateString: new Date().toISOString().split('T')[0],
      mealType,
      foodName: recipe.title,
      servings,
      calories: Math.round(recipe.calories * scale),
      proteinGrams: Math.round(recipe.proteinGrams * scale),
      carbsGrams: Math.round(recipe.carbsGrams * scale),
      fatGrams: Math.round(recipe.fatGrams * scale),
      recipeId: recipe.id
    });
  };

  const handleAddRecipeToShoppingList = (recipe: Recipe, servings: number) => {
    const scale = servings / recipe.servings;
    const newItems: ShoppingListItem[] = recipe.ingredients.map((ing, idx) => {
      const customPhp = settings.customIngredientPrices[ing.id];
      const baseCost = customPhp !== undefined ? customPhp : ing.estimatedCostPhp;
      const scaledCost = (baseCost / recipe.servings) * servings;

      return {
        id: `shop-recipe-${recipe.id}-${idx}-${Date.now()}`,
        name: ing.name,
        category: ing.category,
        quantityMetric: `${Math.round(ing.amountMetric * scale * 10) / 10} ${ing.unitMetric}`,
        quantityCustomary: `${Math.round(ing.amountCustomary * scale * 10) / 10} ${ing.unitCustomary}`,
        estimatedCostPhp: Math.round(scaledCost),
        checked: false,
        fromRecipes: [recipe.title]
      };
    });

    setShoppingList(prev => [...prev, ...newItems]);
    showToast(`Added ${recipe.ingredients.length} items from "${recipe.title}" to Grocery List!`);
  };

  const handleAddRecipeToPlanFromModal = (recipe: Recipe, servings: number) => {
    const todayIndex = (new Date().getDay() + 6) % 7;
    const currentHour = new Date().getHours();
    const mealType = currentHour < 11 ? 'breakfast' : currentHour < 16 ? 'lunch' : 'dinner';

    handleAddMealToPlan({
      dayIndex: todayIndex,
      mealType,
      recipeId: recipe.id,
      recipeTitle: recipe.title,
      servings,
      calories: Math.round((recipe.calories / recipe.servings) * servings),
      costPhp: Math.round((recipe.baseCostPhp / recipe.servings) * servings)
    });
  };

  return (
    <div className="min-h-screen bg-[#FAF7F2] text-[#15241C] flex flex-col font-sans selection:bg-[#113826] selection:text-white pb-24 lg:pb-12">
      {/* Top Bar Navigation */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        settings={settings}
      />

      {/* Main Content Viewport */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8">
        {activeTab === 'home' && (
          <HomeView
            settings={settings}
            recipes={recipes}
            loggedMeals={loggedMeals}
            waterLogs={waterLogs}
            mealPlan={mealPlan}
            onSelectRecipe={(r) => setSelectedRecipe(r)}
            onNavigateTab={(tab) => setActiveTab(tab)}
            onQuickAddWater={handleAddWater}
            onQuickLogMeal={(r) => handleLogRecipeAsMeal(r, 1)}
          />
        )}

        {activeTab === 'recipes' && (
          <RecipeListView
            recipes={recipes}
            settings={settings}
            onSelectRecipe={(r) => setSelectedRecipe(r)}
            onQuickAddToPlan={(r) => handleAddRecipeToPlanFromModal(r, 1)}
            onQuickLogMeal={(r) => handleLogRecipeAsMeal(r, 1)}
          />
        )}

        {activeTab === 'planner' && (
          <MealPlannerView
            recipes={recipes}
            settings={settings}
            mealPlan={mealPlan}
            shoppingList={shoppingList}
            onAddMealToPlan={handleAddMealToPlan}
            onRemoveMealFromPlan={handleRemoveMealFromPlan}
            onUpdateShoppingList={handleUpdateShoppingList}
            onSelectRecipe={(r) => setSelectedRecipe(r)}
          />
        )}

        {activeTab === 'tracker' && (
          <CalorieTrackerView
            settings={settings}
            loggedMeals={loggedMeals}
            recipes={recipes}
            onAddMealEntry={handleAddMealEntry}
            onUpdateMealEntry={handleUpdateMealEntry}
            onDeleteMealEntry={handleDeleteMealEntry}
            onUpdateDailyTarget={handleUpdateDailyCalorieTarget}
          />
        )}

        {activeTab === 'water' && (
          <WaterTrackerView
            settings={settings}
            waterLogs={waterLogs}
            onAddWater={handleAddWater}
            onDeleteWaterEntry={handleDeleteWaterEntry}
            onUndoLastWater={handleUndoLastWater}
            onResetTodayWater={handleResetTodayWater}
            onUpdateWaterGoal={handleUpdateWaterGoal}
          />
        )}

        {activeTab === 'swaps' && (
          <BudgetSwapsView
            settings={settings}
          />
        )}

        {activeTab === 'tips' && (
          <CookingTipsView
            onExploreRecipes={() => setActiveTab('recipes')}
          />
        )}

        {activeTab === 'settings' && (
          <SettingsView
            settings={settings}
            onUpdateSettings={handleUpdateSettings}
            onResetAllData={handleResetAllData}
          />
        )}
      </main>

      {/* Recipe Detail Modal */}
      {selectedRecipe && (
        <RecipeDetailModal
          recipe={selectedRecipe}
          settings={settings}
          onClose={() => setSelectedRecipe(null)}
          onAddToPlan={(r, s) => {
            handleAddRecipeToPlanFromModal(r, s);
            setSelectedRecipe(null);
          }}
          onLogMeal={(r, s) => {
            handleLogRecipeAsMeal(r, s);
            setSelectedRecipe(null);
          }}
          onAddToShoppingList={(r, s) => {
            handleAddRecipeToShoppingList(r, s);
          }}
          onUpdateIngredientPrice={handleUpdateIngredientPrice}
        />
      )}

      {/* Onboarding Modal on First Launch */}
      {!settings.hasCompletedOnboarding && (
        <OnboardingModal
          currentSettings={settings}
          onComplete={handleCompleteOnboarding}
        />
      )}

      {/* Mobile Bottom Navigation Bar */}
      <BottomNav
        activeTab={activeTab}
        setActiveTab={setActiveTab}
      />

      {/* Ephemeral Feedback Toast */}
      {toastMessage && (
        <div className="fixed bottom-20 lg:bottom-6 left-1/2 -translate-x-1/2 z-50 bg-[#113826] text-white px-4 py-2.5 rounded-2xl shadow-xl flex items-center gap-2 text-xs font-semibold animate-fadeIn border border-[#245D3B]">
          <CheckCircle2 className="w-4 h-4 text-[#A3E635]" />
          <span>{toastMessage}</span>
        </div>
      )}
    </div>
  );
}
