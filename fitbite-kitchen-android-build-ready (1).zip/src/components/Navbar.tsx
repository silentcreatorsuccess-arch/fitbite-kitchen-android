import React from 'react';
import { UserSettings } from '../types';
import { SUPPORTED_REGIONS } from '../data/regions';
import { Settings as SettingsIcon, Utensils } from 'lucide-react';

interface NavbarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  settings: UserSettings;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  settings
}) => {
  const currentRegion = SUPPORTED_REGIONS.find(r => r.code === settings.countryCode) || SUPPORTED_REGIONS[0];

  const navLinks = [
    { id: 'home', label: 'Home' },
    { id: 'recipes', label: 'Recipe Library' },
    { id: 'planner', label: 'Meal Planner' },
    { id: 'tracker', label: 'Calorie Tracker' },
    { id: 'water', label: 'Hydration' },
    { id: 'tips', label: 'Cooking Tips' },
    { id: 'swaps', label: 'Budget Swaps' }
  ];

  return (
    <header className="sticky top-0 z-30 bg-[#FAF7F2]/95 backdrop-blur-md border-b border-[#EBE5D8] px-4 sm:px-8 py-3 transition-colors shadow-2xs">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-6">
        {/* Brand identity */}
        <button
          type="button"
          onClick={() => setActiveTab('home')}
          className="flex items-center gap-2.5 text-left focus:outline-none group cursor-pointer"
        >
          <div className="w-8 h-8 rounded-xl bg-[#113826] text-[#A3E635] flex items-center justify-center shadow-xs group-hover:scale-105 transition-transform">
            <Utensils className="w-4 h-4 stroke-[2.2]" />
          </div>
          <div>
            <span className="text-lg font-extrabold tracking-tight text-[#113826] block leading-none">
              FitBite Kitchen
            </span>
            <span className="text-[10px] font-semibold text-[#65A30D] tracking-wide uppercase">
              Eat Well · Cook Smart
            </span>
          </div>
        </button>

        {/* Navigation links */}
        <nav className="hidden lg:flex items-center gap-1.5 text-xs font-semibold text-[#526458]">
          {navLinks.map((link) => {
            const isActive = activeTab === link.id;
            return (
              <button
                key={link.id}
                type="button"
                onClick={() => setActiveTab(link.id)}
                className={`relative px-3.5 py-2 rounded-xl transition-all whitespace-nowrap cursor-pointer flex items-center gap-1.5 ${
                  isActive
                    ? 'bg-[#113826] text-white shadow-xs font-bold'
                    : 'text-[#45584D] hover:text-[#113826] hover:bg-[#EFE8DC]'
                }`}
              >
                {isActive && (
                  <span className="w-1.5 h-1.5 rounded-full bg-[#A3E635] animate-pulse" />
                )}
                <span>{link.label}</span>
              </button>
            );
          })}
        </nav>

        {/* Region & Settings Button */}
        <div className="flex items-center gap-2.5 shrink-0">
          <button
            type="button"
            onClick={() => setActiveTab('settings')}
            title="Configure Region, Currency, & Nutrition Targets"
            className={`flex items-center gap-2 px-3 py-1.5 text-xs font-bold rounded-xl border transition-all whitespace-nowrap shrink-0 shadow-2xs cursor-pointer active:scale-95 ${
              activeTab === 'settings'
                ? 'bg-[#113826] text-white border-[#113826]'
                : 'bg-white text-[#15241C] border-[#DDD5C7] hover:border-[#113826]/40 hover:bg-[#F8F5EE]'
            }`}
          >
            <span className="text-sm" aria-hidden="true">{currentRegion.flag}</span>
            <span className="font-mono font-bold text-[#113826]">{settings.currency}</span>
            <SettingsIcon className="w-3.5 h-3.5 opacity-70" />
          </button>
        </div>
      </div>
    </header>
  );
};
