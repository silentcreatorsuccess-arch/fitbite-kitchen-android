import React, { useState } from 'react';
import { UserSettings, WaterLogEntry } from '../types';
import { formatWaterAmount } from '../utils/units';
import { Droplets, Plus, Undo2, RotateCcw, Trash2, Edit2, Check, Sparkles } from 'lucide-react';

interface WaterTrackerViewProps {
  settings: UserSettings;
  waterLogs: WaterLogEntry[];
  onAddWater: (amountMl: number) => void;
  onDeleteWaterEntry: (id: string) => void;
  onUndoLastWater: () => void;
  onResetTodayWater: () => void;
  onUpdateWaterGoal: (newGoalMl: number) => void;
}

export const WaterTrackerView: React.FC<WaterTrackerViewProps> = ({
  settings,
  waterLogs,
  onAddWater,
  onDeleteWaterEntry,
  onUndoLastWater,
  onResetTodayWater,
  onUpdateWaterGoal
}) => {
  const [customInput, setCustomInput] = useState('250');
  const [isEditingGoal, setIsEditingGoal] = useState(false);
  const [goalInput, setGoalInput] = useState(settings.dailyWaterTargetMl.toString());

  const totalMl = waterLogs.reduce((acc, entry) => acc + entry.amountMl, 0);
  const percentage = Math.min(100, Math.round((totalMl / settings.dailyWaterTargetMl) * 100));
  const remainingMl = Math.max(0, settings.dailyWaterTargetMl - totalMl);

  const handleCustomAdd = (e: React.FormEvent) => {
    e.preventDefault();
    const val = parseFloat(customInput);
    if (!isNaN(val) && val > 0) {
      // If user is in US customary, convert fl oz to mL
      const ml = settings.unitSystem === 'us_customary' ? Math.round(val * 29.5735) : Math.round(val);
      onAddWater(ml);
      setCustomInput('250');
    }
  };

  const handleSaveGoal = () => {
    const parsed = parseInt(goalInput, 10);
    if (!isNaN(parsed) && parsed >= 500 && parsed <= 8000) {
      onUpdateWaterGoal(parsed);
      setIsEditingGoal(false);
    }
  };

  const quickButtons = [
    { ml: 150, label: 'Cup (150 mL)', flOz: '5 fl oz' },
    { ml: 250, label: 'Glass (250 mL)', flOz: '8.5 fl oz' },
    { ml: 350, label: 'Mug (350 mL)', flOz: '12 fl oz' },
    { ml: 500, label: 'Bottle (500 mL)', flOz: '17 fl oz' }
  ];

  return (
    <div className="space-y-6 animate-fadeIn max-w-4xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-[#192A20] tracking-tight">
            Daily Water Tracker
          </h1>
          <p className="text-xs sm:text-sm text-[#586A5F] mt-0.5">
            Maintain optimal digestion and energy by staying consistently hydrated throughout the day.
          </p>
        </div>

        {/* Goal Edit */}
        <div>
          {isEditingGoal ? (
            <div className="flex items-center gap-1.5 bg-white border border-[#113826] rounded-xl p-1 shadow-2xs">
              <input
                type="number"
                value={goalInput}
                onChange={(e) => setGoalInput(e.target.value)}
                className="w-24 px-2 py-1 text-xs font-mono font-bold text-[#113826] focus:outline-none"
              />
              <span className="text-xs text-[#586A5F] pr-1">mL</span>
              <button
                type="button"
                onClick={handleSaveGoal}
                className="p-1.5 bg-[#113826] text-white rounded-lg hover:bg-[#1A4E37]"
              >
                <Check className="w-3.5 h-3.5" />
              </button>
            </div>
          ) : (
            <button
              type="button"
              onClick={() => setIsEditingGoal(true)}
              className="flex items-center gap-2 px-3 py-1.5 text-xs font-medium rounded-xl bg-white border border-[#DDD5C7] text-[#192A20] hover:bg-[#F2ECE1] transition-colors shadow-2xs"
            >
              <span>Daily Goal: <strong>{formatWaterAmount(settings.dailyWaterTargetMl, settings.unitSystem)}</strong></span>
              <Edit2 className="w-3 h-3 text-[#586A5F]" />
            </button>
          )}
        </div>
      </div>

      {/* Main Hydration Gauge Card */}
      <div className="bg-white border border-[#E8E2D5] rounded-3xl p-6 sm:p-8 shadow-xs text-center relative overflow-hidden">
        <div className="max-w-md mx-auto">
          {/* Animated Water Bubble Visual */}
          <div className="w-40 h-40 sm:w-48 sm:h-48 mx-auto relative rounded-full border-4 border-[#2B7A78]/20 flex flex-col items-center justify-center p-4 bg-[#F2F8F8] shadow-inner mb-4 overflow-hidden">
            {/* Water Fill Level */}
            <div
              className="absolute bottom-0 left-0 right-0 bg-[#2B7A78]/25 transition-all duration-700 ease-out"
              style={{ height: `${percentage}%` }}
            />

            <div className="relative z-10">
              <Droplets className="w-8 h-8 text-[#2B7A78] mx-auto mb-1 animate-pulse" />
              <span className="text-3xl sm:text-4xl font-extrabold text-[#192A20] font-mono tabular-nums block">
                {formatWaterAmount(totalMl, settings.unitSystem)}
              </span>
              <span className="text-xs font-semibold text-[#52706B] font-mono block mt-0.5">
                {percentage}% of daily goal
              </span>
            </div>
          </div>

          <p className="text-xs text-[#526458] mb-6">
            {remainingMl > 0 ? (
              <span>
                You need <strong>{formatWaterAmount(remainingMl, settings.unitSystem)}</strong> more to reach today’s target.
              </span>
            ) : (
              <span className="text-[#113826] font-bold">
                🎉 Congratulations! You have met your hydration goal for today!
              </span>
            )}
          </p>

          {/* Quick Log Buttons Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 mb-6">
            {quickButtons.map((btn) => (
              <button
                key={btn.ml}
                type="button"
                onClick={() => onAddWater(btn.ml)}
                className="p-3 rounded-2xl bg-[#F4F9F8] border border-[#CFE4E1] hover:border-[#2B7A78] hover:bg-[#E5F3F1] transition-all flex flex-col items-center justify-center text-center group active:scale-95"
              >
                <Plus className="w-4 h-4 text-[#2B7A78] mb-1 group-hover:scale-110 transition-transform" />
                <span className="text-xs font-bold text-[#192A20]">
                  +{settings.unitSystem === 'metric' ? `${btn.ml} mL` : btn.flOz}
                </span>
                <span className="text-[10px] text-[#5C7571] mt-0.5">
                  {btn.label.split(' ')[0]}
                </span>
              </button>
            ))}
          </div>

          {/* Custom Amount Form */}
          <form onSubmit={handleCustomAdd} className="flex items-center gap-2 max-w-xs mx-auto mb-6">
            <input
              type="number"
              min="10"
              max="2000"
              value={customInput}
              onChange={(e) => setCustomInput(e.target.value)}
              placeholder="Amount"
              className="w-full px-3 py-2 bg-white border border-[#DDD5C7] rounded-xl text-xs font-mono text-[#192A20] focus:ring-1 focus:ring-[#2B7A78]"
            />
            <span className="text-xs font-semibold text-[#586A5F] shrink-0">
              {settings.unitSystem === 'metric' ? 'mL' : 'fl oz'}
            </span>
            <button
              type="submit"
              className="px-4 py-2 text-xs font-semibold rounded-xl bg-[#2B7A78] hover:bg-[#205C5B] text-white shrink-0 transition-colors"
            >
              Add
            </button>
          </form>

          {/* Undo and Correction Actions */}
          <div className="flex items-center justify-center gap-3 pt-4 border-t border-[#F2ECE1]">
            <button
              type="button"
              onClick={onUndoLastWater}
              disabled={waterLogs.length === 0}
              className="px-3.5 py-1.5 text-xs font-medium rounded-xl border border-[#DDD5C7] text-[#586A5F] hover:bg-[#F2ECE1] disabled:opacity-40 transition-colors flex items-center gap-1.5"
            >
              <Undo2 className="w-3.5 h-3.5" />
              <span>Undo Last Drink</span>
            </button>

            <button
              type="button"
              onClick={onResetTodayWater}
              disabled={waterLogs.length === 0}
              className="px-3.5 py-1.5 text-xs font-medium rounded-xl border border-[#DDD5C7] text-[#8C9C92] hover:text-[#B83828] hover:bg-[#FDECEB] disabled:opacity-40 transition-colors flex items-center gap-1.5"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Reset Today</span>
            </button>
          </div>
        </div>
      </div>

      {/* Today's Water Log History */}
      <div className="bg-white border border-[#E8E2D5] rounded-2xl overflow-hidden shadow-xs">
        <div className="bg-[#FAF7F0] px-4 py-3 border-b border-[#E8E2D5] flex items-center justify-between">
          <h3 className="text-xs font-bold text-[#192A20] uppercase tracking-wider">
            Today's Hydration Entries ({waterLogs.length})
          </h3>
          <span className="text-xs font-mono font-bold text-[#2B7A78]">
            Total: {formatWaterAmount(totalMl, settings.unitSystem)}
          </span>
        </div>

        {waterLogs.length === 0 ? (
          <div className="py-6 text-center text-xs text-[#8C9C92]">
            No water logged yet today. Tap any button above to track your first glass!
          </div>
        ) : (
          <div className="divide-y divide-[#F2ECE1]">
            {waterLogs.slice().reverse().map((entry) => {
              const timeFormatted = new Date(entry.timestamp).toLocaleTimeString([], {
                hour: '2-digit',
                minute: '2-digit'
              });

              return (
                <div
                  key={entry.id}
                  className="p-3 sm:px-4 flex items-center justify-between gap-3 text-xs"
                >
                  <div className="flex items-center gap-3">
                    <Droplets className="w-4 h-4 text-[#2B7A78]" />
                    <span className="font-mono text-[#586A5F]">{timeFormatted}</span>
                    <span className="font-bold text-[#192A20]">
                      {formatWaterAmount(entry.amountMl, settings.unitSystem)}
                    </span>
                  </div>

                  <button
                    type="button"
                    onClick={() => onDeleteWaterEntry(entry.id)}
                    className="p-1 text-[#8C9C92] hover:text-[#B83828] rounded-lg transition-colors"
                    title="Delete log"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
