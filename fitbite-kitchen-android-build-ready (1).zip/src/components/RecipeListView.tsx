import React, { useState, useMemo } from 'react';
import { Recipe, UserSettings, CuisineType, BudgetTier, FitnessGoal } from '../types';
import { RecipeCard } from './RecipeCard';
import { formatRawCurrency, convertPhpToCurrency } from '../utils/currency';
import { Search, SlidersHorizontal, RotateCcw, Filter, Clock, Flame, Dumbbell } from 'lucide-react';

interface RecipeListViewProps {
  recipes: Recipe[];
  settings: UserSettings;
  onSelectRecipe: (recipe: Recipe) => void;
  onQuickAddToPlan: (recipe: Recipe) => void;
  onQuickLogMeal: (recipe: Recipe) => void;
}

export const RecipeListView: React.FC<RecipeListViewProps> = ({
  recipes,
  settings,
  onSelectRecipe,
  onQuickAddToPlan,
  onQuickLogMeal
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCuisine, setSelectedCuisine] = useState<CuisineType | 'all'>('all');
  const [selectedBudgetTier, setSelectedBudgetTier] = useState<BudgetTier | 'all'>('all');
  const [selectedFitnessGoal, setSelectedFitnessGoal] = useState<FitnessGoal | 'all'>(
    settings.activeFitnessGoal || 'all'
  );
  const [selectedDietary, setSelectedDietary] = useState<string>('all');
  const [maxCookingTime, setMaxCookingTime] = useState<number>(60);
  const [minProtein, setMinProtein] = useState<number>(0);
  const [maxCalories, setMaxCalories] = useState<number>(1000);
  
  // Custom max food budget per serving slider in user's currency
  const maxBenchmarkInUserCurrency = Math.ceil(convertPhpToCurrency(300, settings.currency));
  const [maxBudgetCap, setMaxBudgetCap] = useState<number>(settings.maxBudgetPerServing || maxBenchmarkInUserCurrency);
  const [showAdvancedFilters, setShowAdvancedFilters] = useState(false);

  const filteredRecipes = useMemo(() => {
    return recipes.filter((recipe) => {
      // 1. Search Query (recipe title, filipino name, ingredient names, description)
      if (searchQuery.trim()) {
        const query = searchQuery.toLowerCase();
        const matchesTitle = recipe.title.toLowerCase().includes(query);
        const matchesFilipino = recipe.filipinoName?.toLowerCase().includes(query);
        const matchesDesc = recipe.description.toLowerCase().includes(query);
        const matchesIngredient = recipe.ingredients.some(i => i.name.toLowerCase().includes(query));
        if (!matchesTitle && !matchesFilipino && !matchesDesc && !matchesIngredient) {
          return false;
        }
      }

      // 2. Cuisine
      if (selectedCuisine !== 'all' && recipe.cuisine !== selectedCuisine) {
        return false;
      }

      // 3. Budget Tier
      if (selectedBudgetTier !== 'all' && recipe.budgetTier !== selectedBudgetTier) {
        return false;
      }

      // 4. Fitness Goal
      if (selectedFitnessGoal !== 'all') {
        // Match exact goal or legacy alias
        const matches = recipe.fitnessGoals.includes(selectedFitnessGoal);
        if (!matches) return false;
      }

      // 5. Dietary Tag
      if (selectedDietary !== 'all') {
        const hasTag = recipe.dietaryTags.some(t => t.toLowerCase() === selectedDietary.toLowerCase());
        if (!hasTag) return false;
      }

      // 6. Max Cooking Time
      const totalTime = recipe.prepTimeMinutes + recipe.cookTimeMinutes;
      if (totalTime > maxCookingTime) {
        return false;
      }

      // 7. Min Protein
      if (recipe.proteinGrams < minProtein) {
        return false;
      }

      // 8. Max Calories
      if (recipe.calories > maxCalories) {
        return false;
      }

      // 9. Custom Max Food Budget Per Serving
      const recipeCostInUserCurrency = convertPhpToCurrency(recipe.baseCostPhp, settings.currency);
      if (recipeCostInUserCurrency > maxBudgetCap) {
        return false;
      }

      return true;
    });
  }, [
    recipes, 
    searchQuery, 
    selectedCuisine, 
    selectedBudgetTier, 
    selectedFitnessGoal, 
    selectedDietary,
    maxCookingTime,
    minProtein,
    maxCalories,
    maxBudgetCap, 
    settings.currency
  ]);

  const resetFilters = () => {
    setSearchQuery('');
    setSelectedCuisine('all');
    setSelectedBudgetTier('all');
    setSelectedFitnessGoal('all');
    setSelectedDietary('all');
    setMaxCookingTime(60);
    setMinProtein(0);
    setMaxCalories(1000);
    setMaxBudgetCap(maxBenchmarkInUserCurrency);
  };

  const fitnessGoalButtons: { id: FitnessGoal | 'all'; label: string }[] = [
    { id: 'all', label: 'All Goals' },
    { id: 'calorie_deficit', label: 'Calorie Deficit' },
    { id: 'omad', label: 'OMAD' },
    { id: 'new_to_balanced', label: 'New to Balanced' },
    { id: 'build_muscle', label: 'Build Muscle' },
    { id: 'general_healthy', label: 'General Healthy' }
  ];

  const activeFiltersCount = [
    selectedCuisine !== 'all',
    selectedBudgetTier !== 'all',
    selectedFitnessGoal !== 'all',
    selectedDietary !== 'all',
    maxCookingTime < 60,
    minProtein > 0,
    maxCalories < 1000,
    maxBudgetCap < maxBenchmarkInUserCurrency
  ].filter(Boolean).length;

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Header & Search */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-[#192A20] tracking-tight">
            Recipe Library
          </h1>
          <p className="text-xs sm:text-sm text-[#586A5F] mt-0.5">
            {recipes.length} wholesome recipes featuring delicious Filipino staples & global favorites.
          </p>
        </div>

        {/* Search Bar */}
        <div className="relative max-w-md w-full">
          <Search className="w-4 h-4 text-[#7A8A80] absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search by dish or ingredients (e.g. malunggay, chicken, sayote)..."
            className="w-full pl-9 pr-4 py-2.5 bg-white border border-[#DDD5C7] rounded-xl text-xs sm:text-sm text-[#192A20] placeholder-[#7A8A80] focus:outline-none focus:ring-2 focus:ring-[#113826] focus:border-transparent transition-all shadow-2xs"
          />
        </div>
      </div>

      {/* Main Filter Bar */}
      <div className="bg-white border border-[#E8E2D5] rounded-3xl p-5 shadow-xs space-y-4">
        {/* Row 1: Fitness Goal */}
        <div>
          <span className="text-[11px] font-bold text-[#15241C] uppercase tracking-wider block mb-2">
            Target Fitness Goal
          </span>
          <div className="flex flex-wrap gap-1.5">
            {fitnessGoalButtons.map((g) => (
              <button
                key={g.id}
                type="button"
                onClick={() => setSelectedFitnessGoal(g.id)}
                className={`px-3 py-1.5 text-xs font-bold rounded-xl transition-all whitespace-nowrap cursor-pointer active:scale-95 ${
                  selectedFitnessGoal === g.id
                    ? 'bg-[#113826] text-[#A3E635] shadow-xs'
                    : 'bg-[#FAF7F2] text-[#45584D] hover:bg-[#EAE4D7] border border-[#E8E2D5]'
                }`}
              >
                {g.label}
              </button>
            ))}
          </div>
        </div>

        {/* Row 2: Cuisine Selector */}
        <div>
          <span className="text-[11px] font-bold text-[#15241C] uppercase tracking-wider block mb-2">
            Cuisine
          </span>
          <div className="flex flex-wrap gap-1.5">
            {[
              { id: 'all', label: 'All Cuisines' },
              { id: 'filipino', label: '🇵🇭 Filipino Classics' },
              { id: 'asian', label: '🥢 Asian' },
              { id: 'mediterranean', label: '🍋 Mediterranean' },
              { id: 'american', label: '🍳 American' },
              { id: 'other', label: '🌍 Global Bowls' }
            ].map((c) => (
              <button
                key={c.id}
                type="button"
                onClick={() => setSelectedCuisine(c.id as CuisineType | 'all')}
                className={`px-3 py-1.5 text-xs font-bold rounded-xl transition-all whitespace-nowrap cursor-pointer active:scale-95 ${
                  selectedCuisine === c.id
                    ? 'bg-[#113826] text-white shadow-xs'
                    : 'bg-[#FAF7F2] text-[#45584D] hover:bg-[#EAE4D7] border border-[#E8E2D5]'
                }`}
              >
                {c.label}
              </button>
            ))}
          </div>
        </div>

        {/* Row 3: Budget Tier & Max Budget Slider */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-3 border-t border-[#F2ECE1]">
          {/* Budget Tier Buttons */}
          <div>
            <span className="text-[11px] font-bold text-[#15241C] uppercase tracking-wider block mb-2">
              Budget Level
            </span>
            <div className="flex flex-wrap gap-1.5">
              {[
                { id: 'all', label: 'All Tiers' },
                { id: 'budget', label: 'Budget-Friendly' },
                { id: 'mid', label: 'Mid-Range' },
                { id: 'premium', label: 'Premium' }
              ].map((tier) => (
                <button
                  key={tier.id}
                  type="button"
                  onClick={() => setSelectedBudgetTier(tier.id as BudgetTier | 'all')}
                  className={`px-3 py-1.5 text-xs font-bold rounded-xl transition-all cursor-pointer active:scale-95 ${
                    selectedBudgetTier === tier.id
                      ? 'bg-[#113826] text-white shadow-xs'
                      : 'bg-[#FAF7F2] text-[#45584D] hover:bg-[#EAE4D7] border border-[#E8E2D5]'
                  }`}
                >
                  {tier.label}
                </button>
              ))}
            </div>
          </div>

          {/* User's Max Budget Per Serving Slider */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <span className="text-[11px] font-bold text-[#5A6D60] uppercase tracking-wider">
                Max Food Budget / Serving ({settings.currency})
              </span>
              <span className="text-xs font-bold font-mono text-[#113826]">
                {formatRawCurrency(maxBudgetCap, settings.currency)}
              </span>
            </div>
            <input
              type="range"
              min={Math.ceil(convertPhpToCurrency(30, settings.currency))}
              max={maxBenchmarkInUserCurrency}
              step={settings.currency === 'JPY' ? 50 : 1}
              value={maxBudgetCap}
              onChange={(e) => setMaxBudgetCap(Number(e.target.value))}
              className="w-full accent-[#113826] h-2 bg-[#F0ECE1] rounded-lg cursor-pointer"
            />
            <div className="flex justify-between text-[10px] text-[#7A8A80] mt-1 font-mono">
              <span>{formatRawCurrency(convertPhpToCurrency(30, settings.currency), settings.currency)}</span>
              <span>{formatRawCurrency(maxBenchmarkInUserCurrency, settings.currency)}+</span>
            </div>
          </div>
        </div>

        {/* Toggle Advanced Filters (Calories, Protein, Cooking Time, Dietary) */}
        <div className="pt-2 flex items-center justify-between text-xs">
          <button
            type="button"
            onClick={() => setShowAdvancedFilters(!showAdvancedFilters)}
            className="flex items-center gap-1.5 font-semibold text-[#113826] hover:underline"
          >
            <Filter className="w-3.5 h-3.5" />
            <span>
              {showAdvancedFilters ? 'Hide Advanced Filters' : 'More Filters (Time, Calories, Protein, Dietary)'}
            </span>
            {activeFiltersCount > 0 && (
              <span className="bg-[#113826] text-white text-[10px] w-4 h-4 rounded-full flex items-center justify-center font-bold">
                {activeFiltersCount}
              </span>
            )}
          </button>

          {activeFiltersCount > 0 && (
            <button
              type="button"
              onClick={resetFilters}
              className="flex items-center gap-1 text-[#8C9C92] hover:text-[#B83828] font-medium"
            >
              <RotateCcw className="w-3 h-3" />
              <span>Reset all</span>
            </button>
          )}
        </div>

        {/* Advanced Filters Expandable Panel */}
        {showAdvancedFilters && (
          <div className="pt-4 border-t border-[#F2ECE1] grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs animate-fadeIn">
            {/* Cooking Time */}
            <div>
              <label className="block text-[11px] font-bold text-[#5A6D60] uppercase mb-1.5 flex items-center gap-1">
                <Clock className="w-3.5 h-3.5 text-[#113826]" />
                Max Cooking Time: {maxCookingTime >= 60 ? 'Any Time' : `≤ ${maxCookingTime} min`}
              </label>
              <input
                type="range"
                min="15"
                max="60"
                step="5"
                value={maxCookingTime}
                onChange={(e) => setMaxCookingTime(Number(e.target.value))}
                className="w-full accent-[#113826] h-1.5 bg-[#F0ECE1] rounded-lg cursor-pointer"
              />
              <div className="flex justify-between text-[10px] text-[#7A8A80] mt-1">
                <span>15m</span>
                <span>30m</span>
                <span>Any</span>
              </div>
            </div>

            {/* Min Protein */}
            <div>
              <label className="block text-[11px] font-bold text-[#5A6D60] uppercase mb-1.5 flex items-center gap-1">
                <Dumbbell className="w-3.5 h-3.5 text-[#113826]" />
                Min Protein: {minProtein > 0 ? `≥ ${minProtein}g` : 'Any'}
              </label>
              <input
                type="range"
                min="0"
                max="50"
                step="5"
                value={minProtein}
                onChange={(e) => setMinProtein(Number(e.target.value))}
                className="w-full accent-[#113826] h-1.5 bg-[#F0ECE1] rounded-lg cursor-pointer"
              />
              <div className="flex justify-between text-[10px] text-[#7A8A80] mt-1 font-mono">
                <span>0g</span>
                <span>25g</span>
                <span>50g+</span>
              </div>
            </div>

            {/* Max Calories */}
            <div>
              <label className="block text-[11px] font-bold text-[#5A6D60] uppercase mb-1.5 flex items-center gap-1">
                <Flame className="w-3.5 h-3.5 text-[#B85D19]" />
                Max Calories: {maxCalories >= 1000 ? 'Any' : `≤ ${maxCalories} kcal`}
              </label>
              <input
                type="range"
                min="200"
                max="1000"
                step="50"
                value={maxCalories}
                onChange={(e) => setMaxCalories(Number(e.target.value))}
                className="w-full accent-[#113826] h-1.5 bg-[#F0ECE1] rounded-lg cursor-pointer"
              />
              <div className="flex justify-between text-[10px] text-[#7A8A80] mt-1 font-mono">
                <span>200</span>
                <span>500</span>
                <span>1000+</span>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Results Header */}
      <div className="flex items-center justify-between text-xs text-[#586A5F] px-1">
        <span>
          Showing <strong>{filteredRecipes.length}</strong> of {recipes.length} recipes
        </span>

        {activeFiltersCount > 0 && (
          <button
            type="button"
            onClick={resetFilters}
            className="flex items-center gap-1 font-semibold text-[#113826] hover:underline"
          >
            <RotateCcw className="w-3 h-3" />
            <span>Reset filters</span>
          </button>
        )}
      </div>

      {/* Recipes Grid */}
      {filteredRecipes.length === 0 ? (
        <div className="bg-white border border-[#E8E2D5] rounded-3xl p-10 text-center max-w-md mx-auto">
          <div className="w-12 h-12 mx-auto mb-3 bg-[#F6F4ED] text-[#6B7C71] rounded-2xl flex items-center justify-center">
            <SlidersHorizontal className="w-6 h-6" />
          </div>
          <h3 className="text-base font-bold text-[#192A20]">No recipes match your filters</h3>
          <p className="text-xs text-[#6B7C71] mt-1">
            Try adjusting your budget cap or clearing some filters to see more delicious meals.
          </p>
          <button
            type="button"
            onClick={resetFilters}
            className="mt-4 px-4 py-2 text-xs font-semibold rounded-xl bg-[#113826] text-white hover:bg-[#1A4E37] transition-colors"
          >
            Clear All Filters
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {filteredRecipes.map((recipe) => (
            <RecipeCard
              key={recipe.id}
              recipe={recipe}
              settings={settings}
              onSelect={onSelectRecipe}
              onQuickAddToPlan={() => onQuickAddToPlan(recipe)}
              onQuickLogMeal={() => onQuickLogMeal(recipe)}
            />
          ))}
        </div>
      )}
    </div>
  );
};
