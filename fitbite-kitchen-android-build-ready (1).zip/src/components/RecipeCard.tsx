import React, { useState } from 'react';
import { Recipe, UserSettings } from '../types';
import { formatCurrency } from '../utils/currency';
import { Clock, Plus, Camera, RotateCcw, Utensils, Check } from 'lucide-react';

interface RecipeCardProps {
  recipe: Recipe;
  settings: UserSettings;
  onSelect: (recipe: Recipe) => void;
  onQuickAddToPlan?: (recipe: Recipe) => void;
  onQuickLogMeal?: (recipe: Recipe) => void;
}

export const RecipeCard: React.FC<RecipeCardProps> = ({
  recipe,
  settings,
  onSelect,
  onQuickAddToPlan,
  onQuickLogMeal
}) => {
  const [imageFailed, setImageFailed] = useState(false);
  const [retryKey, setRetryKey] = useState(0);
  const [justLogged, setJustLogged] = useState(false);

  const totalTime = recipe.prepTimeMinutes + recipe.cookTimeMinutes;
  const costFormatted = formatCurrency(recipe.baseCostPhp, settings.currency);

  const budgetLabel = {
    budget: 'Budget-Friendly',
    mid: 'Mid-Range',
    premium: 'Premium'
  }[recipe.budgetTier];

  // User custom uploaded photo overrides default
  const userCustomPhoto = settings.customRecipePhotos?.[recipe.id];
  const activeImageUrl = userCustomPhoto || (recipe.hasRealPhoto ? recipe.imageUrl : undefined);
  const hasDisplayablePhoto = Boolean(activeImageUrl) && !imageFailed;

  const handleRetry = (e: React.MouseEvent) => {
    e.stopPropagation();
    setImageFailed(false);
    setRetryKey(k => k + 1);
  };

  const handleQuickLog = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (onQuickLogMeal) {
      onQuickLogMeal(recipe);
      setJustLogged(true);
      setTimeout(() => setJustLogged(false), 1500);
    }
  };

  const handleQuickPlan = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (onQuickAddToPlan) {
      onQuickAddToPlan(recipe);
    }
  };

  // Up to two primary dietary / highlight badges
  const keyBadge = recipe.dietaryTags?.[0] || (recipe.proteinGrams >= 30 ? 'High Protein' : recipe.difficulty);

  return (
    <div className="bg-white border border-[#EBE5D8] rounded-3xl overflow-hidden hover:border-[#113826]/40 hover:shadow-xl hover:-translate-y-0.5 transition-all duration-300 flex flex-col justify-between group shadow-xs">
      <div>
        {/* Card Header Media Slot: 16/10 aspect ratio with smooth image zoom */}
        <div 
          onClick={() => onSelect(recipe)}
          className="relative aspect-[16/10] w-full bg-[#F3EFE6] overflow-hidden cursor-pointer select-none"
        >
          {hasDisplayablePhoto ? (
            <>
              <img
                key={retryKey}
                src={activeImageUrl}
                alt={recipe.imageAlt || recipe.title}
                onError={() => setImageFailed(true)}
                loading="lazy"
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500 ease-out"
              />
              {/* Subtle gradient scrim overlay for high text contrast */}
              <div className="absolute inset-0 bg-gradient-to-t from-black/75 via-black/15 to-transparent pointer-events-none" />

              {/* Photo Attribution Badge */}
              {recipe.photoCredit && !userCustomPhoto && (
                <div className="absolute top-2.5 right-2.5 bg-black/60 backdrop-blur-md text-[9px] text-white/95 px-2 py-0.5 rounded-md pointer-events-none font-medium border border-white/10">
                  Photo: {recipe.photoCredit.photographer}
                </div>
              )}
            </>
          ) : (
            /* Clean, honest placeholder (Rule 5: labeled "Photo unavailable") */
            <div className="w-full h-full flex flex-col items-center justify-center p-4 bg-[#F5F1E8] text-center relative border-b border-[#E8E2D5]">
              <div className="w-11 h-11 rounded-2xl bg-white border border-[#DDD5C7] flex items-center justify-center text-[#113826] shadow-2xs mb-2">
                <Camera className="w-5 h-5 text-[#526458]" />
              </div>

              <span className="text-xs font-bold text-[#15241C] uppercase tracking-wider block">
                Photo unavailable
              </span>
              <p className="text-[10px] text-[#69796E] mt-0.5 max-w-[200px] leading-tight">
                Verified photograph matching this dish will appear once confirmed
              </p>

              {imageFailed && (
                <button
                  type="button"
                  onClick={handleRetry}
                  className="mt-2 text-[10px] font-semibold text-[#113826] bg-white px-2 py-1 rounded-md border border-[#DDD5C7] flex items-center gap-1 shadow-2xs hover:bg-[#F0ECE1]"
                >
                  <RotateCcw className="w-3 h-3" />
                  <span>Retry photo</span>
                </button>
              )}
            </div>
          )}

          {/* Floating Category Tag */}
          <div className="absolute top-2.5 left-2.5">
            <span className="bg-white/95 backdrop-blur-md text-[#113826] text-[10px] font-bold px-2.5 py-0.5 rounded-lg shadow-2xs border border-[#EBE5D8]/80">
              {keyBadge}
            </span>
          </div>

          {/* Bottom Banner Stats */}
          <div className="absolute bottom-2.5 left-3 right-3 flex items-center justify-between text-xs font-medium">
            <span className="flex items-center gap-1 bg-[#15241C]/85 text-white backdrop-blur-md px-2 py-0.5 rounded-lg text-[10px] border border-white/10">
              <Clock className="w-3 h-3 text-[#A3E635]" />
              {totalTime} min
            </span>

            <span className="bg-[#113826]/90 text-white backdrop-blur-md px-2 py-0.5 rounded-lg text-[10px] font-bold tracking-tight border border-white/10">
              {recipe.calories} kcal
            </span>
          </div>
        </div>

        {/* Content Body */}
        <div className="p-4 sm:p-5">
          {/* Metadata line */}
          <div className="flex items-center gap-1.5 text-[11px] text-[#64756A] mb-1.5 uppercase tracking-wide font-medium">
            <span className="capitalize">{recipe.cuisine}</span>
            <span aria-hidden="true" className="text-[#DDD5C7]">·</span>
            <span>{budgetLabel}</span>
            <span aria-hidden="true" className="text-[#DDD5C7]">·</span>
            <span>{recipe.difficulty}</span>
          </div>

          {/* Title */}
          <h3 
            onClick={() => onSelect(recipe)}
            className="text-base sm:text-lg font-bold text-[#15241C] leading-snug group-hover:text-[#143D2B] cursor-pointer transition-colors"
          >
            {recipe.title}
          </h3>
          {recipe.filipinoName && recipe.filipinoName !== recipe.title && (
            <p className="text-xs text-[#7A8A80] italic mt-0.5">
              {recipe.filipinoName}
            </p>
          )}

          {/* Short Description */}
          <p className="text-xs text-[#526458] line-clamp-2 mt-2 leading-relaxed">
            {recipe.description}
          </p>

          {/* Nutrition & Cost Strip */}
          <div className="pt-3 mt-3 border-t border-[#F2ECE1] grid grid-cols-2 gap-2 text-xs items-center">
            <div>
              <span className="text-[10px] text-[#7A8A80] block font-medium">Cost / Serving</span>
              <span className="font-bold text-sm text-[#143D2B] font-mono tabular-nums">
                {costFormatted}
              </span>
            </div>
            <div className="text-right">
              <span className="text-[10px] text-[#7A8A80] block font-medium">Protein & Carbs</span>
              <span className="font-bold text-sm text-[#15241C] font-mono tabular-nums block">
                {recipe.proteinGrams}g Protein
              </span>
              <span className="text-[10px] text-[#69796E] font-mono">
                {recipe.carbsGrams}g C · {recipe.fatGrams}g F
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Card Action Controls */}
      <div className="bg-[#FAF7F2] border-t border-[#EBE5D8] px-4 py-2.5 flex items-center justify-between gap-2">
        <button
          type="button"
          onClick={() => onSelect(recipe)}
          className="px-3.5 py-1.5 text-xs font-bold text-[#113826] hover:bg-[#E8F0EB] rounded-xl transition-all flex items-center gap-1.5 active:scale-95 cursor-pointer"
        >
          <Utensils className="w-3.5 h-3.5 text-[#65A30D]" />
          <span>View Recipe</span>
        </button>

        <div className="flex items-center gap-1.5">
          {onQuickAddToPlan && (
            <button
              type="button"
              onClick={handleQuickPlan}
              title="Add to Meal Plan"
              className="px-2.5 py-1.5 text-xs font-semibold rounded-xl bg-white border border-[#DDD5C7] text-[#113826] hover:bg-[#E8F0EB] transition-all flex items-center gap-1 shadow-2xs active:scale-95 cursor-pointer"
            >
              <Plus className="w-3 h-3 text-[#113826]" />
              <span>Plan</span>
            </button>
          )}

          {onQuickLogMeal && (
            <button
              type="button"
              onClick={handleQuickLog}
              title="Log to Calorie Tracker"
              className={`px-3 py-1.5 text-xs font-bold rounded-xl transition-all shadow-2xs active:scale-95 flex items-center gap-1 cursor-pointer ${
                justLogged 
                  ? 'bg-[#65A30D] text-white' 
                  : 'bg-[#113826] text-white hover:bg-[#1A4E37]'
              }`}
            >
              {justLogged ? (
                <>
                  <Check className="w-3 h-3 stroke-[3]" />
                  <span>Logged</span>
                </>
              ) : (
                <span>Log Meal</span>
              )}
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
