import React, { useState } from 'react';
import { Recipe, UserSettings, BudgetSwap } from '../types';
import { formatCurrency, convertPhpToCurrency, convertCurrencyToPhp } from '../utils/currency';
import { formatIngredientQuantity } from '../utils/units';
import { 
  X, 
  Clock, 
  Flame, 
  Users, 
  Check, 
  Sparkles, 
  Plus, 
  Edit2, 
  Info, 
  ArrowRight, 
  ShoppingBag, 
  AlertTriangle, 
  Refrigerator, 
  Utensils, 
  RotateCcw,
  Camera,
  Upload,
  ExternalLink,
  Printer,
  ChefHat
} from 'lucide-react';

interface RecipeDetailModalProps {
  recipe: Recipe;
  settings: UserSettings;
  onClose: () => void;
  onAddToPlan: (recipe: Recipe, servings: number) => void;
  onLogMeal: (recipe: Recipe, servings: number) => void;
  onAddToShoppingList: (recipe: Recipe, servings: number) => void;
  onUpdateIngredientPrice: (ingredientId: string, newPricePhp: number) => void;
  onSaveCustomPhoto?: (recipeId: string, photoDataUrl: string) => void;
}

export const RecipeDetailModal: React.FC<RecipeDetailModalProps> = ({
  recipe,
  settings,
  onClose,
  onAddToPlan,
  onLogMeal,
  onAddToShoppingList,
  onUpdateIngredientPrice,
  onSaveCustomPhoto
}) => {
  const [servings, setServings] = useState(recipe.servings);
  const [appliedSwaps, setAppliedSwaps] = useState<Record<string, boolean>>({});
  const [completedSteps, setCompletedSteps] = useState<Record<number, boolean>>({});
  const [editingIngredientId, setEditingIngredientId] = useState<string | null>(null);
  const [editingPriceInput, setEditingPriceInput] = useState<string>('');
  const [imageFailed, setImageFailed] = useState(false);
  const [retryKey, setRetryKey] = useState(0);
  const [isCookMode, setIsCookMode] = useState(false);
  const [activeCookStep, setActiveCookStep] = useState(0);

  const servingsRatio = servings / recipe.servings;

  // Dynamic cost with applied budget swaps
  let currentCostPhpPerServing = recipe.baseCostPhp;
  recipe.swaps.forEach((swap) => {
    if (appliedSwaps[swap.id]) {
      currentCostPhpPerServing -= swap.savingsPhpPerServing;
    }
  });

  const toggleSwap = (swap: BudgetSwap) => {
    setAppliedSwaps(prev => ({
      ...prev,
      [swap.id]: !prev[swap.id]
    }));
  };

  const toggleStep = (index: number) => {
    setCompletedSteps(prev => ({
      ...prev,
      [index]: !prev[index]
    }));
  };

  const startEditPrice = (ingredientId: string, currentPhp: number) => {
    setEditingIngredientId(ingredientId);
    const inUserCurrency = convertPhpToCurrency(currentPhp, settings.currency);
    setEditingPriceInput(inUserCurrency.toFixed(2));
  };

  const saveEditPrice = (ingredientId: string) => {
    const parsed = parseFloat(editingPriceInput);
    if (!isNaN(parsed) && parsed >= 0) {
      const phpAmount = convertCurrencyToPhp(parsed, settings.currency);
      onUpdateIngredientPrice(ingredientId, phpAmount);
    }
    setEditingIngredientId(null);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file && onSaveCustomPhoto) {
      const reader = new FileReader();
      reader.onload = () => {
        if (typeof reader.result === 'string') {
          onSaveCustomPhoto(recipe.id, reader.result);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const totalCalories = Math.round(recipe.calories * servings);
  const totalCostFormatted = formatCurrency(currentCostPhpPerServing * servings, settings.currency);
  const perServingCostFormatted = formatCurrency(currentCostPhpPerServing, settings.currency);
  const totalTime = recipe.prepTimeMinutes + recipe.cookTimeMinutes;

  // User custom uploaded photo overrides default
  const userCustomPhoto = settings.customRecipePhotos?.[recipe.id];
  const activeImageUrl = userCustomPhoto || (recipe.hasRealPhoto ? recipe.imageUrl : undefined);
  const hasDisplayablePhoto = Boolean(activeImageUrl) && !imageFailed;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-[#0E2C1E]/80 backdrop-blur-sm animate-fadeIn">
      <div className="bg-[#FAF7F2] border border-[#EBE5D8] rounded-3xl max-w-3xl w-full max-h-[94vh] overflow-y-auto shadow-2xl flex flex-col">
        {/* Sticky Header with Actions & Close button */}
        <div className="sticky top-0 z-20 bg-[#FAF7F2]/95 backdrop-blur-md border-b border-[#EBE5D8] px-4 sm:px-6 py-3 flex items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <span className="text-xl" role="img" aria-label={recipe.title}>
              {recipe.imageEmoji}
            </span>
            <span className="text-xs font-bold text-[#113826] uppercase tracking-wider">
              {recipe.cuisine} Cuisine · {recipe.difficulty}
            </span>
          </div>

          <div className="flex items-center gap-2">
            {/* Cook Mode toggle */}
            <button
              type="button"
              onClick={() => setIsCookMode(prev => !prev)}
              className={`px-3 py-1.5 text-xs font-bold rounded-xl border transition-all flex items-center gap-1.5 active:scale-95 cursor-pointer ${
                isCookMode
                  ? 'bg-[#113826] text-[#A3E635] border-[#113826] shadow-xs'
                  : 'bg-white text-[#113826] border-[#DDD5C7] hover:bg-[#E8F0EB]'
              }`}
              title="Toggle Hands-Free Kitchen Cook Mode"
            >
              <ChefHat className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">{isCookMode ? 'Cook Mode Active' : 'Cook Mode'}</span>
            </button>

            {/* Print button */}
            <button
              type="button"
              onClick={() => window.print()}
              className="px-2.5 py-1.5 text-xs font-semibold rounded-xl bg-white border border-[#DDD5C7] text-[#526458] hover:text-[#113826] hover:bg-[#F0ECE1] transition-colors flex items-center gap-1 cursor-pointer"
              title="Print Recipe Sheet"
            >
              <Printer className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Print</span>
            </button>

            <button
              type="button"
              onClick={onClose}
              className="min-h-[36px] min-w-[36px] flex items-center justify-center rounded-xl bg-white border border-[#DDD5C7] text-[#526458] hover:text-[#15241C] hover:bg-[#F0ECE1] transition-colors cursor-pointer"
              aria-label="Close modal"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Hero Media Slot */}
        <div className="relative h-64 sm:h-84 w-full bg-[#EFEAE1] shrink-0 overflow-hidden">
          {hasDisplayablePhoto ? (
            <>
              <img
                key={retryKey}
                src={activeImageUrl}
                alt={recipe.imageAlt || recipe.title}
                onError={() => setImageFailed(true)}
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/25 to-transparent pointer-events-none" />

              {/* Verified Real Photograph Attribution (Rule 4 & 5) */}
              <div className="absolute top-3 right-3 bg-black/60 backdrop-blur-md text-[10px] text-white/95 px-2.5 py-1 rounded-lg border border-white/10 flex items-center gap-1.5 shadow-sm">
                <span className="w-1.5 h-1.5 rounded-full bg-[#7AC29A]" />
                {userCustomPhoto ? (
                  <span>Cooked & Captured by You</span>
                ) : (
                  <span>
                    Real photo by {recipe.photoCredit?.photographer || 'Professional Food Photographer'} ({recipe.photoCredit?.source || 'Verified Source'})
                  </span>
                )}
              </div>
            </>
          ) : (
            /* Clean, honest placeholder (Rule 5: labeled "Photo unavailable") */
            <div className="w-full h-full flex flex-col items-center justify-center p-6 bg-[#F4EFE6] text-center border-b border-[#E5DFD3]">
              <div className="w-14 h-14 rounded-3xl bg-white border border-[#DDD5C7] flex items-center justify-center text-[#143D2B] shadow-xs mb-3">
                <Camera className="w-7 h-7 text-[#4D6054]" />
              </div>

              <span className="text-base sm:text-lg font-bold text-[#192A20] tracking-tight">
                Photo unavailable
              </span>
              <p className="text-xs text-[#586A5F] mt-1 max-w-md leading-relaxed">
                We only display verified photographs matching the exact recipe and ingredients. A verified photograph of this prepared dish is currently unavailable.
              </p>

              {/* Option for user to attach their real photo of this dish */}
              <label className="mt-4 cursor-pointer inline-flex items-center gap-2 px-3.5 py-1.5 text-xs font-semibold rounded-xl bg-white border border-[#DDD5C7] text-[#143D2B] hover:bg-[#E8F0EB] transition-colors shadow-2xs">
                <Upload className="w-3.5 h-3.5 text-[#143D2B]" />
                <span>Cooked this dish? Add your photo</span>
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleFileUpload}
                  className="hidden"
                />
              </label>

              {imageFailed && (
                <button
                  type="button"
                  onClick={() => {
                    setImageFailed(false);
                    setRetryKey(k => k + 1);
                  }}
                  className="mt-3 text-xs font-semibold text-[#143D2B] bg-white px-3 py-1.5 rounded-lg border border-[#DDD5C7] flex items-center gap-1.5 shadow-2xs"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>Retry photo</span>
                </button>
              )}
            </div>
          )}

          {/* Title Overlay in Banner */}
          <div className={`absolute bottom-4 left-5 right-5 ${hasDisplayablePhoto ? 'text-white' : 'text-[#192A20]'}`}>
            <h1 className={`text-2xl sm:text-3xl font-extrabold tracking-tight ${hasDisplayablePhoto ? 'drop-shadow-md' : ''}`}>
              {recipe.title}
            </h1>
            {recipe.filipinoName && recipe.filipinoName !== recipe.title && (
              <p className={`text-sm italic mt-0.5 ${hasDisplayablePhoto ? 'text-[#E2ECE5] drop-shadow-sm' : 'text-[#64756A]'}`}>
                {recipe.filipinoName}
              </p>
            )}
          </div>
        </div>

        {/* Modal Body */}
        <div className="p-5 sm:p-7 space-y-7 flex-1">
          {/* Quick Metrics Bar */}
          <div className="flex flex-wrap items-center gap-y-2 gap-x-4 text-xs text-[#526458] pb-4 border-b border-[#E8E2D5]">
            <span className="flex items-center gap-1.5 font-medium">
              <Clock className="w-4 h-4 text-[#143D2B]" />
              Prep: {recipe.prepTimeMinutes}m · Cook: {recipe.cookTimeMinutes}m ({totalTime}m total)
            </span>
            <span aria-hidden="true" className="text-[#C4BCAC]">·</span>
            <span className="font-semibold text-[#143D2B]">
              {recipe.budgetTier === 'budget' ? 'Budget-Friendly' : recipe.budgetTier === 'mid' ? 'Mid-Range' : 'Premium'}
            </span>
            <span aria-hidden="true" className="text-[#C4BCAC]">·</span>
            <span>{recipe.dietaryTags.join(' · ')}</span>
          </div>

          {/* Description */}
          <p className="text-sm text-[#3E5245] leading-relaxed">
            {recipe.description}
          </p>

          {/* Servings Scaler & Nutrition Dashboard */}
          <div className="bg-white border border-[#E5DFD3] rounded-3xl p-5 shadow-xs space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-[#F2ECE1]">
              {/* Servings controller */}
              <div>
                <span className="text-[11px] font-bold text-[#5B6D61] uppercase tracking-wider block mb-1">
                  Adjust Number of Servings
                </span>
                <div className="flex items-center gap-3">
                  <button
                    type="button"
                    onClick={() => setServings(Math.max(1, servings - 1))}
                    className="w-9 h-9 rounded-xl bg-[#F5F2EA] border border-[#DDD5C7] font-bold text-[#143D2B] hover:bg-[#E8F0EB] transition-colors flex items-center justify-center text-lg active:scale-95"
                  >
                    -
                  </button>
                  <span className="text-lg font-bold font-mono text-[#192A20] w-8 text-center">
                    {servings}
                  </span>
                  <button
                    type="button"
                    onClick={() => setServings(Math.min(12, servings + 1))}
                    className="w-9 h-9 rounded-xl bg-[#F5F2EA] border border-[#DDD5C7] font-bold text-[#143D2B] hover:bg-[#E8F0EB] transition-colors flex items-center justify-center text-lg active:scale-95"
                  >
                    +
                  </button>
                  <span className="text-xs text-[#6B7C71]">
                    ({servings === 1 ? 'single portion' : `${servings} portions`})
                  </span>
                </div>
              </div>

              {/* Estimated Recipe Cost */}
              <div className="sm:text-right">
                <span className="text-[11px] font-bold text-[#5B6D61] uppercase tracking-wider block mb-1">
                  Estimated Ingredient Cost
                </span>
                <span className="text-xl sm:text-2xl font-extrabold text-[#143D2B] font-mono tabular-nums">
                  {perServingCostFormatted}
                </span>
                <span className="text-xs text-[#64756A] block">
                  per serving ({totalCostFormatted} total for {servings})
                </span>
              </div>
            </div>

            {/* Macronutrients Grid per serving */}
            <div>
              <span className="text-[11px] font-bold text-[#5B6D61] uppercase tracking-wider block mb-2">
                Estimated Nutrition / Serving (Calculated Baseline)
              </span>
              <div className="grid grid-cols-2 sm:grid-cols-5 gap-2 font-mono text-center">
                <div className="bg-[#FAF7F0] p-2.5 rounded-xl border border-[#E5DFD3]">
                  <span className="text-[10px] text-[#7A8A80] block font-sans uppercase">Calories</span>
                  <span className="text-base font-bold text-[#192A20]">{recipe.calories} kcal</span>
                </div>
                <div className="bg-[#FAF7F0] p-2.5 rounded-xl border border-[#E5DFD3]">
                  <span className="text-[10px] text-[#7A8A80] block font-sans uppercase">Protein</span>
                  <span className="text-base font-bold text-[#143D2B]">{recipe.proteinGrams}g</span>
                </div>
                <div className="bg-[#FAF7F0] p-2.5 rounded-xl border border-[#E5DFD3]">
                  <span className="text-[10px] text-[#7A8A80] block font-sans uppercase">Carbohydrates</span>
                  <span className="text-base font-bold text-[#192A20]">{recipe.carbsGrams}g</span>
                </div>
                <div className="bg-[#FAF7F0] p-2.5 rounded-xl border border-[#E5DFD3]">
                  <span className="text-[10px] text-[#7A8A80] block font-sans uppercase">Fats</span>
                  <span className="text-base font-bold text-[#192A20]">{recipe.fatGrams}g</span>
                </div>
                <div className="bg-[#FAF7F0] p-2.5 rounded-xl border border-[#E5DFD3] col-span-2 sm:col-span-1">
                  <span className="text-[10px] text-[#7A8A80] block font-sans uppercase">Fiber</span>
                  <span className="text-base font-bold text-[#192A20]">{recipe.fiberGrams || 3}g</span>
                </div>
              </div>
            </div>
          </div>

          {/* Interactive Budget Swaps & Substitutions */}
          {recipe.swaps.length > 0 && (
            <div className="bg-[#EBF2ED] border border-[#CFDFD4] rounded-3xl p-5 space-y-3">
              <div className="flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-[#113826]" />
                <h3 className="text-xs font-bold text-[#113826] uppercase tracking-wider">
                  Smart Budget & Local Ingredient Swaps
                </h3>
              </div>
              <p className="text-xs text-[#3D5646]">
                Tap any swap below to substitute ingredients and update this recipe’s estimated cost in real-time.
              </p>

              <div className="space-y-2">
                {recipe.swaps.map((swap) => {
                  const isApplied = !!appliedSwaps[swap.id];
                  const savingsFormatted = formatCurrency(swap.savingsPhpPerServing, settings.currency);
                  return (
                    <div
                      key={swap.id}
                      className={`p-3.5 rounded-2xl border transition-all ${
                        isApplied
                          ? 'bg-white border-[#113826] shadow-xs'
                          : 'bg-[#F4F8F5] border-[#D1E0D6]'
                      }`}
                    >
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                        <div>
                          <div className="flex items-center gap-2 text-xs font-semibold text-[#192A20]">
                            <span className="line-through text-[#7A8A80]">{swap.originalIngredient}</span>
                            <ArrowRight className="w-3.5 h-3.5 text-[#113826]" />
                            <span className="text-[#113826]">{swap.swapIngredient}</span>
                          </div>
                          <p className="text-[11px] text-[#586A5F] mt-1">{swap.reason}</p>
                          <p className="text-[11px] text-[#305844] italic mt-0.5">Tip: {swap.culinaryTip}</p>
                        </div>

                        <button
                          type="button"
                          onClick={() => toggleSwap(swap)}
                          className={`px-3 py-1.5 text-xs font-medium rounded-xl whitespace-nowrap transition-colors self-start sm:self-center ${
                            isApplied
                              ? 'bg-[#113826] text-white'
                              : 'bg-white border border-[#B8CEBF] text-[#113826] hover:bg-[#E2EDE5]'
                          }`}
                        >
                          {isApplied ? 'Swap Applied ✓' : `Save ${savingsFormatted}/srv`}
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* Scaled Ingredients List with Editable Local Prices */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <h3 className="text-sm font-bold text-[#192A20] uppercase tracking-wider">
                Ingredients ({servings} {servings === 1 ? 'serving' : 'servings'})
              </h3>
              <span className="text-xs text-[#6B7C71]">
                Tap price to adjust for your local store
              </span>
            </div>

            <div className="bg-white border border-[#E5DFD3] rounded-2xl divide-y divide-[#F2ECE1] overflow-hidden">
              {recipe.ingredients.map((ing) => {
                const customPhp = settings.customIngredientPrices[ing.id];
                const basePhp = customPhp !== undefined ? customPhp : ing.estimatedCostPhp;
                const scaledCost = (basePhp / recipe.servings) * servings;
                const qtyFormatted = formatIngredientQuantity(
                  ing.amountMetric,
                  ing.unitMetric,
                  ing.amountCustomary,
                  ing.unitCustomary,
                  settings.unitSystem,
                  servingsRatio
                );

                const isEditing = editingIngredientId === ing.id;

                return (
                  <div key={ing.id} className="p-3 sm:px-4 flex items-center justify-between gap-3 text-xs">
                    <div className="flex items-center gap-2.5 min-w-0">
                      <span className="w-1.5 h-1.5 rounded-full bg-[#113826] shrink-0" />
                      <span className="font-semibold text-[#192A20] truncate">{ing.name}</span>
                      <span className="text-[#64756A] font-mono tabular-nums shrink-0">
                        ({qtyFormatted})
                      </span>
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                      {isEditing ? (
                        <div className="flex items-center gap-1">
                          <input
                            type="number"
                            step="0.1"
                            value={editingPriceInput}
                            onChange={(e) => setEditingPriceInput(e.target.value)}
                            className="w-16 px-1.5 py-0.5 border border-[#113826] rounded text-right font-mono"
                            autoFocus
                          />
                          <button
                            type="button"
                            onClick={() => saveEditPrice(ing.id)}
                            className="p-1 text-white bg-[#113826] rounded hover:bg-[#1A4E37]"
                          >
                            <Check className="w-3 h-3" />
                          </button>
                        </div>
                      ) : (
                        <button
                          type="button"
                          onClick={() => startEditPrice(ing.id, basePhp)}
                          title="Click to edit with your local grocery price"
                          className="flex items-center gap-1 font-mono tabular-nums text-[#3F5245] hover:text-[#113826] bg-[#F7F4EC] px-2 py-0.5 rounded border border-[#E0D8CB] transition-colors"
                        >
                          <span>{formatCurrency(scaledCost, settings.currency)}</span>
                          <Edit2 className="w-2.5 h-2.5 opacity-50" />
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Numbered Step-by-Step Cooking Guide */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold text-[#192A20] uppercase tracking-wider">
                Preparation & Cooking Guide (Tap Steps to Complete)
              </h3>
              <span className="text-xs text-[#6B7C71]">
                {Object.values(completedSteps).filter(Boolean).length} of {recipe.instructions.length} done
              </span>
            </div>

            {/* Cook Mode Spotlight Box */}
            {isCookMode && (
              <div className="bg-[#113826] text-white rounded-3xl p-5 shadow-lg border border-[#164732] space-y-3 animate-fadeIn">
                <div className="flex items-center justify-between">
                  <span className="inline-flex items-center gap-1.5 text-xs font-bold text-[#A3E635] uppercase tracking-wider">
                    <ChefHat className="w-4 h-4 text-[#A3E635]" />
                    <span>Kitchen Cook Mode Spotlight</span>
                  </span>
                  <span className="text-xs font-mono font-bold bg-white/10 px-2 py-0.5 rounded-lg text-white/90">
                    Step {activeCookStep + 1} of {recipe.instructions.length}
                  </span>
                </div>

                {/* Progress bar */}
                <div className="w-full h-1.5 bg-white/20 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-[#A3E635] transition-all duration-300"
                    style={{ width: `${((activeCookStep + 1) / recipe.instructions.length) * 100}%` }}
                  />
                </div>

                <div className="py-2">
                  <p className="text-base sm:text-lg font-medium leading-relaxed text-white">
                    {recipe.instructions[activeCookStep]}
                  </p>
                </div>

                <div className="pt-2 border-t border-white/10 flex items-center justify-between gap-2">
                  <button
                    type="button"
                    disabled={activeCookStep === 0}
                    onClick={() => setActiveCookStep(s => Math.max(0, s - 1))}
                    className="px-3 py-1.5 text-xs font-bold rounded-xl bg-white/10 hover:bg-white/20 disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
                  >
                    ← Previous Step
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      toggleStep(activeCookStep);
                      if (activeCookStep < recipe.instructions.length - 1) {
                        setActiveCookStep(s => s + 1);
                      }
                    }}
                    className="px-3.5 py-1.5 text-xs font-bold rounded-xl bg-[#A3E635] text-[#113826] hover:bg-[#B4F044] transition-colors flex items-center gap-1 active:scale-95"
                  >
                    <Check className="w-3.5 h-3.5 stroke-[3]" />
                    <span>{completedSteps[activeCookStep] ? 'Completed ✓ Next' : 'Done & Next Step →'}</span>
                  </button>

                  <button
                    type="button"
                    disabled={activeCookStep >= recipe.instructions.length - 1}
                    onClick={() => setActiveCookStep(s => Math.min(recipe.instructions.length - 1, s + 1))}
                    className="px-3 py-1.5 text-xs font-bold rounded-xl bg-white/10 hover:bg-white/20 disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
                  >
                    Next Step →
                  </button>
                </div>
              </div>
            )}

            <div className="space-y-2.5">
              {recipe.instructions.map((step, idx) => {
                const isDone = !!completedSteps[idx];
                const isCurrent = isCookMode && activeCookStep === idx;
                return (
                  <div
                    key={idx}
                    onClick={() => {
                      toggleStep(idx);
                      if (isCookMode) setActiveCookStep(idx);
                    }}
                    className={`p-3.5 rounded-2xl border cursor-pointer transition-all flex items-start gap-3.5 ${
                      isCurrent
                        ? 'bg-[#EBF2ED] border-[#113826] shadow-xs ring-2 ring-[#113826]/20'
                        : isDone
                        ? 'bg-[#EBF2ED] border-[#C3D9CB] opacity-80'
                        : 'bg-white border-[#E5DFD3] hover:border-[#113826]/40'
                    }`}
                  >
                    <div
                      className={`w-6 h-6 rounded-lg flex items-center justify-center shrink-0 text-xs font-bold transition-colors ${
                        isDone
                          ? 'bg-[#113826] text-white'
                          : isCurrent
                          ? 'bg-[#113826] text-[#A3E635]'
                          : 'bg-[#F0ECE1] text-[#4F6255] border border-[#DDD5C7]'
                      }`}
                    >
                      {isDone ? <Check className="w-3.5 h-3.5" /> : idx + 1}
                    </div>
                    <p
                      className={`text-xs sm:text-sm leading-relaxed ${
                        isDone ? 'line-through text-[#64756A]' : 'text-[#203126]'
                      }`}
                    >
                      {step}
                    </p>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Culinary Advice Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
            {/* Common Mistakes to Avoid */}
            {recipe.commonMistakes && recipe.commonMistakes.length > 0 && (
              <div className="bg-[#FAF2F2] border border-[#ECD1D1] rounded-2xl p-4 text-[#6E2E2E]">
                <div className="flex items-center gap-1.5 font-bold mb-1.5">
                  <AlertTriangle className="w-4 h-4 text-[#B83828]" />
                  <span>Common Mistakes to Avoid:</span>
                </div>
                <ul className="list-disc pl-4 space-y-1">
                  {recipe.commonMistakes.map((m, i) => (
                    <li key={i}>{m}</li>
                  ))}
                </ul>
              </div>
            )}

            {/* Serving Suggestions */}
            {recipe.servingSuggestions && (
              <div className="bg-[#FAF6EC] border border-[#EAE0C4] rounded-2xl p-4 text-[#5E4E28]">
                <div className="flex items-center gap-1.5 font-bold mb-1.5">
                  <Utensils className="w-4 h-4 text-[#8C7337]" />
                  <span>Chef Serving Suggestions:</span>
                </div>
                <p>{recipe.servingSuggestions}</p>
              </div>
            )}

            {/* Food Storage Advice */}
            {recipe.storageAdvice && (
              <div className="bg-[#F4F8F6] border border-[#CFE2D7] rounded-2xl p-4 text-[#2C523C]">
                <div className="flex items-center gap-1.5 font-bold mb-1.5">
                  <Refrigerator className="w-4 h-4 text-[#113826]" />
                  <span>Food Storage & Shelf Life:</span>
                </div>
                <p>{recipe.storageAdvice}</p>
              </div>
            )}

            {/* Reheating Guidelines */}
            {recipe.reheatingAdvice && (
              <div className="bg-[#F8F6F2] border border-[#E5DFD3] rounded-2xl p-4 text-[#44564B]">
                <div className="flex items-center gap-1.5 font-bold mb-1.5">
                  <Clock className="w-4 h-4 text-[#113826]" />
                  <span>Reheating Advice:</span>
                </div>
                <p>{recipe.reheatingAdvice}</p>
              </div>
            )}
          </div>

          {/* Health & Price Disclaimer */}
          <div className="flex items-start gap-2 p-3 bg-white border border-[#E5DFD3] rounded-xl text-[11px] text-[#7A8A80]">
            <Info className="w-4 h-4 shrink-0 text-[#8C9C92] mt-0.5" />
            <p>
              Nutritional values and ingredient costs are estimates based on standard regional ingredient averages. Adjust ingredient prices anytime to match your local market. Consult a doctor or registered dietitian for medical dietary guidance.
            </p>
          </div>
        </div>

        {/* Action Controls Footer */}
        <div className="sticky bottom-0 bg-[#FAF7F2]/95 backdrop-blur-md border-t border-[#EBE5D8] p-4 sm:p-5 flex flex-wrap items-center justify-end gap-2.5">
          <button
            type="button"
            onClick={() => onAddToShoppingList(recipe, servings)}
            className="px-4 py-2.5 text-xs font-bold rounded-xl bg-white border border-[#DDD5C7] text-[#113826] hover:bg-[#E8F0EB] transition-colors flex items-center gap-1.5 shadow-2xs active:scale-95 cursor-pointer"
          >
            <ShoppingBag className="w-4 h-4 text-[#65A30D]" />
            <span>Add to Grocery List</span>
          </button>

          <button
            type="button"
            onClick={() => onAddToPlan(recipe, servings)}
            className="px-4 py-2.5 text-xs font-bold rounded-xl bg-white border border-[#DDD5C7] text-[#113826] hover:bg-[#E8F0EB] transition-colors flex items-center gap-1.5 shadow-2xs active:scale-95 cursor-pointer"
          >
            <Plus className="w-4 h-4 text-[#113826]" />
            <span>Add to Meal Planner</span>
          </button>

          <button
            type="button"
            onClick={() => onLogMeal(recipe, servings)}
            className="px-5 py-2.5 text-xs font-bold rounded-xl bg-[#113826] hover:bg-[#184832] text-white shadow-xs transition-all flex items-center gap-1.5 active:scale-95 cursor-pointer"
          >
            <Check className="w-4 h-4 stroke-[2.5] text-[#A3E635]" />
            <span>Log to Tracker ({totalCalories} kcal)</span>
          </button>
        </div>
      </div>
    </div>
  );
};
