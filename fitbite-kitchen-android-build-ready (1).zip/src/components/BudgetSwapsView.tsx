import React, { useState } from 'react';
import { UserSettings } from '../types';
import { formatCurrency, formatRawCurrency, convertPhpToCurrency } from '../utils/currency';
import { Sparkles, ArrowRight, DollarSign, PiggyBank, CheckCircle, Info } from 'lucide-react';

interface BudgetSwapsViewProps {
  settings: UserSettings;
}

interface MasterSwapItem {
  id: string;
  originalName: string;
  originalPriceEstimatePhp: number;
  swapName: string;
  swapPriceEstimatePhp: number;
  savingsPhpPerServing: number;
  proteinComparison: string;
  culinaryTip: string;
  category: string;
}

const MASTER_SWAPS: MasterSwapItem[] = [
  {
    id: 'ms-fish',
    originalName: 'Imported Salmon Fillet (150g)',
    originalPriceEstimatePhp: 160,
    swapName: 'Fresh Bangus Belly or Tilapia Fillet',
    swapPriceEstimatePhp: 65,
    savingsPhpPerServing: 95,
    proteinComparison: 'Equal protein (~30g), rich in Omega-3 fatty acids.',
    culinaryTip: 'Pan-sear bangus belly skin-side down until blistered and golden. Finish with calamansi and garlic.',
    category: 'Protein & Seafood'
  },
  {
    id: 'ms-greens',
    originalName: 'Imported Baby Kale / Spinach',
    originalPriceEstimatePhp: 45,
    swapName: 'Fresh Malunggay (Moringa) or Kangkong',
    swapPriceEstimatePhp: 12,
    savingsPhpPerServing: 33,
    proteinComparison: 'Malunggay has 3x more iron and 4x more calcium per gram than kale!',
    culinaryTip: 'Never boil malunggay too long. Turn off the burner and let residual steam gently wilt the leaves.',
    category: 'Greens & Produce'
  },
  {
    id: 'ms-protein',
    originalName: 'Ground Beef / Pork (200g)',
    originalPriceEstimatePhp: 80,
    swapName: 'Firm Tofu (Tokwa) + Hard-Boiled Egg',
    swapPriceEstimatePhp: 30,
    savingsPhpPerServing: 50,
    proteinComparison: '28g plant & egg protein with zero saturated animal cholesterol.',
    culinaryTip: 'Press tofu cubes between paper towels for 10 minutes, then pan-sear until crispy before tossing in savory sauce.',
    category: 'Protein'
  },
  {
    id: 'ms-grains',
    originalName: 'Imported Quinoa (1 cup)',
    originalPriceEstimatePhp: 55,
    swapName: 'Philippine Adlai Grain or Brown Rice',
    swapPriceEstimatePhp: 22,
    savingsPhpPerServing: 33,
    proteinComparison: 'Adlai grain is packed with dietary fiber, low glycemic index, and satisfying chew.',
    culinaryTip: 'Rinse adlai thoroughly and boil at 1:2 ratio with water for 30 minutes until tender.',
    category: 'Complex Grains'
  },
  {
    id: 'ms-citrus',
    originalName: 'Imported Meyer Lemon (1 pc)',
    originalPriceEstimatePhp: 35,
    swapName: 'Fresh Local Calamansi (5 pcs)',
    swapPriceEstimatePhp: 8,
    savingsPhpPerServing: 27,
    proteinComparison: 'Bright vitamin C with distinct fragrant floral notes.',
    culinaryTip: 'Cut calamansi at the top 1/3 (not dead center) to avoid puncturing seeds that cause bitterness.',
    category: 'Produce & Citrus'
  },
  {
    id: 'ms-veg',
    originalName: 'Imported Zucchini / Courgette',
    originalPriceEstimatePhp: 40,
    swapName: 'Sayote (Chayote) or Green Eggplant',
    swapPriceEstimatePhp: 15,
    savingsPhpPerServing: 25,
    proteinComparison: 'High water content, gut-friendly prebiotic fiber, and tender texture.',
    culinaryTip: 'Rub sayote halves together to release the sticky sap before peeling and cubing.',
    category: 'Vegetables'
  },
  {
    id: 'ms-beans',
    originalName: 'Imported Canned Cannellini Beans',
    originalPriceEstimatePhp: 65,
    swapName: 'Green Mung Beans (Monggo) or Dried White Beans',
    swapPriceEstimatePhp: 20,
    savingsPhpPerServing: 45,
    proteinComparison: 'Full of prebiotic plant fiber and 18g protein per cup.',
    culinaryTip: 'Soak dry beans in water in the morning so they cook in just 20 minutes for dinner.',
    category: 'Pantry'
  }
];

export const BudgetSwapsView: React.FC<BudgetSwapsViewProps> = ({ settings }) => {
  const [mealsPerWeek, setMealsPerWeek] = useState(6);

  // Average savings across swaps
  const avgSavingPerMealPhp = 45;
  const weeklySavingPhp = avgSavingPerMealPhp * mealsPerWeek;
  const monthlySavingPhp = weeklySavingPhp * 4.3;
  const annualSavingPhp = weeklySavingPhp * 52;

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-[#192A20] tracking-tight">
          Smart Budget & Local Swaps
        </h1>
        <p className="text-xs sm:text-sm text-[#586A5F] mt-0.5 max-w-2xl">
          Cook restaurant-quality nutritious meals without overpaying for imported luxury groceries. Use smart local swaps to save money while boosting nutrient density.
        </p>
      </div>

      {/* Interactive Savings Calculator */}
      <div className="bg-[#FAF7F0] border border-[#E5DFD3] rounded-3xl p-6 sm:p-8 shadow-xs">
        <div className="flex items-center gap-2 mb-3">
          <PiggyBank className="w-5 h-5 text-[#113826]" />
          <h2 className="text-sm font-bold text-[#113826] uppercase tracking-wider">
            Interactive Annual Food Savings Calculator
          </h2>
        </div>

        <p className="text-xs text-[#526458] mb-5">
          See how much you can save simply by swapping 1 or 2 premium ingredients for fresh local alternatives each week.
        </p>

        {/* Meals slider */}
        <div className="mb-6 bg-white p-4 rounded-2xl border border-[#E8E2D5] max-w-xl">
          <div className="flex items-center justify-between mb-2 text-xs">
            <span className="font-semibold text-[#192A20]">Meals cooked with smart swaps:</span>
            <span className="font-bold font-mono text-[#113826] text-sm">
              {mealsPerWeek} meals / week
            </span>
          </div>
          <input
            type="range"
            min="1"
            max="14"
            value={mealsPerWeek}
            onChange={(e) => setMealsPerWeek(Number(e.target.value))}
            className="w-full accent-[#113826] h-2 bg-[#F0ECE1] rounded-lg cursor-pointer"
          />
          <div className="flex justify-between text-[10px] text-[#7A8A80] mt-1 font-mono">
            <span>1 meal/wk</span>
            <span>7 meals/wk</span>
            <span>14 meals/wk</span>
          </div>
        </div>

        {/* Calculated Projection Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 font-mono">
          <div className="bg-white p-4 rounded-2xl border border-[#E8E2D5] text-center shadow-2xs">
            <span className="text-[10px] text-[#6B7C71] uppercase font-sans font-semibold block">Weekly Savings</span>
            <span className="text-xl sm:text-2xl font-extrabold text-[#192A20] block mt-1">
              {formatCurrency(weeklySavingPhp, settings.currency)}
            </span>
            <span className="text-[10px] text-[#8C9C92] font-sans">per week in groceries</span>
          </div>

          <div className="bg-white p-4 rounded-2xl border border-[#E8E2D5] text-center shadow-2xs">
            <span className="text-[10px] text-[#6B7C71] uppercase font-sans font-semibold block">Monthly Savings</span>
            <span className="text-xl sm:text-2xl font-extrabold text-[#192A20] block mt-1">
              {formatCurrency(monthlySavingPhp, settings.currency)}
            </span>
            <span className="text-[10px] text-[#8C9C92] font-sans">estimated month bank</span>
          </div>

          <div className="bg-[#EBF2ED] p-4 rounded-2xl border border-[#BFD4C6] text-center shadow-2xs">
            <span className="text-[10px] text-[#113826] uppercase font-sans font-bold block">Annual Savings</span>
            <span className="text-2xl sm:text-3xl font-extrabold text-[#113826] block mt-1">
              {formatCurrency(annualSavingPhp, settings.currency)}
            </span>
            <span className="text-[10px] text-[#3B5A47] font-sans font-semibold">retained per year!</span>
          </div>
        </div>
      </div>

      {/* Master Swaps Directory */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-bold text-[#192A20]">
            Master Ingredient Swap Directory
          </h2>
          <span className="text-xs text-[#6B7C71]">
            Prices converted to {settings.currency}
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {MASTER_SWAPS.map((swap) => {
            const savingsFormatted = formatCurrency(swap.savingsPhpPerServing, settings.currency);
            const originalFormatted = formatCurrency(swap.originalPriceEstimatePhp, settings.currency);
            const swapFormatted = formatCurrency(swap.swapPriceEstimatePhp, settings.currency);

            return (
              <div
                key={swap.id}
                className="bg-white border border-[#E8E2D5] rounded-2xl p-5 hover:border-[#113826]/40 transition-all flex flex-col justify-between shadow-xs"
              >
                <div>
                  <div className="flex items-center justify-between text-[11px] text-[#6B7C71] uppercase font-semibold mb-2">
                    <span>{swap.category}</span>
                    <span className="text-[#113826] font-bold">
                      Save {savingsFormatted}
                    </span>
                  </div>

                  {/* Before & After Row */}
                  <div className="bg-[#FAF7F0] p-3 rounded-xl border border-[#E5DFD3] mb-3">
                    <div className="flex items-center justify-between text-xs text-[#7A8A80]">
                      <span className="line-through">{swap.originalName}</span>
                      <span className="font-mono">{originalFormatted}</span>
                    </div>

                    <div className="flex items-center justify-center my-1 text-[#113826]">
                      <ArrowRight className="w-4 h-4" />
                    </div>

                    <div className="flex items-center justify-between text-xs font-bold text-[#113826]">
                      <span>{swap.swapName}</span>
                      <span className="font-mono">{swapFormatted}</span>
                    </div>
                  </div>

                  {/* Nutrition notes */}
                  <div className="text-xs text-[#3C4F42] mb-2 flex items-start gap-1.5">
                    <CheckCircle className="w-3.5 h-3.5 text-[#113826] shrink-0 mt-0.5" />
                    <p>{swap.proteinComparison}</p>
                  </div>

                  {/* Culinary Tip */}
                  <div className="text-[11px] text-[#64756A] italic bg-[#F7F5EE] p-2.5 rounded-lg border border-[#EDE7D9]">
                    <span className="font-semibold not-italic text-[#192A20]">Kitchen Tip: </span>
                    {swap.culinaryTip}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
