import React, { useState } from 'react';
import { 
  BookOpen, 
  Flame, 
  Sparkles, 
  ShieldCheck, 
  Refrigerator, 
  Utensils, 
  ChefHat, 
  CheckCircle2, 
  Lightbulb, 
  DollarSign,
  ChevronDown
} from 'lucide-react';

interface CookingTipsViewProps {
  onExploreRecipes: () => void;
}

export const CookingTipsView: React.FC<CookingTipsViewProps> = ({ onExploreRecipes }) => {
  const [activeCategory, setActiveCategory] = useState<string>('all');
  const [expandedTip, setExpandedTip] = useState<string | null>('knife-skills');

  const categories = [
    { id: 'all', label: 'All Guides' },
    { id: 'prep', label: 'Knife Skills & Prep' },
    { id: 'seasoning', label: 'Flavor & Seasoning' },
    { id: 'methods', label: 'Healthy Cooking Methods' },
    { id: 'safety', label: 'Food Safety & Storage' },
    { id: 'budget', label: 'Budget Grocery Secrets' }
  ];

  const tipsList = [
    {
      id: 'knife-skills',
      category: 'prep',
      icon: Utensils,
      title: 'Knife Safety & The Claw Grip',
      summary: 'Protect your fingertips and cut uniform slices for even cooking times.',
      details: [
        'Place a damp paper towel or non-slip mat under your cutting board so it never wobbles or slips.',
        'Use the "Claw Grip": Curl your non-knife fingertips inward like a tiger claw, resting the flat side of the knife blade against your knuckles.',
        'Peel fresh ginger with the edge of an ordinary teaspoon rather than a vegetable peeler. It navigates ginger’s bumpy knolls without wasting precious root.',
        'Uniform sizing: When dicing sayote, squash, or sweet potatoes, aim for 1/2-inch cubes so all pieces become tender at the exact same minute.'
      ]
    },
    {
      id: 'greens-prep',
      category: 'prep',
      icon: ChefHat,
      title: 'Handling Leafy Vegetables (Malunggay, Kangkong, Bok Choy)',
      summary: 'Keep greens crisp, vibrant emerald, and nutrient-packed.',
      details: [
        'De-stemming Malunggay (Moringa): Hold the woody stem at the top with one hand, and with the thumb and index finger of your other hand, slide downward along the branch. The tender leaves will strip right off in a second!',
        'Kangkong & Bok Choy stems cook slower than their tender leafy tops. Always separate stems from leaves: sauté or simmer stems 2 minutes first, then fold in leafy tops in the last 60 seconds.',
        'Residual Steam Technique: For delicate greens like malunggay and baby spinach, turn off the burner before adding them. Cover the pot with a tight lid; 2 minutes of trapped steam will gently wilt them while preserving vitamin C.'
      ]
    },
    {
      id: 'flavor-balancing',
      category: 'seasoning',
      icon: Sparkles,
      title: 'The 4 Pillars of Flavor: Salt, Acid, Sweetness & Umami',
      summary: 'How to make healthy, low-sodium dishes burst with restaurant-depth flavor.',
      details: [
        'Acid is the secret to cutting sodium: When a soup tastes "flat," beginners reach for salt. Instead, squeeze fresh calamansi or splash cane vinegar! Bright acidity lifts dull broths and activates tastebuds without raising blood pressure.',
        'Mellowing raw vinegar: In Filipino adobo and stews, never stir the vinegar immediately after pouring it into the hot pan. Let it simmer uncovered for 3-5 minutes so the harsh, pungent acetic vapor evaporates into a fragrant, mellow tang.',
        'Natural Sweetness without Sugar: Sauté yellow onions and ripe native tomatoes slowly over medium-low heat for 6-8 minutes until translucent. They naturally caramelize, providing sweetness to balance sour tamarind or bitter greens.',
        'Umami Depth: A single teaspoon of fish sauce (patis), fermented black beans, or dried mushroom broth adds more savory depth than multiple bullion cubes.'
      ]
    },
    {
      id: 'steam-fry',
      category: 'methods',
      icon: Flame,
      title: 'The "Steam-Fry" Technique (Minimal Oil Sautéing)',
      summary: 'Get the fragrant sear of stir-frying with only 1 teaspoon of oil.',
      details: [
        'Heat a non-stick skillet or wok with just 1 teaspoon of oil. Sauté your garlic, ginger, and sliced onions until aromatic (about 1 minute).',
        'Add hard vegetables (sayote, green beans, or carrots) and toss vigorously for 30 seconds.',
        'Splash in 2 to 3 tablespoons of water or chicken broth, then immediately cover with a tight lid for 2 minutes.',
        'The water flash-steams inside the pan, softening dense vegetables thoroughly while keeping them crisp and sealing in natural bright colors with minimal dietary fat.'
      ]
    },
    {
      id: 'protein-searing',
      category: 'methods',
      icon: Flame,
      title: 'Juicy Chicken Breast & Crispy Fish Skin',
      summary: 'Never eat dry chicken breast or soggy fish again.',
      details: [
        'The Dry-Skin Rule: Moisture is the enemy of crispiness! Always pat fish fillets and skinless chicken thoroughly dry with paper towels before seasoning.',
        'Preheat the skillet until a drop of water sizzles instantly. Place fish skin-side down and press gently with a flat spatula for 15 seconds to prevent curling.',
        'Leave it alone! Don’t poke or shuffle the protein. Meat naturally releases from the pan once a golden caramelized crust has formed.',
        'Rest before slicing: Always let cooked chicken breast or grilled inasal rest on a cutting board for 5 minutes before slicing. Cutting hot meat immediately drains all delicious savory juices.'
      ]
    },
    {
      id: 'food-safety',
      category: 'safety',
      icon: ShieldCheck,
      title: 'Temperature Danger Zone & Safe Thawing',
      summary: 'Protect your family and preserve food freshness safely.',
      details: [
        'The Danger Zone (4°C to 60°C / 40°F to 140°F): Harmful bacteria multiply rapidly in this temperature window. Never leave cooked food sitting at room temperature for more than 2 hours.',
        'Safe Thawing Methods: Never thaw frozen poultry or fish on the warm kitchen counter! Thaw overnight in the refrigerator, or seal in a leak-proof bag immersed in cold tap water.',
        'Cross-Contamination: Always dedicate one cutting board strictly for raw meats and seafood, and a separate board for produce and ready-to-eat foods.'
      ]
    },
    {
      id: 'storage-reheating',
      category: 'safety',
      icon: Refrigerator,
      title: 'Storage & Reheating Without Losing Moisture',
      summary: 'Keep meal-prep containers tasting like they were cooked 10 minutes ago.',
      details: [
        'Cool in Shallow Containers: Never place a huge, piping hot stockpot directly into the fridge; the center remains warm for hours, breeding bacteria. Divide leftovers into shallow glass containers so they cool uniformly.',
        'Shelf Life Rules: Cooked seafood lasts 2 days in the fridge. Cooked chicken, lean beef, and bean stews last 4-5 days. Hearty broths can be frozen for up to 3 months.',
        'The Damp Paper Towel Microwave Trick: When reheating cold brown rice or chicken breast in the microwave, drape a damp paper towel loosely over the dish. The steam keeps the rice fluffy and stops the poultry from turning into rubber.'
      ]
    },
    {
      id: 'budget-grocery',
      category: 'budget',
      icon: DollarSign,
      title: 'Wet-Market & Smart Grocery Budget Secrets',
      summary: 'Cut your weekly food bill by 30-40% while eating more nutritious whole foods.',
      details: [
        'Embrace Local Power Greens: Local Malunggay (moringa) and Kangkong (water spinach) provide far more vitamin C, iron, and calcium than expensive imported baby kale or spinach, at a fraction of the price.',
        'Choose Sustainable Local Fish: Local farmed Tilapia and fresh Bangus belly are packed with lean protein and Omega-3s. Use them instead of high-priced imported Atlantic salmon.',
        'Stretch Meat with Tofu & Lentils: In ground meat dishes like Picadillo, Tortang Talong, or Adobo, replace 50% of the ground meat with pressed firm tofu or cooked green lentils. It halves the cost, adds heart-healthy fiber, and soaks up seasonings.',
        'Batch Cook Dry Legumes: Buy dry mung beans and dry white beans in bulk. Cook a large batch on Sunday, portion into sandwich bags with cooking liquid, and freeze for rapid 5-minute weeknight dinners.'
      ]
    }
  ];

  const filteredTips = activeCategory === 'all' 
    ? tipsList 
    : tipsList.filter(t => t.category === activeCategory);

  return (
    <div className="space-y-8 animate-fadeIn max-w-4xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-bold text-[#113826] uppercase tracking-wider mb-1">
            <BookOpen className="w-4 h-4" />
            <span>FitBite Kitchen Culinary Academy</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-bold text-[#192A20] tracking-tight">
            Cooking Tips & Kitchen Skills
          </h1>
          <p className="text-xs sm:text-sm text-[#586A5F] mt-1 max-w-2xl">
            Practical beginner advice on knife handling, flavor balancing, healthy cooking methods, food safety, and stretching your grocery budget.
          </p>
        </div>

        <button
          type="button"
          onClick={onExploreRecipes}
          className="px-4 py-2.5 text-xs font-semibold rounded-xl bg-[#113826] hover:bg-[#1A4E37] text-white shadow-xs transition-colors self-start sm:self-auto shrink-0"
        >
          Explore Recipes →
        </button>
      </div>

      {/* Category Pills */}
      <div className="flex flex-wrap gap-1.5 p-1.5 bg-[#FAF7F0] border border-[#E8E2D5] rounded-2xl">
        {categories.map((c) => (
          <button
            key={c.id}
            type="button"
            onClick={() => setActiveCategory(c.id)}
            className={`px-3.5 py-2 text-xs font-semibold rounded-xl transition-all whitespace-nowrap ${
              activeCategory === c.id
                ? 'bg-[#113826] text-white shadow-xs'
                : 'text-[#4F6255] hover:text-[#192A20] hover:bg-white'
            }`}
          >
            {c.label}
          </button>
        ))}
      </div>

      {/* Guides List */}
      <div className="space-y-4">
        {filteredTips.map((tip) => {
          const isExpanded = expandedTip === tip.id;
          const Icon = tip.icon;

          return (
            <div
              key={tip.id}
              className="bg-white border border-[#E8E2D5] rounded-3xl overflow-hidden shadow-xs transition-all hover:border-[#113826]/40"
            >
              <div
                onClick={() => setExpandedTip(isExpanded ? null : tip.id)}
                className="p-5 sm:p-6 cursor-pointer flex items-start justify-between gap-4 select-none"
              >
                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 rounded-2xl bg-[#E8F0EB] text-[#113826] flex items-center justify-center shrink-0 mt-0.5">
                    <Icon className="w-5 h-5" />
                  </div>

                  <div>
                    <h3 className="text-base sm:text-lg font-bold text-[#192A20]">
                      {tip.title}
                    </h3>
                    <p className="text-xs text-[#586A5F] mt-0.5">
                      {tip.summary}
                    </p>
                  </div>
                </div>

                <div
                  className={`p-2 rounded-xl text-[#6B7C71] hover:bg-[#F2ECE1] transition-transform ${
                    isExpanded ? 'rotate-180 text-[#113826]' : ''
                  }`}
                >
                  <ChevronDown className="w-5 h-5" />
                </div>
              </div>

              {isExpanded && (
                <div className="px-5 pb-6 sm:px-6 pt-1 border-t border-[#F2ECE1] bg-[#FAF8F3] space-y-3">
                  <div className="space-y-2.5 pt-3">
                    {tip.details.map((detail, idx) => (
                      <div key={idx} className="flex items-start gap-3 text-xs sm:text-sm text-[#2C3E33] leading-relaxed">
                        <CheckCircle2 className="w-4 h-4 text-[#113826] shrink-0 mt-0.5" />
                        <p>{detail}</p>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Quick Action Box */}
      <div className="bg-[#EBF2ED] border border-[#CFDFD4] rounded-3xl p-6 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h3 className="text-sm font-bold text-[#113826]">
            Put these culinary skills to work today
          </h3>
          <p className="text-xs text-[#3E5547] mt-0.5">
            Browse our 22 sample Filipino and international healthy recipes, all configured with beginner tips and budget swaps.
          </p>
        </div>

        <button
          type="button"
          onClick={onExploreRecipes}
          className="px-4 py-2.5 text-xs font-semibold text-white bg-[#113826] rounded-xl hover:bg-[#1A4E37] transition-all whitespace-nowrap shadow-xs"
        >
          Browse Recipe Library →
        </button>
      </div>
    </div>
  );
};
