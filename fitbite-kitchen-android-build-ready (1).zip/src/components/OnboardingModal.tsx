import React, { useState } from 'react';
import { SUPPORTED_REGIONS } from '../data/regions';
import { CurrencyCode, UnitSystem, UserSettings, FitnessGoal, SecondaryInterest } from '../types';
import { Globe, Check, ChevronRight, Sparkles, Info, ArrowRight } from 'lucide-react';

interface OnboardingModalProps {
  currentSettings: UserSettings;
  onComplete: (updated: Partial<UserSettings>) => void;
  onSkip?: () => void;
}

interface PrimaryGoalOption {
  id: FitnessGoal;
  letter: string;
  title: string;
  description: string;
  badge: string;
}

const PRIMARY_GOALS: PrimaryGoalOption[] = [
  {
    id: 'calorie_deficit',
    letter: 'A',
    title: 'Calorie Deficit',
    description: 'Recipes that help you plan mindful, satisfying meals around a daily calorie target.',
    badge: 'Mindful Energy'
  },
  {
    id: 'omad',
    letter: 'B',
    title: 'OMAD (One Meal a Day)',
    description: 'Substantial, nutrient-dense recipes tailored for people who prefer a single daily feeding window.',
    badge: 'Nutrient-Dense'
  },
  {
    id: 'new_to_balanced',
    letter: 'C',
    title: 'New to Balanced Eating',
    description: 'Beginner-friendly recipes, simple nutrition guidance, and easy step-by-step cooking.',
    badge: 'Beginner Friendly'
  },
  {
    id: 'build_muscle',
    letter: 'D',
    title: 'Build Muscle',
    description: 'High-protein meals and power recipes designed to fuel strength training and muscle repair.',
    badge: 'High Protein'
  },
  {
    id: 'general_healthy',
    letter: 'E',
    title: 'General Healthy Eating',
    description: 'Varied, wholesome, and delicious home-cooked meals for everyday vitality and wellbeing.',
    badge: 'Everyday Wellness'
  }
];

const SECONDARY_INTERESTS: { id: SecondaryInterest; label: string }[] = [
  { id: 'budget_friendly', label: 'Budget-Friendly Cooking' },
  { id: 'vegetarian', label: 'Vegetarian Meals' },
  { id: 'weight_management', label: 'Weight Management' },
  { id: 'high_protein', label: 'High Protein Focus' },
  { id: 'quick_recipes', label: 'Quick Meals (< 30 min)' }
];

export const OnboardingModal: React.FC<OnboardingModalProps> = ({
  currentSettings,
  onComplete,
  onSkip
}) => {
  const [step, setStep] = useState<1 | 2>(1); // Step 1: Goals & Interests, Step 2: Region & Units
  const [selectedGoal, setSelectedGoal] = useState<FitnessGoal>(
    currentSettings.primaryGoal || 'general_healthy'
  );
  const [selectedInterests, setSelectedInterests] = useState<SecondaryInterest[]>(
    currentSettings.secondaryInterests || ['budget_friendly']
  );
  const [selectedRegionCode, setSelectedRegionCode] = useState(currentSettings.countryCode);
  const [selectedCurrency, setSelectedCurrency] = useState<CurrencyCode>(currentSettings.currency);
  const [selectedUnit, setSelectedUnit] = useState<UnitSystem>(currentSettings.unitSystem);

  const selectedRegion = SUPPORTED_REGIONS.find(r => r.code === selectedRegionCode) || SUPPORTED_REGIONS[0];

  const handleToggleInterest = (id: SecondaryInterest) => {
    setSelectedInterests(prev => 
      prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]
    );
  };

  const handleRegionSelect = (code: string) => {
    const region = SUPPORTED_REGIONS.find(r => r.code === code);
    if (region) {
      setSelectedRegionCode(code);
      setSelectedCurrency(region.currency);
      setSelectedUnit(region.defaultUnitSystem);
    }
  };

  const handleFinish = () => {
    onComplete({
      primaryGoal: selectedGoal,
      activeFitnessGoal: selectedGoal,
      secondaryInterests: selectedInterests,
      countryCode: selectedRegion.code,
      countryName: selectedRegion.name,
      currency: selectedCurrency,
      unitSystem: selectedUnit,
      hasCompletedOnboarding: true
    });
  };

  const handleQuickSkip = () => {
    onComplete({
      primaryGoal: 'general_healthy',
      activeFitnessGoal: 'general_healthy',
      secondaryInterests: ['budget_friendly'],
      hasCompletedOnboarding: true
    });
    if (onSkip) onSkip();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-[#0E2C1E]/80 backdrop-blur-sm animate-fadeIn">
      <div className="bg-[#FAF7F2] border border-[#EBE5D8] rounded-3xl max-w-xl w-full max-h-[92vh] overflow-y-auto shadow-2xl p-6 sm:p-8 flex flex-col justify-between">
        {step === 1 ? (
          /* Step 1: Goals & Personalization */
          <div className="space-y-6">
            {/* Header */}
            <div className="text-center">
              <div className="w-12 h-12 mx-auto mb-3 bg-[#113826] text-[#A3E635] rounded-2xl flex items-center justify-center shadow-xs">
                <Sparkles className="w-6 h-6 stroke-[2.2]" />
              </div>
              <h2 className="text-2xl sm:text-3xl font-extrabold text-[#15241C] tracking-tight">
                Eat Better. Cook Smarter. Reach Your Goals.
              </h2>
              <p className="text-xs sm:text-sm text-[#45584D] mt-1.5 font-medium">
                Welcome to FitBite Kitchen! What would you like help with?
              </p>
            </div>

            {/* Primary Goal Selector */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-[11px] font-bold text-[#15241C] uppercase tracking-wider block">
                  Choose Your Primary Goal
                </span>
                <span className="text-[10px] text-[#65A30D] font-bold">Step 1 of 2</span>
              </div>
              <div className="space-y-2">
                {PRIMARY_GOALS.map((goal) => {
                  const isSelected = selectedGoal === goal.id;
                  return (
                    <button
                      key={goal.id}
                      type="button"
                      onClick={() => setSelectedGoal(goal.id)}
                      className={`w-full text-left p-3.5 rounded-2xl border transition-all flex items-start gap-3 cursor-pointer ${
                        isSelected
                          ? 'bg-[#E8F3D6] border-[#65A30D] shadow-xs'
                          : 'bg-white border-[#E8E2D5] hover:border-[#113826]/40'
                      }`}
                    >
                      <div
                        className={`w-7 h-7 rounded-xl flex items-center justify-center font-bold text-xs shrink-0 mt-0.5 transition-colors ${
                          isSelected ? 'bg-[#113826] text-[#A3E635]' : 'bg-[#F3EFE6] text-[#55695C]'
                        }`}
                      >
                        {goal.letter}
                      </div>

                      <div className="min-w-0 flex-1">
                        <div className="flex items-center justify-between gap-2">
                          <h4 className="text-xs sm:text-sm font-bold text-[#15241C]">
                            {goal.title}
                          </h4>
                          <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-md border ${
                            isSelected ? 'bg-white text-[#113826] border-[#A3E635]' : 'bg-[#FAF7F2] text-[#64756A] border-[#E8E2D5]'
                          }`}>
                            {goal.badge}
                          </span>
                        </div>
                        <p className="text-[11px] text-[#45584D] mt-1 leading-relaxed">
                          {goal.description}
                        </p>
                      </div>

                      {isSelected && (
                        <Check className="w-4 h-4 text-[#65A30D] stroke-[3] shrink-0 mt-1" />
                      )}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Optional Secondary Interests */}
            <div>
              <span className="text-[11px] font-bold text-[#15241C] uppercase tracking-wider block mb-2">
                Secondary Interests (Optional)
              </span>
              <div className="flex flex-wrap gap-2">
                {SECONDARY_INTERESTS.map((item) => {
                  const isChecked = selectedInterests.includes(item.id);
                  return (
                    <button
                      key={item.id}
                      type="button"
                      onClick={() => handleToggleInterest(item.id)}
                      className={`px-3 py-1.5 text-xs font-semibold rounded-xl border transition-all cursor-pointer ${
                        isChecked
                          ? 'bg-[#113826] text-white border-[#113826] shadow-2xs'
                          : 'bg-white border-[#DDD5C7] text-[#45584D] hover:bg-[#FAF7F2]'
                      }`}
                    >
                      {isChecked ? '✓ ' : '+ '}
                      {item.label}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Gentle Nutrition & Fasting Note */}
            <div className="p-3.5 bg-[#FAF4E6] border border-[#EAE0C4] rounded-2xl flex items-start gap-2.5 text-[11px] text-[#5E4E28] leading-relaxed">
              <Info className="w-4 h-4 text-[#D97706] shrink-0 mt-0.5" />
              <p>
                <strong>Educational note:</strong> FitBite provides balanced meal suggestions and customizable targets. We never prescribe extreme calorie restriction. Fasting or strict deficits may not be suitable for pregnant or nursing individuals, teens, or those with certain medical conditions.
              </p>
            </div>

            {/* Footer Step 1 Controls */}
            <div className="pt-2 flex items-center justify-between gap-3">
              <button
                type="button"
                onClick={handleQuickSkip}
                className="text-xs font-semibold text-[#64756A] hover:text-[#15241C] underline cursor-pointer"
              >
                Skip for now
              </button>

              <button
                type="button"
                onClick={() => setStep(2)}
                className="px-6 py-2.5 text-xs sm:text-sm font-bold rounded-xl bg-[#113826] hover:bg-[#1A4E37] text-white shadow-xs transition-all flex items-center gap-1.5 cursor-pointer active:scale-95"
              >
                <span>Continue</span>
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        ) : (
          /* Step 2: Region, Currency, & Measurement Preferences */
          <div className="space-y-6">
            <div className="text-center">
              <div className="w-12 h-12 mx-auto mb-3 bg-[#E8F0EB] text-[#113826] rounded-2xl flex items-center justify-center">
                <Globe className="w-6 h-6 stroke-[2.2]" />
              </div>
              <h2 className="text-2xl sm:text-3xl font-extrabold text-[#15241C] tracking-tight">
                Where are you cooking?
              </h2>
              <p className="text-xs sm:text-sm text-[#45584D] mt-1.5 font-medium">
                We will localize estimated ingredient prices, currency, and cooking measurements.
              </p>
            </div>

            {/* Country / Region Picker */}
            <div>
              <label className="text-[11px] font-bold text-[#15241C] uppercase tracking-wider block mb-2">
                Select Your Region
              </label>
              <div className="grid grid-cols-2 gap-2 max-h-48 overflow-y-auto p-1 border border-[#E8E2D5] rounded-2xl bg-white">
                {SUPPORTED_REGIONS.map((region) => {
                  const isSelected = selectedRegionCode === region.code;
                  return (
                    <button
                      key={region.code}
                      type="button"
                      onClick={() => handleRegionSelect(region.code)}
                      className={`p-2.5 rounded-xl border text-left flex items-center justify-between text-xs transition-colors cursor-pointer ${
                        isSelected
                          ? 'bg-[#E8F3D6] border-[#65A30D] text-[#113826] font-bold'
                          : 'bg-white border-transparent hover:bg-[#FAF7F2] text-[#45584D]'
                      }`}
                    >
                      <span className="flex items-center gap-2 truncate">
                        <span className="text-base">{region.flag}</span>
                        <span className="truncate">{region.name}</span>
                      </span>
                      {isSelected && <Check className="w-3.5 h-3.5 text-[#65A30D] shrink-0" />}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Unit System Picker */}
            <div>
              <label className="text-[11px] font-bold text-[#15241C] uppercase tracking-wider block mb-2">
                Measurement Units
              </label>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => setSelectedUnit('metric')}
                  className={`p-3 rounded-2xl border text-xs font-semibold transition-all cursor-pointer ${
                    selectedUnit === 'metric'
                      ? 'bg-[#113826] text-white border-[#113826]'
                      : 'bg-white border-[#DDD5C7] text-[#45584D] hover:bg-[#FAF7F2]'
                  }`}
                >
                  Metric (g, ml, kg)
                </button>
                <button
                  type="button"
                  onClick={() => setSelectedUnit('us_customary')}
                  className={`p-3 rounded-2xl border text-xs font-semibold transition-all cursor-pointer ${
                    selectedUnit === 'us_customary'
                      ? 'bg-[#113826] text-white border-[#113826]'
                      : 'bg-white border-[#DDD5C7] text-[#45584D] hover:bg-[#FAF7F2]'
                  }`}
                >
                  US / Imperial (oz, cups, lb)
                </button>
              </div>
            </div>

            {/* Footer Step 2 Controls */}
            <div className="pt-4 flex items-center justify-between gap-3 border-t border-[#E8E2D5]">
              <button
                type="button"
                onClick={() => setStep(1)}
                className="text-xs font-semibold text-[#64756A] hover:text-[#15241C] cursor-pointer"
              >
                ← Back
              </button>

              <button
                type="button"
                onClick={handleFinish}
                className="px-6 py-2.5 text-xs sm:text-sm font-bold rounded-xl bg-[#113826] hover:bg-[#1A4E37] text-white shadow-md transition-all flex items-center gap-1.5 cursor-pointer active:scale-95"
              >
                <span>Build My Plan</span>
                <ArrowRight className="w-4 h-4 stroke-[2.5]" />
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
