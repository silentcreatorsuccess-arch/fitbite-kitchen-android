import React, { useState } from 'react';
import { UserSettings, LoggedMealEntry, MealType, Recipe } from '../types';
import { Flame, Plus, Trash2, Edit2, ChevronLeft, ChevronRight, Check } from 'lucide-react';

interface CalorieTrackerViewProps {
  settings: UserSettings;
  loggedMeals: LoggedMealEntry[];
  recipes: Recipe[];
  onAddMealEntry: (entry: Omit<LoggedMealEntry, 'id'>) => void;
  onUpdateMealEntry: (id: string, updated: Partial<LoggedMealEntry>) => void;
  onDeleteMealEntry: (id: string) => void;
  onUpdateDailyTarget: (newTargetKcal: number) => void;
}

export const CalorieTrackerView: React.FC<CalorieTrackerViewProps> = ({
  settings,
  loggedMeals,
  recipes,
  onAddMealEntry,
  onUpdateMealEntry,
  onDeleteMealEntry,
  onUpdateDailyTarget
}) => {
  const [selectedDate, setSelectedDate] = useState<string>(
    new Date().toISOString().split('T')[0]
  );
  const [isCustomFoodModalOpen, setIsCustomFoodModalOpen] = useState(false);
  const [isEditingTarget, setIsEditingTarget] = useState(false);
  const [targetInput, setTargetInput] = useState(settings.dailyCalorieTarget.toString());

  // Form states for adding custom food
  const [customName, setCustomName] = useState('');
  const [customMealType, setCustomMealType] = useState<MealType>('lunch');
  const [customCalories, setCustomCalories] = useState('250');
  const [customProtein, setCustomProtein] = useState('20');
  const [customCarbs, setCustomCarbs] = useState('25');
  const [customFat, setCustomFat] = useState('8');
  const [customServings, setCustomServings] = useState('1');
  const [formError, setFormError] = useState('');

  // Selected date's logs
  const dayMeals = loggedMeals.filter(m => m.dateString === selectedDate);
  const totalCalories = dayMeals.reduce((acc, m) => acc + m.calories, 0);
  const totalProtein = dayMeals.reduce((acc, m) => acc + m.proteinGrams, 0);
  const totalCarbs = dayMeals.reduce((acc, m) => acc + m.carbsGrams, 0);
  const totalFat = dayMeals.reduce((acc, m) => acc + m.fatGrams, 0);

  const caloriePercentage = Math.min(100, Math.round((totalCalories / settings.dailyCalorieTarget) * 100));
  const remainingCalories = Math.max(0, settings.dailyCalorieTarget - totalCalories);

  // Date navigation
  const handlePrevDay = () => {
    const d = new Date(selectedDate);
    d.setDate(d.getDate() - 1);
    setSelectedDate(d.toISOString().split('T')[0]);
  };

  const handleNextDay = () => {
    const d = new Date(selectedDate);
    d.setDate(d.getDate() + 1);
    setSelectedDate(d.toISOString().split('T')[0]);
  };

  const handleSaveTarget = () => {
    const val = parseInt(targetInput, 10);
    if (!isNaN(val) && val >= 1000 && val <= 6000) {
      onUpdateDailyTarget(val);
      setIsEditingTarget(false);
    }
  };

  const handleAddCustomSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customName.trim()) {
      setFormError('Please enter a food name');
      return;
    }
    const cal = parseFloat(customCalories);
    const p = parseFloat(customProtein) || 0;
    const c = parseFloat(customCarbs) || 0;
    const f = parseFloat(customFat) || 0;
    const s = parseFloat(customServings) || 1;

    if (isNaN(cal) || cal < 0) {
      setFormError('Please enter a valid calorie amount');
      return;
    }

    onAddMealEntry({
      timestamp: new Date().toISOString(),
      dateString: selectedDate,
      mealType: customMealType,
      foodName: customName.trim(),
      servings: s,
      calories: Math.round(cal * s),
      proteinGrams: Math.round(p * s),
      carbsGrams: Math.round(c * s),
      fatGrams: Math.round(f * s)
    });

    setCustomName('');
    setFormError('');
    setIsCustomFoodModalOpen(false);
  };

  const mealSections: { type: MealType; label: string }[] = [
    { type: 'breakfast', label: 'Breakfast' },
    { type: 'lunch', label: 'Lunch' },
    { type: 'dinner', label: 'Dinner' },
    { type: 'snack', label: 'Snacks' }
  ];

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Date Switcher & Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-[#192A20] tracking-tight">
            Calorie & Macro Tracker
          </h1>
          <p className="text-xs sm:text-sm text-[#586A5F] mt-0.5">
            Log your daily nourishing meals, monitor balanced energy, and adjust targets.
          </p>
        </div>

        {/* Date Selector */}
        <div className="flex items-center gap-2 self-start sm:self-auto bg-white border border-[#DDD5C7] rounded-xl px-2 py-1 shadow-2xs">
          <button
            type="button"
            onClick={handlePrevDay}
            className="p-1 rounded-lg hover:bg-[#F2ECE1] text-[#4F6255]"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>
          <span className="text-xs font-bold font-mono text-[#192A20] px-2">
            {selectedDate === new Date().toISOString().split('T')[0] ? 'Today' : selectedDate}
          </span>
          <button
            type="button"
            onClick={handleNextDay}
            className="p-1 rounded-lg hover:bg-[#F2ECE1] text-[#4F6255]"
          >
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Main Stats Card */}
      <div className="bg-white border border-[#E8E2D5] rounded-3xl p-6 shadow-xs">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6 pb-6 border-b border-[#F2ECE1]">
          {/* Calorie Progress */}
          <div className="flex-1 w-full">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-bold text-[#192A20] uppercase tracking-wider flex items-center gap-1.5">
                <Flame className="w-4 h-4 text-[#C46820]" />
                Energy Balance
              </span>

              {isEditingTarget ? (
                <div className="flex items-center gap-1">
                  <input
                    type="number"
                    value={targetInput}
                    onChange={(e) => setTargetInput(e.target.value)}
                    className="w-20 px-2 py-0.5 text-xs font-mono border border-[#113826] rounded text-right"
                  />
                  <button
                    type="button"
                    onClick={handleSaveTarget}
                    className="p-1 bg-[#113826] text-white rounded hover:bg-[#1A4E37]"
                  >
                    <Check className="w-3.5 h-3.5" />
                  </button>
                </div>
              ) : (
                <button
                  type="button"
                  onClick={() => setIsEditingTarget(true)}
                  className="text-xs font-medium text-[#5B6F62] hover:text-[#113826] flex items-center gap-1"
                >
                  <span>Target: {settings.dailyCalorieTarget} kcal</span>
                  <Edit2 className="w-3 h-3" />
                </button>
              )}
            </div>

            <div className="flex items-baseline gap-2 mb-2">
              <span className="text-4xl font-extrabold text-[#192A20] font-mono tabular-nums">
                {totalCalories}
              </span>
              <span className="text-xs text-[#6B7C71] font-mono">
                / {settings.dailyCalorieTarget} kcal consumed
              </span>
            </div>

            {/* Progress bar in fresh lime green */}
            <div className="w-full h-3 bg-[#F2ECE1] rounded-full overflow-hidden mb-2">
              <div
                className="h-full bg-[#65A30D] rounded-full transition-all duration-500"
                style={{ width: `${caloriePercentage}%` }}
              />
            </div>

            <div className="flex items-center justify-between text-xs text-[#526458]">
              <span>{remainingCalories} kcal left</span>
              <span className="font-semibold text-[#113826]">{caloriePercentage}% of goal</span>
            </div>
          </div>

          {/* Macro Breakdown */}
          <div className="grid grid-cols-3 gap-3 w-full md:w-auto shrink-0 font-mono">
            <div className="bg-[#FAF7F0] p-3 rounded-2xl border border-[#E5DFD3] text-center min-w-[90px]">
              <span className="text-[10px] text-[#6B7C71] block font-sans font-semibold uppercase">Protein</span>
              <span className="text-lg font-bold text-[#192A20] block mt-0.5">{totalProtein}g</span>
              <span className="text-[9px] text-[#8C9C92]">{Math.round((totalProtein * 4 / (totalCalories || 1)) * 100)}%</span>
            </div>
            <div className="bg-[#FAF7F0] p-3 rounded-2xl border border-[#E5DFD3] text-center min-w-[90px]">
              <span className="text-[10px] text-[#6B7C71] block font-sans font-semibold uppercase">Carbs</span>
              <span className="text-lg font-bold text-[#192A20] block mt-0.5">{totalCarbs}g</span>
              <span className="text-[9px] text-[#8C9C92]">{Math.round((totalCarbs * 4 / (totalCalories || 1)) * 100)}%</span>
            </div>
            <div className="bg-[#FAF7F0] p-3 rounded-2xl border border-[#E5DFD3] text-center min-w-[90px]">
              <span className="text-[10px] text-[#6B7C71] block font-sans font-semibold uppercase">Fat</span>
              <span className="text-lg font-bold text-[#192A20] block mt-0.5">{totalFat}g</span>
              <span className="text-[9px] text-[#8C9C92]">{Math.round((totalFat * 9 / (totalCalories || 1)) * 100)}%</span>
            </div>
          </div>
        </div>

        {/* Quick Add Custom Food Action */}
        <div className="mt-4 flex items-center justify-between">
          <span className="text-xs text-[#6B7C71]">
            Track your meals consistently without strict restrictions
          </span>
          <button
            type="button"
            onClick={() => setIsCustomFoodModalOpen(true)}
            className="px-4 py-2 text-xs font-semibold rounded-xl bg-[#113826] text-white hover:bg-[#1A4E37] transition-all flex items-center gap-1.5 shadow-2xs"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Add Custom Food</span>
          </button>
        </div>
      </div>

      {/* Logged Meals List by Section */}
      <div className="space-y-4">
        {mealSections.map((sec) => {
          const sectionMeals = dayMeals.filter(m => m.mealType === sec.type);
          const sectionCalories = sectionMeals.reduce((acc, m) => acc + m.calories, 0);

          return (
            <div key={sec.type} className="bg-white border border-[#E8E2D5] rounded-2xl overflow-hidden shadow-xs">
              <div className="bg-[#FAF7F0] px-4 py-3 border-b border-[#E8E2D5] flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <h3 className="text-xs font-bold text-[#192A20] uppercase tracking-wider">
                    {sec.label}
                  </h3>
                  <span className="text-[11px] font-mono text-[#6B7C71]">
                    ({sectionCalories} kcal)
                  </span>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    setCustomMealType(sec.type);
                    setIsCustomFoodModalOpen(true);
                  }}
                  className="text-xs font-semibold text-[#113826] hover:underline flex items-center gap-1"
                >
                  <Plus className="w-3 h-3" />
                  <span>Add Food</span>
                </button>
              </div>

              {sectionMeals.length === 0 ? (
                <div className="py-4 text-center text-xs text-[#8C9C92]">
                  No items logged for {sec.label.toLowerCase()}
                </div>
              ) : (
                <div className="divide-y divide-[#F2ECE1]">
                  {sectionMeals.map((meal) => (
                    <div
                      key={meal.id}
                      className="p-3 sm:px-4 flex items-center justify-between gap-3 text-xs"
                    >
                      <div className="min-w-0">
                        <span className="font-semibold text-[#192A20] block truncate">
                          {meal.foodName}
                        </span>
                        <span className="text-[11px] text-[#64756A] font-mono tabular-nums">
                          {meal.servings} serving · {meal.proteinGrams}g P · {meal.carbsGrams}g C · {meal.fatGrams}g F
                        </span>
                      </div>

                      <div className="flex items-center gap-3 shrink-0">
                        <span className="font-mono font-bold text-[#192A20]">
                          {meal.calories} kcal
                        </span>
                        <button
                          type="button"
                          onClick={() => onDeleteMealEntry(meal.id)}
                          className="p-1.5 text-[#8C9C92] hover:text-[#B83828] rounded-lg transition-colors"
                          title="Delete entry"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Add Custom Food Modal */}
      {isCustomFoodModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#11241A]/70 backdrop-blur-sm animate-fadeIn">
          <div className="bg-[#FAF7F0] border border-[#E2DBD0] rounded-3xl max-w-md w-full p-6 shadow-2xl">
            <h3 className="text-lg font-bold text-[#192A20] mb-1">
              Add Food or Custom Meal
            </h3>
            <p className="text-xs text-[#586A5F] mb-4">
              Enter nutritional details for your meal.
            </p>

            {formError && (
              <div className="mb-4 p-2.5 bg-[#FDECEB] border border-[#F5C2C0] rounded-xl text-xs text-[#A82B24]">
                {formError}
              </div>
            )}

            <form onSubmit={handleAddCustomSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-[#192A20] uppercase tracking-wider mb-1">
                  Food Name
                </label>
                <input
                  type="text"
                  value={customName}
                  onChange={(e) => setCustomName(e.target.value)}
                  placeholder="e.g. Grilled Chicken Rice Bowl"
                  className="w-full p-2.5 bg-white border border-[#DDD5C7] rounded-xl text-xs text-[#192A20]"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-[#192A20] uppercase tracking-wider mb-1">
                    Meal Type
                  </label>
                  <select
                    value={customMealType}
                    onChange={(e) => setCustomMealType(e.target.value as MealType)}
                    className="w-full p-2.5 bg-white border border-[#DDD5C7] rounded-xl text-xs text-[#192A20]"
                  >
                    <option value="breakfast">Breakfast</option>
                    <option value="lunch">Lunch</option>
                    <option value="dinner">Dinner</option>
                    <option value="snack">Snack</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#192A20] uppercase tracking-wider mb-1">
                    Servings
                  </label>
                  <input
                    type="number"
                    step="0.5"
                    min="0.5"
                    value={customServings}
                    onChange={(e) => setCustomServings(e.target.value)}
                    className="w-full p-2.5 bg-white border border-[#DDD5C7] rounded-xl text-xs text-[#192A20]"
                  />
                </div>
              </div>

              <div className="grid grid-cols-4 gap-2">
                <div>
                  <label className="block text-[10px] font-semibold text-[#192A20] uppercase mb-1">
                    Calories
                  </label>
                  <input
                    type="number"
                    value={customCalories}
                    onChange={(e) => setCustomCalories(e.target.value)}
                    className="w-full p-2 bg-white border border-[#DDD5C7] rounded-xl text-xs font-mono text-[#192A20]"
                  />
                </div>

                <div>
                  <label className="block text-[10px] font-semibold text-[#192A20] uppercase mb-1">
                    Protein (g)
                  </label>
                  <input
                    type="number"
                    value={customProtein}
                    onChange={(e) => setCustomProtein(e.target.value)}
                    className="w-full p-2 bg-white border border-[#DDD5C7] rounded-xl text-xs font-mono text-[#192A20]"
                  />
                </div>

                <div>
                  <label className="block text-[10px] font-semibold text-[#192A20] uppercase mb-1">
                    Carbs (g)
                  </label>
                  <input
                    type="number"
                    value={customCarbs}
                    onChange={(e) => setCustomCarbs(e.target.value)}
                    className="w-full p-2 bg-white border border-[#DDD5C7] rounded-xl text-xs font-mono text-[#192A20]"
                  />
                </div>

                <div>
                  <label className="block text-[10px] font-semibold text-[#192A20] uppercase mb-1">
                    Fat (g)
                  </label>
                  <input
                    type="number"
                    value={customFat}
                    onChange={(e) => setCustomFat(e.target.value)}
                    className="w-full p-2 bg-white border border-[#DDD5C7] rounded-xl text-xs font-mono text-[#192A20]"
                  />
                </div>
              </div>

              <div className="pt-2 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsCustomFoodModalOpen(false)}
                  className="px-4 py-2 text-xs font-semibold rounded-xl bg-white border border-[#DDD5C7] text-[#586A5F]"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 text-xs font-semibold rounded-xl bg-[#113826] text-white hover:bg-[#1A4E37]"
                >
                  Add Entry
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
