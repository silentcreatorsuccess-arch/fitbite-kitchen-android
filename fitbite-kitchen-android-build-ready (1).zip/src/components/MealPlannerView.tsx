import React, { useState } from 'react';
import { Recipe, UserSettings, MealPlanItem, MealType, ShoppingListItem, IngredientCategory } from '../types';
import { formatCurrency } from '../utils/currency';
import { formatIngredientQuantity } from '../utils/units';
import { Plus, Trash2, Calendar, ShoppingBag, Check, CheckSquare, Square, Flame, Copy, CheckCircle2 } from 'lucide-react';

interface MealPlannerViewProps {
  recipes: Recipe[];
  settings: UserSettings;
  mealPlan: MealPlanItem[];
  shoppingList: ShoppingListItem[];
  onAddMealToPlan: (item: Omit<MealPlanItem, 'id'>) => void;
  onRemoveMealFromPlan: (id: string) => void;
  onUpdateShoppingList: (items: ShoppingListItem[]) => void;
  onSelectRecipe: (recipe: Recipe) => void;
}

const DAYS_OF_WEEK = [
  { index: 0, short: 'Mon', full: 'Monday' },
  { index: 1, short: 'Tue', full: 'Tuesday' },
  { index: 2, short: 'Wed', full: 'Wednesday' },
  { index: 3, short: 'Thu', full: 'Thursday' },
  { index: 4, short: 'Fri', full: 'Friday' },
  { index: 5, short: 'Sat', full: 'Saturday' },
  { index: 6, short: 'Sun', full: 'Sunday' }
];

const MEAL_SLOTS: { type: MealType; label: string }[] = [
  { type: 'breakfast', label: 'Breakfast' },
  { type: 'lunch', label: 'Lunch' },
  { type: 'dinner', label: 'Dinner' },
  { type: 'snack', label: 'Snack' }
];

export const MealPlannerView: React.FC<MealPlannerViewProps> = ({
  recipes,
  settings,
  mealPlan,
  shoppingList,
  onAddMealToPlan,
  onRemoveMealFromPlan,
  onUpdateShoppingList,
  onSelectRecipe
}) => {
  // Current day index 0-6
  const todayIndex = (new Date().getDay() + 6) % 7;
  const [selectedDayIndex, setSelectedDayIndex] = useState<number>(todayIndex);
  const [activeTab, setActiveTab] = useState<'schedule' | 'shopping'>('schedule');
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [targetSlot, setTargetSlot] = useState<MealType>('lunch');
  const [selectedRecipeIdToAdd, setSelectedRecipeIdToAdd] = useState<string>(recipes[0]?.id || '');
  const [copiedNotification, setCopiedNotification] = useState(false);

  // Filter meals for the selected day
  const dayMeals = mealPlan.filter(m => m.dayIndex === selectedDayIndex);
  const dayCalories = dayMeals.reduce((acc, m) => acc + m.calories, 0);
  const dayCostPhp = dayMeals.reduce((acc, m) => acc + m.costPhp, 0);

  // Generate Shopping list from all meals currently in the planner
  const generateShoppingListFromPlan = () => {
    const ingredientMap: Record<string, {
      name: string;
      category: IngredientCategory;
      amountMetric: number;
      unitMetric: string;
      amountCustomary: number;
      unitCustomary: string;
      costPhp: number;
      recipes: Set<string>;
    }> = {};

    mealPlan.forEach((planItem) => {
      const recipe = recipes.find(r => r.id === planItem.recipeId);
      if (!recipe) return;

      const scale = planItem.servings / recipe.servings;

      recipe.ingredients.forEach((ing) => {
        const key = ing.name.toLowerCase().trim();
        const customPhp = settings.customIngredientPrices[ing.id];
        const baseCost = customPhp !== undefined ? customPhp : ing.estimatedCostPhp;
        const ingCost = (baseCost / recipe.servings) * planItem.servings;

        if (!ingredientMap[key]) {
          ingredientMap[key] = {
            name: ing.name,
            category: ing.category,
            amountMetric: ing.amountMetric * scale,
            unitMetric: ing.unitMetric,
            amountCustomary: ing.amountCustomary * scale,
            unitCustomary: ing.unitCustomary,
            costPhp: ingCost,
            recipes: new Set([recipe.title])
          };
        } else {
          ingredientMap[key].amountMetric += ing.amountMetric * scale;
          ingredientMap[key].amountCustomary += ing.amountCustomary * scale;
          ingredientMap[key].costPhp += ingCost;
          ingredientMap[key].recipes.add(recipe.title);
        }
      });
    });

    const newList: ShoppingListItem[] = Object.entries(ingredientMap).map(([key, data], idx) => ({
      id: `shop-${idx}-${Date.now()}`,
      name: data.name,
      category: data.category,
      quantityMetric: `${Math.round(data.amountMetric * 10) / 10} ${data.unitMetric}`,
      quantityCustomary: `${Math.round(data.amountCustomary * 10) / 10} ${data.unitCustomary}`,
      estimatedCostPhp: Math.round(data.costPhp),
      checked: false,
      fromRecipes: Array.from(data.recipes)
    }));

    onUpdateShoppingList(newList);
    setActiveTab('shopping');
  };

  const toggleShoppingItem = (id: string) => {
    const updated = shoppingList.map(item => 
      item.id === id ? { ...item, checked: !item.checked } : item
    );
    onUpdateShoppingList(updated);
  };

  const handleOpenAddModal = (slot: MealType) => {
    setTargetSlot(slot);
    setIsAddModalOpen(true);
  };

  const handleConfirmAddMeal = () => {
    const recipe = recipes.find(r => r.id === selectedRecipeIdToAdd);
    if (!recipe) return;

    onAddMealToPlan({
      dayIndex: selectedDayIndex,
      mealType: targetSlot,
      recipeId: recipe.id,
      recipeTitle: recipe.title,
      servings: 1,
      calories: recipe.calories,
      costPhp: recipe.baseCostPhp
    });

    setIsAddModalOpen(false);
  };

  const copyShoppingListToClipboard = () => {
    const lines = shoppingList.map(item => 
      `${item.checked ? '[x]' : '[ ]'} ${item.name} (${settings.unitSystem === 'metric' ? item.quantityMetric : item.quantityCustomary}) - ${formatCurrency(item.estimatedCostPhp, settings.currency)}`
    );
    const text = `FitBite Kitchen Grocery List:\n\n${lines.join('\n')}`;
    navigator.clipboard.writeText(text);
    setCopiedNotification(true);
    setTimeout(() => setCopiedNotification(false), 2000);
  };

  // Group shopping list items by category
  const categoryLabels: Record<IngredientCategory, string> = {
    produce: 'Fresh Produce & Greens',
    meat_seafood: 'Meat, Seafood & Tofu',
    pantry_grains: 'Grains & Pantry Staples',
    dairy_alt: 'Dairy & Alternatives',
    seasoning_oil: 'Oils & Seasonings'
  };

  const shoppingTotalPhp = shoppingList.reduce((acc, item) => acc + item.estimatedCostPhp, 0);

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Top Banner & Mode Toggle */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-[#192A20] tracking-tight">
            Meal Planner & Grocery List
          </h1>
          <p className="text-xs sm:text-sm text-[#586A5F] mt-0.5">
            Plan your weekly healthy dishes and automatically generate an organized shopping list.
          </p>
        </div>

        {/* Schedule vs Shopping List Tabs */}
        <div className="flex items-center gap-1 p-1 bg-[#EBE7DC] rounded-xl self-start sm:self-auto border border-[#DDD5C7]">
          <button
            type="button"
            onClick={() => setActiveTab('schedule')}
            className={`px-4 py-1.5 text-xs font-semibold rounded-lg transition-colors flex items-center gap-1.5 ${
              activeTab === 'schedule'
                ? 'bg-white text-[#113826] shadow-xs'
                : 'text-[#586A5F] hover:text-[#192A20]'
            }`}
          >
            <Calendar className="w-3.5 h-3.5" />
            <span>Weekly Schedule</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('shopping')}
            className={`px-4 py-1.5 text-xs font-semibold rounded-lg transition-colors flex items-center gap-1.5 ${
              activeTab === 'shopping'
                ? 'bg-white text-[#113826] shadow-xs'
                : 'text-[#586A5F] hover:text-[#192A20]'
            }`}
          >
            <ShoppingBag className="w-3.5 h-3.5" />
            <span>Shopping List ({shoppingList.length})</span>
          </button>
        </div>
      </div>

      {activeTab === 'schedule' ? (
        <div className="space-y-6">
          {/* Day of Week Selector Bar */}
          <div className="grid grid-cols-7 gap-1.5 sm:gap-2">
            {DAYS_OF_WEEK.map((d) => {
              const isSelected = selectedDayIndex === d.index;
              const isToday = todayIndex === d.index;
              const mealsCount = mealPlan.filter(m => m.dayIndex === d.index).length;

              return (
                <button
                  key={d.index}
                  type="button"
                  onClick={() => setSelectedDayIndex(d.index)}
                  className={`py-3 px-1 sm:px-3 rounded-2xl border text-center transition-all ${
                    isSelected
                      ? 'bg-[#113826] text-white border-[#113826] shadow-sm'
                      : 'bg-white text-[#384A3E] border-[#E5DFD3] hover:border-[#113826]/40'
                  }`}
                >
                  <span className={`text-[10px] font-bold block uppercase tracking-wider ${isSelected ? 'text-[#A3E635]' : 'text-[#7A8A80]'}`}>
                    {d.short}
                  </span>
                  <span className="text-sm sm:text-base font-extrabold block mt-0.5">
                    {d.index + 1}
                  </span>
                  {mealsCount > 0 && (
                    <span className={`text-[9px] block mt-1 font-mono ${isSelected ? 'text-white' : 'text-[#113826] font-semibold'}`}>
                      {mealsCount} meal{mealsCount > 1 ? 's' : ''}
                    </span>
                  )}
                  {isToday && (
                    <span className={`text-[8px] font-bold block uppercase mt-0.5 ${isSelected ? 'text-[#F9D678]' : 'text-[#B85D19]'}`}>
                      Today
                    </span>
                  )}
                </button>
              );
            })}
          </div>

          {/* Day Totals Summary */}
          <div className="bg-[#FAF7F0] border border-[#E5DFD3] rounded-2xl p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs">
            <div className="flex items-center gap-4">
              <span className="font-bold text-[#192A20] text-sm">
                {DAYS_OF_WEEK.find(d => d.index === selectedDayIndex)?.full} Totals
              </span>
              <span className="font-mono tabular-nums text-[#586A5F] flex items-center gap-1">
                <Flame className="w-3.5 h-3.5 text-[#B85D19]" />
                {dayCalories} kcal
              </span>
              <span className="font-mono tabular-nums text-[#113826] font-bold">
                {formatCurrency(dayCostPhp, settings.currency)} estimated
              </span>
            </div>

            <button
              type="button"
              onClick={generateShoppingListFromPlan}
              className="px-3.5 py-1.5 text-xs font-semibold rounded-xl bg-[#113826] text-white hover:bg-[#1A4E37] transition-all flex items-center gap-1.5 shadow-xs"
            >
              <ShoppingBag className="w-3.5 h-3.5" />
              <span>Generate Shopping List from Plan</span>
            </button>
          </div>

          {/* Meal Slots (Breakfast, Lunch, Dinner, Snack) */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {MEAL_SLOTS.map((slot) => {
              const slotMeals = dayMeals.filter(m => m.mealType === slot.type);

              return (
                <div
                  key={slot.type}
                  className="bg-white border border-[#E8E2D5] rounded-2xl p-4 sm:p-5 flex flex-col justify-between"
                >
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-xs font-bold text-[#192A20] uppercase tracking-wider">
                      {slot.label}
                    </span>
                    <button
                      type="button"
                      onClick={() => handleOpenAddModal(slot.type)}
                      className="text-xs font-semibold text-[#113826] hover:underline flex items-center gap-1"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      <span>Add Recipe</span>
                    </button>
                  </div>

                  {slotMeals.length === 0 ? (
                    <div className="py-6 text-center text-xs text-[#7A8A80] bg-[#FAF8F2] rounded-xl border border-dashed border-[#DDD5C7]">
                      <p>No dish planned for {slot.label.toLowerCase()}</p>
                      <button
                        type="button"
                        onClick={() => handleOpenAddModal(slot.type)}
                        className="mt-1.5 text-xs font-semibold text-[#113826] hover:underline"
                      >
                        + Select from Recipe Library
                      </button>
                    </div>
                  ) : (
                    <div className="space-y-2">
                      {slotMeals.map((meal) => {
                        const targetRecipe = recipes.find(r => r.id === meal.recipeId);
                        return (
                          <div
                            key={meal.id}
                            className="p-3 bg-[#FAF7F0] border border-[#E5DFD3] rounded-xl flex items-center justify-between gap-2 text-xs group"
                          >
                            <div className="min-w-0">
                              <h4
                                onClick={() => targetRecipe && onSelectRecipe(targetRecipe)}
                                className="font-bold text-[#192A20] truncate cursor-pointer hover:text-[#113826]"
                              >
                                {meal.recipeTitle}
                              </h4>
                              <p className="text-[11px] text-[#64756A] font-mono tabular-nums mt-0.5">
                                {meal.calories} kcal · {formatCurrency(meal.costPhp, settings.currency)}
                              </p>
                            </div>

                            <button
                              type="button"
                              onClick={() => onRemoveMealFromPlan(meal.id)}
                              title="Remove from meal plan"
                              className="p-1.5 text-[#8C9C92] hover:text-[#B83828] hover:bg-white rounded-lg transition-colors"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      ) : (
        /* Shopping List View */
        <div className="space-y-6">
          <div className="bg-[#FAF7F0] border border-[#E5DFD3] rounded-2xl p-5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div>
              <span className="text-xs font-bold text-[#5A6D60] uppercase tracking-wider block mb-1">
                Total Estimated Grocery Budget
              </span>
              <p className="text-2xl sm:text-3xl font-extrabold text-[#113826] font-mono tabular-nums">
                {formatCurrency(shoppingTotalPhp, settings.currency)}
              </p>
              <p className="text-xs text-[#7A8A80] mt-0.5">
                Calculated across {shoppingList.length} items from your planned meals. Prices are local estimates.
              </p>
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={copyShoppingListToClipboard}
                className="px-3.5 py-2 text-xs font-semibold rounded-xl bg-white border border-[#DDD5C7] text-[#192A20] hover:bg-[#F2ECE1] transition-colors flex items-center gap-1.5 shadow-2xs"
              >
                {copiedNotification ? <CheckCircle2 className="w-4 h-4 text-[#113826]" /> : <Copy className="w-4 h-4" />}
                <span>{copiedNotification ? 'Copied to Clipboard!' : 'Copy List'}</span>
              </button>

              <button
                type="button"
                onClick={generateShoppingListFromPlan}
                className="px-3.5 py-2 text-xs font-semibold rounded-xl bg-[#113826] text-white hover:bg-[#1A4E37] transition-colors flex items-center gap-1.5 shadow-2xs"
              >
                <span>Re-generate from Plan</span>
              </button>
            </div>
          </div>

          {shoppingList.length === 0 ? (
            <div className="bg-white border border-[#E8E2D5] rounded-3xl p-10 text-center max-w-md mx-auto">
              <ShoppingBag className="w-12 h-12 mx-auto mb-3 text-[#A0B0A5]" />
              <h3 className="text-base font-bold text-[#192A20]">Your shopping list is empty</h3>
              <p className="text-xs text-[#6B7C71] mt-1">
                Add recipes to your weekly schedule, then click "Generate Shopping List from Plan" to build your grocery checklist.
              </p>
              <button
                type="button"
                onClick={() => setActiveTab('schedule')}
                className="mt-4 px-4 py-2 text-xs font-semibold rounded-xl bg-[#113826] text-white"
              >
                Go to Meal Schedule
              </button>
            </div>
          ) : (
            <div className="space-y-6">
              {(Object.keys(categoryLabels) as IngredientCategory[]).map((category) => {
                const items = shoppingList.filter(i => i.category === category);
                if (items.length === 0) return null;

                const categoryTotalPhp = items.reduce((acc, i) => acc + i.estimatedCostPhp, 0);

                return (
                  <div key={category} className="bg-white border border-[#E8E2D5] rounded-2xl overflow-hidden shadow-xs">
                    <div className="bg-[#FAF7F0] px-4 py-3 border-b border-[#E8E2D5] flex items-center justify-between">
                      <h3 className="text-xs font-bold text-[#192A20] uppercase tracking-wider">
                        {categoryLabels[category]} ({items.length})
                      </h3>
                      <span className="text-xs font-bold font-mono text-[#113826]">
                        {formatCurrency(categoryTotalPhp, settings.currency)}
                      </span>
                    </div>

                    <div className="divide-y divide-[#F2ECE1]">
                      {items.map((item) => (
                        <div
                          key={item.id}
                          onClick={() => toggleShoppingItem(item.id)}
                          className={`p-3 sm:px-4 flex items-center justify-between gap-3 text-xs cursor-pointer transition-colors ${
                            item.checked ? 'bg-[#F7FBF8] text-[#8C9C92]' : 'hover:bg-[#FCFBF8]'
                          }`}
                        >
                          <div className="flex items-center gap-3 min-w-0">
                            {item.checked ? (
                              <CheckSquare className="w-4 h-4 text-[#113826] shrink-0" />
                            ) : (
                              <Square className="w-4 h-4 text-[#B8C8BD] shrink-0" />
                            )}
                            <div className="min-w-0">
                              <span className={`font-semibold block truncate ${item.checked ? 'line-through text-[#8C9C92]' : 'text-[#192A20]'}`}>
                                {item.name}
                              </span>
                              <span className="text-[10px] text-[#7A8A80] block truncate">
                                For: {item.fromRecipes.join(', ')}
                              </span>
                            </div>
                          </div>

                          <div className="text-right shrink-0">
                            <span className="font-mono font-semibold block text-[#384A3E]">
                              {settings.unitSystem === 'metric' ? item.quantityMetric : item.quantityCustomary}
                            </span>
                            <span className="text-[10px] font-mono text-[#7A8A80]">
                              {formatCurrency(item.estimatedCostPhp, settings.currency)}
                            </span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* Add Recipe to Plan Modal */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#11241A]/70 backdrop-blur-sm animate-fadeIn">
          <div className="bg-[#FAF7F0] border border-[#E2DBD0] rounded-3xl max-w-md w-full p-6 shadow-2xl">
            <h3 className="text-lg font-bold text-[#192A20] mb-1">
              Add Recipe to {targetSlot.toUpperCase()}
            </h3>
            <p className="text-xs text-[#586A5F] mb-4">
              Scheduled for {DAYS_OF_WEEK.find(d => d.index === selectedDayIndex)?.full}
            </p>

            <div className="mb-5">
              <label className="block text-xs font-semibold text-[#192A20] uppercase tracking-wider mb-2">
                Select Recipe
              </label>
              <select
                value={selectedRecipeIdToAdd}
                onChange={(e) => setSelectedRecipeIdToAdd(e.target.value)}
                className="w-full p-2.5 bg-white border border-[#DDD5C7] rounded-xl text-xs font-medium text-[#192A20] focus:ring-1 focus:ring-[#113826]"
              >
                {recipes.map((r) => (
                  <option key={r.id} value={r.id}>
                    {r.title} ({r.calories} kcal · {formatCurrency(r.baseCostPhp, settings.currency)})
                  </option>
                ))}
              </select>
            </div>

            <div className="flex items-center justify-end gap-2">
              <button
                type="button"
                onClick={() => setIsAddModalOpen(false)}
                className="px-4 py-2 text-xs font-semibold rounded-xl bg-white border border-[#DDD5C7] text-[#586A5F]"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleConfirmAddMeal}
                className="px-4 py-2 text-xs font-semibold rounded-xl bg-[#113826] text-white hover:bg-[#1A4E37]"
              >
                Add to Schedule
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
