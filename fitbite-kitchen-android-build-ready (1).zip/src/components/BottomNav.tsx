import React from 'react';
import { Home, BookOpen, Calendar, Activity, Droplets, SlidersHorizontal } from 'lucide-react';

interface BottomNavProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

export const BottomNav: React.FC<BottomNavProps> = ({
  activeTab,
  setActiveTab
}) => {
  const navItems = [
    { id: 'home', label: 'Home', icon: Home },
    { id: 'recipes', label: 'Recipes', icon: BookOpen },
    { id: 'planner', label: 'Planner', icon: Calendar },
    { id: 'tracker', label: 'Tracker', icon: Activity },
    { id: 'water', label: 'Water', icon: Droplets },
    { id: 'settings', label: 'Settings', icon: SlidersHorizontal }
  ];

  return (
    <div className="lg:hidden fixed bottom-0 left-0 right-0 z-40 bg-[#FAF7F2]/95 backdrop-blur-md border-t border-[#EBE5D8] pb-safe shadow-lg">
      <div className="grid grid-cols-6 items-center h-16 max-w-lg mx-auto px-1">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              type="button"
              onClick={() => setActiveTab(item.id)}
              className="min-h-[44px] min-w-[44px] flex flex-col items-center justify-center relative transition-transform active:scale-95 focus:outline-none cursor-pointer"
            >
              <div
                className={`p-1.5 rounded-xl transition-all ${
                  isActive 
                    ? 'bg-[#113826] text-[#A3E635] shadow-xs ring-2 ring-[#A3E635]/30' 
                    : 'text-[#64756A] hover:text-[#113826]'
                }`}
              >
                <Icon className={`w-4 h-4 sm:w-5 sm:h-5 ${isActive ? 'stroke-[2.5]' : 'stroke-[1.8]'}`} />
              </div>
              <span
                className={`text-[10px] tracking-tight mt-0.5 whitespace-nowrap ${
                  isActive ? 'font-bold text-[#113826]' : 'font-medium text-[#64756A]'
                }`}
              >
                {item.label}
              </span>
            </button>
          );
        })}
      </div>
    </div>
  );
};
