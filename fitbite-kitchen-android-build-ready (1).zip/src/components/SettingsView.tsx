import React, { useState } from 'react';
import { UserSettings, CurrencyCode, UnitSystem, FitnessGoal } from '../types';
import { SUPPORTED_REGIONS } from '../data/regions';
import { formatCurrency, formatRawCurrency } from '../utils/currency';
import { 
  Globe, 
  DollarSign, 
  Scale, 
  Flame, 
  Droplets, 
  Smartphone, 
  ShieldCheck, 
  RotateCcw, 
  Check, 
  ExternalLink,
  Code2
} from 'lucide-react';

interface SettingsViewProps {
  settings: UserSettings;
  onUpdateSettings: (newSettings: Partial<UserSettings>) => void;
  onResetAllData: () => void;
}

export const SettingsView: React.FC<SettingsViewProps> = ({
  settings,
  onUpdateSettings,
  onResetAllData
}) => {
  const [calorieInput, setCalorieInput] = useState(settings.dailyCalorieTarget.toString());
  const [waterInput, setWaterInput] = useState(settings.dailyWaterTargetMl.toString());
  const [budgetInput, setBudgetInput] = useState(settings.maxBudgetPerServing.toString());
  const [saveToast, setSaveToast] = useState(false);
  const [confirmReset, setConfirmReset] = useState(false);

  const selectedRegion = SUPPORTED_REGIONS.find(r => r.code === settings.countryCode) || SUPPORTED_REGIONS[0];

  const handleRegionChange = (code: string) => {
    const reg = SUPPORTED_REGIONS.find(r => r.code === code);
    if (reg) {
      onUpdateSettings({
        countryCode: reg.code,
        countryName: reg.name,
        currency: reg.currency,
        unitSystem: reg.defaultUnitSystem
      });
      triggerToast();
    }
  };

  const handleCurrencyChange = (currency: CurrencyCode) => {
    onUpdateSettings({ currency });
    triggerToast();
  };

  const handleUnitChange = (unitSystem: UnitSystem) => {
    onUpdateSettings({ unitSystem });
    triggerToast();
  };

  const handleDietaryChange = (dietaryPreference: UserSettings['dietaryPreference']) => {
    onUpdateSettings({ dietaryPreference });
    triggerToast();
  };

  const handleFitnessGoalChange = (activeFitnessGoal: FitnessGoal | 'all') => {
    onUpdateSettings({ activeFitnessGoal });
    triggerToast();
  };

  const handleSaveNumericGoals = (e: React.FormEvent) => {
    e.preventDefault();
    const cal = parseInt(calorieInput, 10);
    const water = parseInt(waterInput, 10);
    const budget = parseFloat(budgetInput);

    onUpdateSettings({
      dailyCalorieTarget: !isNaN(cal) && cal >= 800 ? cal : settings.dailyCalorieTarget,
      dailyWaterTargetMl: !isNaN(water) && water >= 500 ? water : settings.dailyWaterTargetMl,
      maxBudgetPerServing: !isNaN(budget) && budget > 0 ? budget : settings.maxBudgetPerServing
    });

    triggerToast();
  };

  const triggerToast = () => {
    setSaveToast(true);
    setTimeout(() => setSaveToast(false), 2500);
  };

  return (
    <div className="space-y-8 animate-fadeIn max-w-4xl mx-auto pb-12">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-[#192A20] tracking-tight">
            Settings & International Preferences
          </h1>
          <p className="text-xs sm:text-sm text-[#586A5F] mt-0.5">
            Customize region, currency, measurements, nutritional targets, and food budget.
          </p>
        </div>

        {saveToast && (
          <div className="flex items-center gap-1.5 px-3 py-1.5 bg-[#E8F0EB] text-[#113826] text-xs font-semibold rounded-xl border border-[#C6DC CE] animate-fadeIn">
            <Check className="w-3.5 h-3.5" />
            <span>Preferences Saved</span>
          </div>
        )}
      </div>

      {/* 1. Region & Localization */}
      <div className="bg-white border border-[#E8E2D5] rounded-3xl p-6 shadow-xs space-y-6">
        <div className="flex items-center gap-2 pb-4 border-b border-[#F2ECE1]">
          <Globe className="w-5 h-5 text-[#113826]" />
          <div>
            <h2 className="text-base font-bold text-[#192A20]">Region & Country</h2>
            <p className="text-xs text-[#586A5F]">
              Adapts currency, default units, and local grocery baseline estimates.
            </p>
          </div>
        </div>

        {/* Region selector pills */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
          {SUPPORTED_REGIONS.map((region) => {
            const isSelected = settings.countryCode === region.code;
            return (
              <button
                key={region.code}
                type="button"
                onClick={() => handleRegionChange(region.code)}
                className={`p-3 rounded-2xl border text-left transition-all ${
                  isSelected
                    ? 'bg-[#E8F0EB] border-[#113826] text-[#113826] font-bold shadow-xs'
                    : 'bg-[#FAF7F0] border-[#E8E2D5] text-[#3D4F43] hover:border-[#113826]/40'
                }`}
              >
                <span className="text-xl block mb-1" role="img" aria-label={region.name}>
                  {region.flag}
                </span>
                <span className="text-xs font-medium block truncate">{region.name}</span>
                <span className="text-[10px] text-[#69796E] font-mono block">
                  {region.currency} ({region.currencySymbol})
                </span>
              </button>
            );
          })}
        </div>

        {/* Currency & Unit System Manual Overrides */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-4 border-t border-[#F2ECE1]">
          <div>
            <label className="block text-xs font-semibold text-[#192A20] uppercase tracking-wider mb-1.5 flex items-center gap-1.5">
              <DollarSign className="w-3.5 h-3.5 text-[#113826]" />
              Manual Currency Selection
            </label>
            <select
              value={settings.currency}
              onChange={(e) => handleCurrencyChange(e.target.value as CurrencyCode)}
              className="w-full p-2.5 bg-[#FAF7F0] border border-[#DDD5C7] rounded-xl text-xs font-semibold text-[#192A20] focus:ring-1 focus:ring-[#113826]"
            >
              <option value="PHP">PHP (₱) - Philippine Peso</option>
              <option value="USD">USD ($) - US Dollar</option>
              <option value="EUR">EUR (€) - Euro</option>
              <option value="GBP">GBP (£) - British Pound</option>
              <option value="CAD">CAD ($) - Canadian Dollar</option>
              <option value="AUD">AUD ($) - Australian Dollar</option>
              <option value="JPY">JPY (¥) - Japanese Yen</option>
              <option value="SGD">SGD (S$) - Singapore Dollar</option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-semibold text-[#192A20] uppercase tracking-wider mb-1.5 flex items-center gap-1.5">
              <Scale className="w-3.5 h-3.5 text-[#113826]" />
              Measurement Units System
            </label>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => handleUnitChange('metric')}
                className={`py-2 px-3 text-xs font-semibold rounded-xl border transition-colors ${
                  settings.unitSystem === 'metric'
                    ? 'bg-[#113826] text-white border-[#113826]'
                    : 'bg-[#FAF7F0] border-[#DDD5C7] text-[#586A5F] hover:bg-[#F0EBE0]'
                }`}
              >
                Metric (g, mL, °C)
              </button>
              <button
                type="button"
                onClick={() => handleUnitChange('us_customary')}
                className={`py-2 px-3 text-xs font-semibold rounded-xl border transition-colors ${
                  settings.unitSystem === 'us_customary'
                    ? 'bg-[#113826] text-white border-[#113826]'
                    : 'bg-[#FAF7F0] border-[#DDD5C7] text-[#586A5F] hover:bg-[#F0EBE0]'
                }`}
              >
                US Customary (oz, cups, °F)
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* 2. Nutritional Targets & Budget */}
      <div className="bg-white border border-[#E8E2D5] rounded-3xl p-6 shadow-xs space-y-6">
        <div className="flex items-center gap-2 pb-4 border-b border-[#F2ECE1]">
          <Flame className="w-5 h-5 text-[#B85D19]" />
          <div>
            <h2 className="text-base font-bold text-[#192A20]">Personal Targets & Budget</h2>
            <p className="text-xs text-[#586A5F]">
              Set your daily calorie allowance, water goal, and maximum food budget per serving.
            </p>
          </div>
        </div>

        <form onSubmit={handleSaveNumericGoals} className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-semibold text-[#192A20] uppercase tracking-wider mb-1">
                Daily Calorie Target (kcal)
              </label>
              <input
                type="number"
                min="1000"
                max="6000"
                value={calorieInput}
                onChange={(e) => setCalorieInput(e.target.value)}
                className="w-full p-2.5 bg-[#FAF7F0] border border-[#DDD5C7] rounded-xl text-xs font-mono font-bold text-[#192A20]"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#192A20] uppercase tracking-wider mb-1">
                Daily Water Target (mL)
              </label>
              <input
                type="number"
                min="500"
                max="8000"
                step="100"
                value={waterInput}
                onChange={(e) => setWaterInput(e.target.value)}
                className="w-full p-2.5 bg-[#FAF7F0] border border-[#DDD5C7] rounded-xl text-xs font-mono font-bold text-[#192A20]"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#192A20] uppercase tracking-wider mb-1">
                Max Food Budget / Serving ({settings.currency})
              </label>
              <input
                type="number"
                min="1"
                step="1"
                value={budgetInput}
                onChange={(e) => setBudgetInput(e.target.value)}
                className="w-full p-2.5 bg-[#FAF7F0] border border-[#DDD5C7] rounded-xl text-xs font-mono font-bold text-[#192A20]"
              />
            </div>
          </div>

          <div className="flex justify-end">
            <button
              type="submit"
              className="px-5 py-2.5 text-xs font-semibold rounded-xl bg-[#113826] text-white hover:bg-[#1A4E37] transition-all shadow-xs"
            >
              Update Targets & Budget
            </button>
          </div>
        </form>

        {/* Dietary Preferences & Fitness Goal */}
        <div className="pt-4 border-t border-[#F2ECE1] space-y-4">
          <div>
            <label className="block text-xs font-semibold text-[#192A20] uppercase tracking-wider mb-2">
              Dietary Preference
            </label>
            <div className="flex flex-wrap gap-2">
              {[
                { id: 'all', label: 'No Restrictions' },
                { id: 'high_protein', label: 'High Protein' },
                { id: 'low_carb', label: 'Low Carb' },
                { id: 'vegetarian', label: 'Vegetarian' },
                { id: 'pescatarian', label: 'Pescatarian' }
              ].map((pref) => (
                <button
                  key={pref.id}
                  type="button"
                  onClick={() => handleDietaryChange(pref.id as any)}
                  className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-colors ${
                    settings.dietaryPreference === pref.id
                      ? 'bg-[#113826] text-white font-semibold'
                      : 'bg-[#FAF7F0] border border-[#DDD5C7] text-[#586A5F] hover:bg-[#F0EBE0]'
                  }`}
                >
                  {pref.label}
                </button>
              ))}
            </div>
          </div>

          {/* Primary Fitness Goal */}
          <div className="pt-3 border-t border-[#F2ECE1]">
            <label className="block text-xs font-semibold text-[#192A20] uppercase tracking-wider mb-2">
              Primary Goal (Personalizes Home & Recipe Feeds)
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {[
                { id: 'calorie_deficit', label: 'Calorie Deficit', desc: 'Mindful portions & calorie targets' },
                { id: 'omad', label: 'OMAD (One Meal/Day)', desc: 'Substantial, nutrient-dense feast bowls' },
                { id: 'new_to_balanced', label: 'New to Balanced Eating', desc: 'Simple comfort dishes & easy steps' },
                { id: 'build_muscle', label: 'Build Muscle', desc: 'High-protein recipes (30g+ protein)' },
                { id: 'general_healthy', label: 'General Healthy Eating', desc: 'Varied, wholesome everyday meals' }
              ].map((goal) => {
                const isSelected = (settings.primaryGoal || settings.activeFitnessGoal) === goal.id;
                return (
                  <button
                    key={goal.id}
                    type="button"
                    onClick={() => {
                      onUpdateSettings({ 
                        primaryGoal: goal.id as FitnessGoal,
                        activeFitnessGoal: goal.id as FitnessGoal 
                      });
                      triggerToast();
                    }}
                    className={`p-3 rounded-2xl border text-left transition-all ${
                      isSelected
                        ? 'bg-[#E8F0EB] border-[#113826] text-[#113826] font-bold shadow-xs'
                        : 'bg-[#FAF7F0] border-[#DDD5C7] text-[#4F6255] hover:bg-[#F0ECE1]'
                    }`}
                  >
                    <span className="text-xs font-bold block">{goal.label}</span>
                    <span className="text-[10px] text-[#69796E] font-normal block mt-0.5">{goal.desc}</span>
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      </div>

      {/* 3. Android Prototype & Native Build Architecture Report */}
      <div className="bg-[#FAF7F0] border border-[#E2DBD0] rounded-3xl p-6 sm:p-8 shadow-xs space-y-4">
        <div className="flex items-center gap-2 pb-3 border-b border-[#E8E2D5]">
          <Smartphone className="w-5 h-5 text-[#113826]" />
          <div>
            <h2 className="text-base font-bold text-[#192A20]">
              About this Prototype & Android App Build Path
            </h2>
            <p className="text-xs text-[#586A5F]">
              Technical classification and production roadmap.
            </p>
          </div>
        </div>

        <div className="space-y-3 text-xs text-[#394B3F] leading-relaxed">
          <div className="p-3.5 bg-white border border-[#DDD5C7] rounded-2xl">
            <span className="font-bold text-[#113826] block mb-1">
              Current Environment Classification: Progressive Web Application (PWA Prototype)
            </span>
            <p>
              This live implementation is a responsive, offline-capable single-page application built with React 19, TypeScript, and Vite. It is <strong>not yet a binary Android package (.apk / .aab)</strong> because this cloud sandbox environment runs a Node.js web server rather than an Android SDK / Gradle toolchain.
            </p>
          </div>

          <div className="p-3.5 bg-white border border-[#DDD5C7] rounded-2xl space-y-2">
            <span className="font-bold text-[#192A20] block">
              3 Practical Steps to Generate a Native Android App (.apk / .aab):
            </span>
            <ol className="list-decimal pl-4 space-y-1.5 text-[11px] text-[#4F6255]">
              <li>
                <strong>Wrap with Capacitor:</strong> Run <code className="bg-[#EBE7DC] px-1 py-0.5 rounded font-mono">npm install @capacitor/core @capacitor/cli @capacitor/android</code>, then <code className="bg-[#EBE7DC] px-1 py-0.5 rounded font-mono">npx cap init FitBiteKitchen com.fitbite.kitchen</code>.
              </li>
              <li>
                <strong>Build & Sync:</strong> Run <code className="bg-[#EBE7DC] px-1 py-0.5 rounded font-mono">npm run build && npx cap add android && npx cap sync android</code>.
              </li>
              <li>
                <strong>Compile in Android Studio:</strong> Open the generated <code className="bg-[#EBE7DC] px-1 py-0.5 rounded font-mono">android/</code> directory in Android Studio. From there, select <em>Build &gt; Build Bundle(s) / APK(s) &gt; Build APK</em> to produce your installable Android binary.
              </li>
            </ol>
          </div>

          <div className="p-3.5 bg-[#E8F0EB] border border-[#BFD6C6] rounded-2xl text-[11px] text-[#1A4E37]">
            <span className="font-bold block mb-1">AdMob Monetization Strategy:</span>
            <p>
              In accordance with your requirements, no mock advertisements or fake banners are rendered in this prototype. When compiling the native Android project via Android Studio, official Google Mobile Ads SDK (<code className="font-mono">com.google.android.gms:play-services-ads</code>) can be integrated with Google AdMob test banner ad unit ID (<code className="font-mono">ca-app-pub-3940256099942544/6300978111</code>) pinned to the bottom of the screen.
            </p>
          </div>
        </div>
      </div>

      {/* 4. Data Management & Reset */}
      <div className="bg-white border border-[#E8E2D5] rounded-3xl p-6 shadow-xs flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-sm font-bold text-[#192A20]">Local Data & Storage</h2>
          <p className="text-xs text-[#6B7C71]">
            All logs, meal plans, custom prices, and settings are securely stored locally on this device.
          </p>
        </div>

        {confirmReset ? (
          <div className="flex items-center gap-2">
            <span className="text-xs text-[#B83828] font-bold">Are you sure?</span>
            <button
              type="button"
              onClick={() => {
                onResetAllData();
                setConfirmReset(false);
              }}
              className="px-3 py-1.5 text-xs font-semibold rounded-xl bg-[#B83828] text-white hover:bg-[#9B2B1D]"
            >
              Yes, Reset Everything
            </button>
            <button
              type="button"
              onClick={() => setConfirmReset(false)}
              className="px-3 py-1.5 text-xs font-medium rounded-xl border border-[#DDD5C7] text-[#586A5F]"
            >
              Cancel
            </button>
          </div>
        ) : (
          <button
            type="button"
            onClick={() => setConfirmReset(true)}
            className="px-4 py-2 text-xs font-semibold rounded-xl border border-[#DDD5C7] text-[#8C9C92] hover:text-[#B83828] hover:border-[#B83828]/40 hover:bg-[#FDECEB] transition-colors flex items-center gap-1.5"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Reset All App Data</span>
          </button>
        )}
      </div>
    </div>
  );
};
