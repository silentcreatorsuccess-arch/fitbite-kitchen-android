import React, { useRef } from 'react';
import { Recipe, UserSettings, LoggedMealEntry, WaterLogEntry, MealPlanItem, FitnessGoal } from '../types';
import { RecipeCard } from './RecipeCard';
import { formatCurrency } from '../utils/currency';
import { formatWaterAmount } from '../utils/units';
import { 
  Flame, 
  Droplets, 
  Calendar, 
  ArrowRight, 
  Plus, 
  Sparkles, 
  Target, 
  Clock, 
  ChevronRight, 
  ChefHat, 
  Wallet,
  CheckCircle2
} from 'lucide-react';

interface HomeViewProps {
  settings: UserSettings;
  recipes: Recipe[];
  loggedMeals: LoggedMealEntry[];
  waterLogs: WaterLogEntry[];
  mealPlan: MealPlanItem[];
  onSelectRecipe: (recipe: Recipe) => void;
  onNavigateTab: (tab: string) => void;
  onQuickAddWater: (amountMl: number) => void;
  onQuickLogMeal: (recipe: Recipe) => void;
}

export const HomeView: React.FC<HomeViewProps> = ({
  settings,
  recipes,
  loggedMeals,
  waterLogs,
  mealPlan,
  onSelectRecipe,
  onNavigateTab,
  onQuickAddWater,
  onQuickLogMeal
}) => {
  const madeForYouRef = useRef<HTMLDivElement>(null);

  const todayStr = new Date().toISOString().split('T')[0];
  const todayMeals = loggedMeals.filter(m => m.dateString === todayStr);

  const totalCaloriesToday = todayMeals.reduce((acc, m) => acc + m.calories, 0);
  const totalProteinToday = todayMeals.reduce((acc, m) => acc + m.proteinGrams, 0);
  const totalCarbsToday = todayMeals.reduce((acc, m) => acc + m.carbsGrams, 0);
  const totalFatToday = todayMeals.reduce((acc, m) => acc + m.fatGrams, 0);

  const caloriePercentage = Math.min(100, Math.round((totalCaloriesToday / settings.dailyCalorieTarget) * 100));
  const remainingCalories = Math.max(0, settings.dailyCalorieTarget - totalCaloriesToday);

  // Water calculations
  const totalWaterMlToday = waterLogs.reduce((acc, w) => acc + w.amountMl, 0);
  const waterPercentage = Math.min(100, Math.round((totalWaterMlToday / settings.dailyWaterTargetMl) * 100));

  // Today's meal plan (0=Mon ... 6=Sun)
  const currentDayIndex = (new Date().getDay() + 6) % 7;
  const todayPlannedItems = mealPlan.filter(p => p.dayIndex === currentDayIndex);

  // Personalized recipe filtering based on user's primaryGoal
  const activeGoal = settings.primaryGoal || settings.activeFitnessGoal || 'general_healthy';

  const goalDescriptions: Record<string, { label: string; tip: string; highlight: string }> = {
    calorie_deficit: {
      label: 'Calorie Deficit',
      tip: 'Mindful, high-satiety meals packed with lean protein and fiber to comfortably support your deficit.',
      highlight: 'Mindful Calorie Target'
    },
    omad: {
      label: 'One Meal a Day (OMAD)',
      tip: 'Wholesome, macro-balanced feast bowls loaded with diverse micronutrients and healthy fats.',
      highlight: 'Macro-Rich Eating Window'
    },
    new_to_balanced: {
      label: 'New to Balanced Eating',
      tip: 'Simple, beginner-friendly comfort meals with step-by-step instructions and everyday pantry ingredients.',
      highlight: 'Easy Kitchen Fundamentals'
    },
    build_muscle: {
      label: 'Build Muscle',
      tip: 'High-protein recipes (30g–60g per serving) designed to support resistance training and muscle repair.',
      highlight: 'High Protein Density'
    },
    general_healthy: {
      label: 'General Healthy Eating',
      tip: 'Flavorful, nutrient-packed home meals celebrating balanced Filipino and international cooking.',
      highlight: 'Everyday Wholesome Vitality'
    }
  };

  const currentGoalMeta = goalDescriptions[activeGoal] || goalDescriptions.general_healthy;

  // Filter personalized recommendations matching goal
  const personalizedRecipes = recipes.filter(r => 
    r.fitnessGoals.includes(activeGoal as FitnessGoal) || 
    (activeGoal === 'build_muscle' && r.proteinGrams >= 30) ||
    (activeGoal === 'calorie_deficit' && r.calories <= 330)
  ).slice(0, 3);

  const madeForYouList = personalizedRecipes.length > 0 ? personalizedRecipes : recipes.slice(0, 3);

  // Budget-friendly collection (Section 5)
  const budgetFriendlyRecipes = recipes.filter(r => r.budgetTier === 'budget').slice(0, 3);

  // Determine an authentic verified hero dish from the recipes
  // Pick a verified dish with an authentic photo matching user preferences
  const heroDishCandidate = madeForYouList.find(r => r.hasRealPhoto && r.imageUrl) || 
    recipes.find(r => r.id === 'healthy-chicken-adobo') || 
    recipes.find(r => r.id === 'mediterranean-salmon-quinoa') || 
    recipes[0];

  const handleFindNextMeal = () => {
    if (madeForYouRef.current) {
      madeForYouRef.current.scrollIntoView({ behavior: 'smooth' });
    } else {
      onNavigateTab('recipes');
    }
  };

  // Check if trackers are enabled
  const showCalories = settings.enableCalorieTracker !== false;
  const showWater = settings.enableWaterTracker !== false;
  const hasAnyTracker = showCalories || showWater;

  return (
    <div className="space-y-10 animate-fadeIn pb-12">
      {/* =========================================================================
          WELCOME HERO SECTION
          - Large, realistic, appetizing photograph of an actual healthy dish
          - Headline: "Eat Well. Feel Strong. Your Way."
          - Supporting text: "Discover delicious meals that fit your goals, taste, and budget."
          - Prominent primary button: "Find My Next Meal"
          - Smaller secondary action: "Explore Recipes"
         ========================================================================= */}
      <section className="relative overflow-hidden rounded-3xl bg-[#0E2E1F] text-white shadow-xl border border-[#164732]">
        {/* Subtle decorative background gradient with soft ambient light */}
        <div className="absolute inset-0 bg-gradient-to-br from-[#0E2E1F] via-[#113826] to-[#0A2217] opacity-98" />
        <div className="absolute -right-16 -top-16 w-88 h-88 rounded-full bg-[#A3E635]/12 blur-3xl pointer-events-none" />
        <div className="absolute -left-16 -bottom-16 w-88 h-88 rounded-full bg-[#EA580C]/10 blur-3xl pointer-events-none" />

        <div className="relative z-10 grid grid-cols-1 lg:grid-cols-12 gap-8 items-center p-6 sm:p-10 lg:p-12">
          {/* Left Text & Call To Action */}
          <div className="lg:col-span-7 space-y-5">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/10 backdrop-blur-md text-[11px] font-semibold text-[#A3E635] border border-white/15 shadow-2xs">
              <Sparkles className="w-3.5 h-3.5 text-[#A3E635]" />
              <span>Personalized for {currentGoalMeta.label}</span>
            </div>

            <div className="space-y-2.5">
              <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold tracking-tight text-white leading-[1.15]">
                Eat Well. Feel Strong. <br className="hidden sm:inline" />
                <span className="text-[#A3E635]">Your Way.</span>
              </h1>
              <p className="text-sm sm:text-base text-white/90 max-w-xl font-normal leading-relaxed">
                Discover delicious meals that fit your goals, taste, and budget.
              </p>
            </div>

            {/* Actions: Primary & Secondary */}
            <div className="flex flex-wrap items-center gap-3 pt-2">
              <button
                type="button"
                onClick={handleFindNextMeal}
                className="px-6 py-3.5 text-sm font-extrabold text-[#0E2E1F] bg-[#A3E635] hover:bg-[#B4F044] active:scale-95 rounded-2xl shadow-lg hover:shadow-xl transition-all flex items-center gap-2 cursor-pointer"
              >
                <span>Find My Next Meal</span>
                <ArrowRight className="w-4 h-4 stroke-[2.5]" />
              </button>

              <button
                type="button"
                onClick={() => onNavigateTab('recipes')}
                className="px-5 py-3.5 text-sm font-semibold text-white/95 bg-white/10 hover:bg-white/15 border border-white/15 active:scale-95 rounded-2xl transition-all cursor-pointer flex items-center gap-1.5 shadow-2xs"
              >
                <span>Explore Recipes</span>
                <ChevronRight className="w-4 h-4 text-white/70" />
              </button>
            </div>

            {/* Quick value badges */}
            <div className="pt-3 flex flex-wrap items-center gap-4 text-xs text-white/80 font-medium border-t border-white/10">
              <span className="flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5 text-[#A3E635]" />
                Realistic Food Photos
              </span>
              <span className="flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5 text-[#A3E635]" />
                Ingredient Cost Scaling
              </span>
              <span className="flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5 text-[#A3E635]" />
                Budget Swaps
              </span>
            </div>
          </div>

          {/* Right Featured Dish Photo Showcase (Identifiable real recipe) */}
          <div className="lg:col-span-5">
            <div 
              onClick={() => onSelectRecipe(heroDishCandidate)}
              className="group relative rounded-3xl overflow-hidden bg-[#1E2922] border-2 border-white/20 shadow-2xl cursor-pointer transition-transform duration-300 hover:scale-[1.02]"
            >
              {heroDishCandidate.hasRealPhoto && heroDishCandidate.imageUrl ? (
                <div className="relative aspect-[4/3] sm:h-72 w-full">
                  <img
                    src={heroDishCandidate.imageUrl}
                    alt={heroDishCandidate.imageAlt || heroDishCandidate.title}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700 ease-out"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/25 to-transparent pointer-events-none" />
                </div>
              ) : (
                <div className="h-64 w-full bg-[#1A2E22] flex items-center justify-center p-6 text-center">
                  <ChefHat className="w-12 h-12 text-[#A3E635]/60 mb-2" />
                </div>
              )}

              {/* Featured dish badge overlay */}
              <div className="absolute top-3.5 left-3.5 bg-black/60 backdrop-blur-md px-3 py-1 rounded-xl border border-white/15 text-[11px] font-bold text-white flex items-center gap-1.5 shadow-sm">
                <span className="w-2 h-2 rounded-full bg-[#A3E635] animate-pulse" />
                <span>Featured Dish</span>
              </div>

              {/* Bottom dish details strip */}
              <div className="absolute bottom-0 left-0 right-0 p-4 sm:p-5 text-white">
                <p className="text-[11px] font-semibold uppercase tracking-wider text-[#A3E635] mb-0.5">
                  {heroDishCandidate.cuisine} Cuisine · {heroDishCandidate.difficulty}
                </p>
                <h3 className="text-base sm:text-lg font-bold leading-snug group-hover:text-[#A3E635] transition-colors line-clamp-1">
                  {heroDishCandidate.title}
                </h3>
                
                <div className="mt-2 flex items-center justify-between text-xs text-white/90 font-medium">
                  <span className="flex items-center gap-1">
                    <Clock className="w-3.5 h-3.5 text-[#A3E635]" />
                    {heroDishCandidate.prepTimeMinutes + heroDishCandidate.cookTimeMinutes} mins
                  </span>
                  <span className="font-mono font-bold text-[#A3E635]">
                    {formatCurrency(heroDishCandidate.baseCostPhp, settings.currency)} / srv
                  </span>
                  <span className="bg-white/20 backdrop-blur-md px-2 py-0.5 rounded-md text-[11px] border border-white/10">
                    {heroDishCandidate.calories} kcal
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* =========================================================================
          1. COMPACT PERSONAL-GOAL CARD
          - Shows user's selected goal
          - With an option to change it
         ========================================================================= */}
      <section className="bg-white border border-[#EBE5D8] rounded-3xl p-5 sm:p-6 shadow-xs flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div className="flex items-start gap-4">
          <div className="w-11 h-11 rounded-2xl bg-[#113826] text-[#A3E635] flex items-center justify-center shrink-0 shadow-xs">
            <Target className="w-5 h-5 stroke-[2.2]" />
          </div>
          <div>
            <div className="flex flex-wrap items-center gap-2">
              <span className="text-xs font-bold text-[#64756A] uppercase tracking-wider">
                Current Goal
              </span>
              <span className="text-[11px] font-bold text-[#113826] bg-[#E8F3D6] px-2.5 py-0.5 rounded-full border border-[#D1E6B2]">
                {currentGoalMeta.label}
              </span>
            </div>
            <p className="text-xs sm:text-sm text-[#45584D] mt-1 max-w-2xl leading-relaxed">
              {currentGoalMeta.tip}
            </p>
          </div>
        </div>

        <button
          type="button"
          onClick={() => onNavigateTab('settings')}
          className="px-4 py-2 text-xs font-bold text-[#113826] bg-[#FAF7F2] hover:bg-[#E8F0EB] border border-[#DDD5C7] rounded-xl transition-all shadow-2xs whitespace-nowrap self-start sm:self-center shrink-0 active:scale-95 cursor-pointer"
        >
          Change Goal →
        </button>
      </section>

      {/* =========================================================================
          2. "MADE FOR YOU"
          - Two or three personalized recipe cards with large, matching food photographs
         ========================================================================= */}
      <section ref={madeForYouRef} className="space-y-4">
        <div className="flex items-end justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-[#65A30D]" />
              <span className="text-xs font-bold uppercase tracking-wider text-[#65A30D]">
                Recommended For You
              </span>
            </div>
            <h2 className="text-xl sm:text-2xl font-extrabold text-[#15241C] tracking-tight mt-0.5">
              Made for You
            </h2>
            <p className="text-xs sm:text-sm text-[#5B6E62]">
              Handcrafted dishes matching your nutrition focus ({currentGoalMeta.label}) and local budget
            </p>
          </div>

          <button
            type="button"
            onClick={() => onNavigateTab('recipes')}
            className="text-xs font-bold text-[#113826] hover:text-[#65A30D] hover:underline whitespace-nowrap shrink-0 flex items-center gap-1"
          >
            <span>See all 22 recipes</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {madeForYouList.map((recipe) => (
            <RecipeCard
              key={recipe.id}
              recipe={recipe}
              settings={settings}
              onSelect={onSelectRecipe}
              onQuickAddToPlan={() => onNavigateTab('planner')}
              onQuickLogMeal={() => onQuickLogMeal(recipe)}
            />
          ))}
        </div>
      </section>

      {/* =========================================================================
          3. "TODAY'S PLAN"
          - Simple meal-plan summary and a clear action to create or edit it
         ========================================================================= */}
      <section className="bg-white border border-[#EBE5D8] rounded-3xl p-6 sm:p-7 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-[#F2ECE1]">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-[#E8F0EB] text-[#113826] flex items-center justify-center shrink-0">
              <Calendar className="w-5 h-5 stroke-[2.2]" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-bold text-[#15241C]">
                Today’s Plan
              </h2>
              <p className="text-xs text-[#64756A]">
                Scheduled meals for healthy routine & easy grocery planning
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => onNavigateTab('planner')}
              className="px-3.5 py-1.5 text-xs font-bold text-[#113826] bg-[#FAF7F2] hover:bg-[#E8F0EB] border border-[#DDD5C7] rounded-xl transition-all shadow-2xs active:scale-95"
            >
              Open Meal Planner →
            </button>
          </div>
        </div>

        {todayPlannedItems.length === 0 ? (
          <div className="py-8 text-center bg-[#FAF7F2] rounded-2xl border border-dashed border-[#DDD5C7] p-6 space-y-3">
            <p className="text-sm font-medium text-[#526458]">
              No meals scheduled for today yet.
            </p>
            <p className="text-xs text-[#7A8A80] max-w-sm mx-auto">
              Plan breakfast, lunch, or dinner from your favorite recipes to keep your daily calorie and grocery budget on track.
            </p>
            <button
              type="button"
              onClick={() => onNavigateTab('planner')}
              className="px-4 py-2 text-xs font-bold text-white bg-[#113826] hover:bg-[#1A4E37] rounded-xl shadow-xs transition-all active:scale-95 inline-flex items-center gap-1.5"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Plan Today’s Meals</span>
            </button>
          </div>
        ) : (
          <div className="space-y-3">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
              {todayPlannedItems.map((item) => {
                const targetRecipe = recipes.find(r => r.id === item.recipeId);
                return (
                  <div
                    key={item.id}
                    className="p-3.5 rounded-2xl bg-[#FAF7F2] border border-[#E8E2D5] flex items-center justify-between gap-3 text-xs hover:border-[#113826]/30 transition-all"
                  >
                    <div className="min-w-0">
                      <span className="text-[10px] uppercase font-bold text-[#65A30D] block">
                        {item.mealType}
                      </span>
                      <p className="font-bold text-[#15241C] truncate mt-0.5">
                        {item.recipeTitle}
                      </p>
                      <span className="font-mono text-[#64756A] text-[11px]">
                        {item.calories} kcal
                      </span>
                    </div>

                    {targetRecipe && (
                      <button
                        type="button"
                        onClick={() => onQuickLogMeal(targetRecipe)}
                        title="Log this planned meal now"
                        className="p-2 rounded-xl bg-white border border-[#DDD5C7] text-[#113826] hover:bg-[#E8F0EB] shadow-2xs active:scale-95 shrink-0"
                      >
                        <Plus className="w-3.5 h-3.5 text-[#113826]" />
                      </button>
                    )}
                  </div>
                );
              })}
            </div>

            <div className="pt-2 flex items-center justify-between text-xs text-[#526458]">
              <span>{todayPlannedItems.length} planned {todayPlannedItems.length === 1 ? 'meal' : 'meals'} scheduled</span>
              <button
                type="button"
                onClick={() => onNavigateTab('planner')}
                className="text-[#113826] font-bold hover:underline"
              >
                View Grocery List →
              </button>
            </div>
          </div>
        )}
      </section>

      {/* =========================================================================
          4. "YOUR DAILY PROGRESS"
          - Compact calorie and water progress, only when relevant trackers are enabled
         ========================================================================= */}
      {hasAnyTracker && (
        <section className="space-y-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-[#EA580C]" />
              <span className="text-xs font-bold uppercase tracking-wider text-[#EA580C]">
                Daily Overview
              </span>
            </div>
            <h2 className="text-xl sm:text-2xl font-extrabold text-[#15241C] tracking-tight mt-0.5">
              Your Daily Progress
            </h2>
          </div>

          <div className={`grid grid-cols-1 ${showCalories && showWater ? 'md:grid-cols-2' : ''} gap-5`}>
            {/* Calorie Card */}
            {showCalories && (
              <div className="bg-white border border-[#EBE5D8] rounded-3xl p-5 sm:p-6 shadow-xs flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-xs font-bold text-[#15241C] uppercase tracking-wider flex items-center gap-1.5">
                      <Flame className="w-4 h-4 text-[#EA580C]" />
                      Calorie Budget
                    </span>
                    <button
                      type="button"
                      onClick={() => onNavigateTab('tracker')}
                      className="text-xs font-bold text-[#113826] hover:underline"
                    >
                      Tracker →
                    </button>
                  </div>

                  <div className="flex items-baseline justify-between mb-2">
                    <div>
                      <span className="text-3xl font-extrabold text-[#15241C] font-mono tabular-nums">
                        {totalCaloriesToday}
                      </span>
                      <span className="text-xs text-[#6B7C71] ml-1 font-mono">
                        / {settings.dailyCalorieTarget} kcal
                      </span>
                    </div>
                    <span className="text-xs font-bold font-mono text-[#65A30D]">
                      {caloriePercentage}%
                    </span>
                  </div>

                  {/* Fresh Lime Progress Bar */}
                  <div className="w-full h-2.5 bg-[#F3EFE6] rounded-full overflow-hidden mb-3">
                    <div
                      className="h-full bg-[#65A30D] rounded-full transition-all duration-500"
                      style={{ width: `${caloriePercentage}%` }}
                    />
                  </div>

                  {/* Macros breakdown */}
                  <div className="grid grid-cols-3 gap-2 text-center pt-2 border-t border-[#F2ECE1] text-[11px] font-mono tabular-nums">
                    <div className="bg-[#FAF7F2] p-1.5 rounded-xl border border-[#EDE8DE]">
                      <span className="text-[#64756A] block text-[9px]">Protein</span>
                      <span className="font-bold text-[#15241C]">{totalProteinToday}g</span>
                    </div>
                    <div className="bg-[#FAF7F2] p-1.5 rounded-xl border border-[#EDE8DE]">
                      <span className="text-[#64756A] block text-[9px]">Carbs</span>
                      <span className="font-bold text-[#15241C]">{totalCarbsToday}g</span>
                    </div>
                    <div className="bg-[#FAF7F2] p-1.5 rounded-xl border border-[#EDE8DE]">
                      <span className="text-[#64756A] block text-[9px]">Fats</span>
                      <span className="font-bold text-[#15241C]">{totalFatToday}g</span>
                    </div>
                  </div>
                </div>

                <div className="mt-4 pt-3 border-t border-[#F2ECE1] flex items-center justify-between text-xs text-[#526458]">
                  <span>{remainingCalories} kcal remaining</span>
                  <button
                    type="button"
                    onClick={() => onNavigateTab('tracker')}
                    className="text-[#113826] font-bold hover:underline"
                  >
                    + Log Food
                  </button>
                </div>
              </div>
            )}

            {/* Water Card */}
            {showWater && (
              <div className="bg-white border border-[#EBE5D8] rounded-3xl p-5 sm:p-6 shadow-xs flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-xs font-bold text-[#15241C] uppercase tracking-wider flex items-center gap-1.5">
                      <Droplets className="w-4 h-4 text-[#0284C7]" />
                      Daily Hydration
                    </span>
                    <button
                      type="button"
                      onClick={() => onNavigateTab('water')}
                      className="text-xs font-bold text-[#113826] hover:underline"
                    >
                      Water Log →
                    </button>
                  </div>

                  <div className="flex items-baseline justify-between mb-2">
                    <div>
                      <span className="text-3xl font-extrabold text-[#15241C] font-mono tabular-nums">
                        {formatWaterAmount(totalWaterMlToday, settings.unitSystem)}
                      </span>
                      <span className="text-xs text-[#6B7C71] ml-1 font-mono">
                        / {formatWaterAmount(settings.dailyWaterTargetMl, settings.unitSystem)}
                      </span>
                    </div>
                    <span className="text-xs font-bold font-mono text-[#0284C7]">
                      {waterPercentage}%
                    </span>
                  </div>

                  {/* Water progress bar */}
                  <div className="w-full h-2.5 bg-[#E6F3FA] rounded-full overflow-hidden mb-4">
                    <div
                      className="h-full bg-[#0284C7] rounded-full transition-all duration-500"
                      style={{ width: `${waterPercentage}%` }}
                    />
                  </div>

                  {/* Quick hydration buttons */}
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      type="button"
                      onClick={() => onQuickAddWater(250)}
                      className="py-2 px-3 text-xs font-bold rounded-xl bg-[#E8F4FC] text-[#0369A1] hover:bg-[#D5EBF9] transition-all flex items-center justify-center gap-1.5 active:scale-95"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      <span>+250 ml (Glass)</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => onQuickAddWater(500)}
                      className="py-2 px-3 text-xs font-bold rounded-xl bg-[#E8F4FC] text-[#0369A1] hover:bg-[#D5EBF9] transition-all flex items-center justify-center gap-1.5 active:scale-95"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      <span>+500 ml (Bottle)</span>
                    </button>
                  </div>
                </div>

                <div className="mt-4 pt-3 border-t border-[#F2ECE1] flex items-center justify-between text-xs text-[#526458]">
                  <span>{Math.max(0, settings.dailyWaterTargetMl - totalWaterMlToday)} ml remaining</span>
                  <button
                    type="button"
                    onClick={() => onNavigateTab('water')}
                    className="text-[#113826] font-bold hover:underline"
                  >
                    View History
                  </button>
                </div>
              </div>
            )}
          </div>
        </section>
      )}

      {/* =========================================================================
          5. "QUICK & BUDGET-FRIENDLY"
          - Small collection of affordable recipes
         ========================================================================= */}
      <section className="space-y-4">
        <div className="flex items-end justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-[#113826]" />
              <span className="text-xs font-bold uppercase tracking-wider text-[#113826]">
                Budget Conscious
              </span>
            </div>
            <h2 className="text-xl sm:text-2xl font-extrabold text-[#15241C] tracking-tight mt-0.5">
              Quick & Budget-Friendly
            </h2>
            <p className="text-xs sm:text-sm text-[#5B6E62]">
              Nutrient-dense home cooking designed to stretch your grocery budget
            </p>
          </div>

          <button
            type="button"
            onClick={() => onNavigateTab('swaps')}
            className="text-xs font-bold text-[#113826] hover:text-[#65A30D] hover:underline whitespace-nowrap shrink-0 flex items-center gap-1"
          >
            <span>Explore Budget Swaps</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {budgetFriendlyRecipes.map((recipe) => (
            <RecipeCard
              key={recipe.id}
              recipe={recipe}
              settings={settings}
              onSelect={onSelectRecipe}
              onQuickAddToPlan={() => onNavigateTab('planner')}
              onQuickLogMeal={() => onQuickLogMeal(recipe)}
            />
          ))}
        </div>
      </section>
    </div>
  );
};
