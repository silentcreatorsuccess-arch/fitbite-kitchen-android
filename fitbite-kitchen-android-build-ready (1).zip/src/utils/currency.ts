import { CurrencyCode } from '../types';
import { SUPPORTED_REGIONS, CURRENCY_SYMBOLS } from '../data/regions';

export function getCurrencyMultiplier(currency: CurrencyCode): number {
  const match = SUPPORTED_REGIONS.find(r => r.currency === currency);
  return match ? match.priceMultiplierFromPhp : 1.0;
}

export function convertPhpToCurrency(amountPhp: number, currency: CurrencyCode): number {
  const multiplier = getCurrencyMultiplier(currency);
  return amountPhp * multiplier;
}

export function convertCurrencyToPhp(amountInCurrency: number, currency: CurrencyCode): number {
  const multiplier = getCurrencyMultiplier(currency);
  if (multiplier === 0) return amountInCurrency;
  return amountInCurrency / multiplier;
}

export function formatCurrency(
  amountInPhp: number, 
  currency: CurrencyCode, 
  includeEstimateTilde = true
): string {
  const symbol = CURRENCY_SYMBOLS[currency] || '₱';
  const converted = convertPhpToCurrency(amountInPhp, currency);
  
  let formattedNumber: string;
  if (currency === 'JPY') {
    formattedNumber = Math.round(converted).toLocaleString();
  } else {
    formattedNumber = converted.toFixed(2);
  }

  const prefix = includeEstimateTilde ? '~' : '';
  return `${prefix}${symbol}${formattedNumber}`;
}

export function formatRawCurrency(
  amountInTargetCurrency: number, 
  currency: CurrencyCode
): string {
  const symbol = CURRENCY_SYMBOLS[currency] || '₱';
  if (currency === 'JPY') {
    return `${symbol}${Math.round(amountInTargetCurrency).toLocaleString()}`;
  }
  return `${symbol}${amountInTargetCurrency.toFixed(2)}`;
}
