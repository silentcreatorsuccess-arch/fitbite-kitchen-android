import { UserSettings, LoggedMealEntry, WaterLogEntry, MealPlanItem, ShoppingListItem } from '../types';

const SETTINGS_KEY = 'fitbite_settings_v1';
const MEALS_LOG_KEY = 'fitbite_logged_meals_v1';
const WATER_LOG_KEY = 'fitbite_water_logs_v1';
const MEAL_PLAN_KEY = 'fitbite_meal_plan_v1';
const SHOPPING_LIST_KEY = 'fitbite_shopping_list_v1';

export const DEFAULT_SETTINGS: UserSettings = {
  countryCode: 'PH',
  countryName: 'Philippines',
  currency: 'PHP',
  unitSystem: 'metric',
  dailyCalorieTarget: 2000,
  dailyWaterTargetMl: 2500,
  maxBudgetPerServing: 120, // ₱120 default per serving
  dietaryPreference: 'all',
  activeFitnessGoal: 'all',
  hasCompletedOnboarding: false,
  customIngredientPrices: {}
};

export function getStoredSettings(): UserSettings {
  try {
    const raw = localStorage.getItem(SETTINGS_KEY);
    if (!raw) return DEFAULT_SETTINGS;
    return { ...DEFAULT_SETTINGS, ...JSON.parse(raw) };
  } catch {
    return DEFAULT_SETTINGS;
  }
}

export function saveStoredSettings(settings: UserSettings): void {
  try {
    localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
  } catch (err) {
    console.warn('Failed to save settings to localStorage', err);
  }
}

export function getStoredLoggedMeals(): LoggedMealEntry[] {
  try {
    const raw = localStorage.getItem(MEALS_LOG_KEY);
    if (!raw) return getInitialLoggedMeals();
    return JSON.parse(raw);
  } catch {
    return getInitialLoggedMeals();
  }
}

export function saveStoredLoggedMeals(meals: LoggedMealEntry[]): void {
  try {
    localStorage.setItem(MEALS_LOG_KEY, JSON.stringify(meals));
  } catch (err) {
    console.warn('Failed to save meals to localStorage', err);
  }
}

export function getStoredWaterLogs(): WaterLogEntry[] {
  try {
    const raw = localStorage.getItem(WATER_LOG_KEY);
    if (!raw) return getInitialWaterLogs();
    return JSON.parse(raw);
  } catch {
    return getInitialWaterLogs();
  }
}

export function saveStoredWaterLogs(logs: WaterLogEntry[]): void {
  try {
    localStorage.setItem(WATER_LOG_KEY, JSON.stringify(logs));
  } catch (err) {
    console.warn('Failed to save water logs to localStorage', err);
  }
}

export function getStoredMealPlan(): MealPlanItem[] {
  try {
    const raw = localStorage.getItem(MEAL_PLAN_KEY);
    if (!raw) return getInitialMealPlan();
    return JSON.parse(raw);
  } catch {
    return getInitialMealPlan();
  }
}

export function saveStoredMealPlan(items: MealPlanItem[]): void {
  try {
    localStorage.setItem(MEAL_PLAN_KEY, JSON.stringify(items));
  } catch (err) {
    console.warn('Failed to save meal plan to localStorage', err);
  }
}

export function getStoredShoppingList(): ShoppingListItem[] {
  try {
    const raw = localStorage.getItem(SHOPPING_LIST_KEY);
    if (!raw) return [];
    return JSON.parse(raw);
  } catch {
    return [];
  }
}

export function saveStoredShoppingList(items: ShoppingListItem[]): void {
  try {
    localStorage.setItem(SHOPPING_LIST_KEY, JSON.stringify(items));
  } catch (err) {
    console.warn('Failed to save shopping list to localStorage', err);
  }
}

// Starter sample data for fresh experience
function getInitialLoggedMeals(): LoggedMealEntry[] {
  const today = new Date().toISOString().split('T')[0];
  return [
    {
      id: 'init-1',
      timestamp: new Date().toISOString(),
      dateString: today,
      mealType: 'breakfast',
      foodName: 'Protein Overnight Chia & Oat Bowl with Banana',
      servings: 1,
      calories: 310,
      proteinGrams: 16,
      carbsGrams: 45,
      fatGrams: 9,
      recipeId: 'overnight-chia-oat-bowl'
    },
    {
      id: 'init-2',
      timestamp: new Date().toISOString(),
      dateString: today,
      mealType: 'lunch',
      foodName: 'Chicken Tinola with Sayote & Malunggay',
      servings: 1,
      calories: 275,
      proteinGrams: 32,
      carbsGrams: 10,
      fatGrams: 11,
      recipeId: 'tinola-chicken-malunggay'
    }
  ];
}

function getInitialWaterLogs(): WaterLogEntry[] {
  return [
    { id: 'w-1', timestamp: new Date(Date.now() - 3 * 3600 * 1000).toISOString(), amountMl: 500 },
    { id: 'w-2', timestamp: new Date(Date.now() - 1 * 3600 * 1000).toISOString(), amountMl: 350 },
    { id: 'w-3', timestamp: new Date().toISOString(), amountMl: 250 }
  ];
}

function getInitialMealPlan(): MealPlanItem[] {
  // Day indices 0=Mon ... 6=Sun
  const todayIndex = (new Date().getDay() + 6) % 7; // Convert 0(Sun) to 6, 1(Mon) to 0
  return [
    {
      id: 'plan-1',
      dayIndex: todayIndex,
      mealType: 'breakfast',
      recipeId: 'overnight-chia-oat-bowl',
      recipeTitle: 'Protein Overnight Chia & Oat Bowl',
      servings: 1,
      calories: 310,
      costPhp: 34
    },
    {
      id: 'plan-2',
      dayIndex: todayIndex,
      mealType: 'lunch',
      recipeId: 'tinola-chicken-malunggay',
      recipeTitle: 'Chicken Tinola with Sayote & Malunggay',
      servings: 1,
      calories: 275,
      costPhp: 65
    },
    {
      id: 'plan-3',
      dayIndex: todayIndex,
      mealType: 'dinner',
      recipeId: 'ginisang-monggo-tofu',
      recipeTitle: 'Ginisang Mung Bean Soup with Tofu',
      servings: 1,
      calories: 260,
      costPhp: 42
    },
    {
      id: 'plan-4',
      dayIndex: (todayIndex + 1) % 7,
      mealType: 'lunch',
      recipeId: 'pinakbet-tilapia',
      recipeTitle: 'Pinakbet Tagalog with Tilapia',
      servings: 1,
      calories: 285,
      costPhp: 68
    }
  ];
}
