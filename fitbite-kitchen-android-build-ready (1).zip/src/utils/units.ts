import { UnitSystem } from '../types';

export function formatIngredientQuantity(
  amountMetric: number,
  unitMetric: string,
  amountCustomary: number,
  unitCustomary: string,
  system: UnitSystem,
  servingsScale: number = 1
): string {
  const scaledMetric = amountMetric * servingsScale;
  const scaledCustomary = amountCustomary * servingsScale;

  if (system === 'us_customary') {
    const formatted = scaledCustomary % 1 === 0 
      ? scaledCustomary.toString() 
      : scaledCustomary.toFixed(1).replace(/\.0$/, '');
    return `${formatted} ${unitCustomary}`;
  } else {
    // Metric
    let displayAmount = scaledMetric;
    let displayUnit = unitMetric;
    if (unitMetric === 'g' && displayAmount >= 1000) {
      displayAmount = displayAmount / 1000;
      displayUnit = 'kg';
    } else if (unitMetric === 'ml' && displayAmount >= 1000) {
      displayAmount = displayAmount / 1000;
      displayUnit = 'L';
    }
    const formatted = displayAmount % 1 === 0 
      ? displayAmount.toString() 
      : displayAmount.toFixed(1).replace(/\.0$/, '');
    return `${formatted} ${displayUnit}`;
  }
}

export function formatWaterAmount(ml: number, system: UnitSystem): string {
  if (system === 'us_customary') {
    // 1 fl oz = 29.5735 mL
    const flOz = ml / 29.5735;
    return `${Math.round(flOz)} fl oz`;
  }
  if (ml >= 1000) {
    return `${(ml / 1000).toFixed(1).replace(/\.0$/, '')} L`;
  }
  return `${Math.round(ml)} mL`;
}

export function formatTemperature(celsius: number, system: UnitSystem): string {
  if (system === 'us_customary') {
    const fahrenheit = Math.round((celsius * 9) / 5 + 32);
    return `${fahrenheit}°F`;
  }
  return `${celsius}°C`;
}
