import { CurrencyCode, UnitSystem } from '../types';

export interface RegionDefinition {
  code: string;
  name: string;
  currency: CurrencyCode;
  currencySymbol: string;
  defaultUnitSystem: UnitSystem;
  flag: string;
  // Relative price purchasing parity / benchmark multiplier relative to PHP base
  // e.g. In USD grocery market, typical equivalent fresh ingredients reflect local grocery indices
  // Rather than just converting ₱100 / 58 = $1.72 (which is unrealistically cheap in the US),
  // we provide a realistic local grocery benchmark baseline, while making all prices user-editable!
  priceMultiplierFromPhp: number;
  popularIngredients: string[];
}

export const SUPPORTED_REGIONS: RegionDefinition[] = [
  {
    code: 'PH',
    name: 'Philippines',
    currency: 'PHP',
    currencySymbol: '₱',
    defaultUnitSystem: 'metric',
    flag: '🇵🇭',
    priceMultiplierFromPhp: 1.0,
    popularIngredients: ['Malunggay', 'Kangkong', 'Sayote', 'Tilapia', 'Bangus', 'Calamansi', 'Tofu']
  },
  {
    code: 'US',
    name: 'United States',
    currency: 'USD',
    currencySymbol: '$',
    defaultUnitSystem: 'us_customary',
    flag: '🇺🇸',
    // ₱100 PHP baseline (~$1.72 nominal) ≈ ~$3.50 US grocery benchmark
    priceMultiplierFromPhp: 0.035,
    popularIngredients: ['Spinach', 'Zucchini', 'Chicken Breast', 'Salmon', 'Sweet Potatoes', 'Greek Yogurt']
  },
  {
    code: 'GB',
    name: 'United Kingdom',
    currency: 'GBP',
    currencySymbol: '£',
    defaultUnitSystem: 'metric',
    flag: '🇬🇧',
    // ₱100 PHP baseline ≈ £2.60 UK benchmark
    priceMultiplierFromPhp: 0.026,
    popularIngredients: ['Kale', 'Broccoli', 'Eggs', 'Canned Lentils', 'Cod Fillet', 'Cheddar']
  },
  {
    code: 'EU',
    name: 'European Union (Eurozone)',
    currency: 'EUR',
    currencySymbol: '€',
    defaultUnitSystem: 'metric',
    flag: '🇪🇺',
    // ₱100 PHP baseline ≈ €3.00 EU benchmark
    priceMultiplierFromPhp: 0.030,
    popularIngredients: ['Olive Oil', 'Tomatoes', 'Zucchini', 'Chicken Thighs', 'Trout', 'Lentils']
  },
  {
    code: 'CA',
    name: 'Canada',
    currency: 'CAD',
    currencySymbol: '$',
    defaultUnitSystem: 'metric',
    flag: '🇨🇦',
    // ₱100 PHP baseline ≈ $4.20 CAD benchmark
    priceMultiplierFromPhp: 0.042,
    popularIngredients: ['Spinach', 'Carrots', 'Ground Turkey', 'Eggs', 'Chickpeas', 'Oats']
  },
  {
    code: 'AU',
    name: 'Australia',
    currency: 'AUD',
    currencySymbol: '$',
    defaultUnitSystem: 'metric',
    flag: '🇦🇺',
    // ₱100 PHP baseline ≈ $4.50 AUD benchmark
    priceMultiplierFromPhp: 0.045,
    popularIngredients: ['Bok Choy', 'Broccolini', 'Barramundi', 'Kangaroo / Lean Beef', 'Avocado']
  },
  {
    code: 'JP',
    name: 'Japan',
    currency: 'JPY',
    currencySymbol: '¥',
    defaultUnitSystem: 'metric',
    flag: '🇯🇵',
    // ₱100 PHP baseline ≈ ¥450 JPY benchmark
    priceMultiplierFromPhp: 4.5,
    popularIngredients: ['Tofu', 'Edamame', 'Daikon', 'Salmon', 'Eggs', 'Cabbage', 'Sesame']
  },
  {
    code: 'SG',
    name: 'Singapore',
    currency: 'SGD',
    currencySymbol: 'S$',
    defaultUnitSystem: 'metric',
    flag: '🇸🇬',
    // ₱100 PHP baseline ≈ S$3.80 benchmark
    priceMultiplierFromPhp: 0.038,
    popularIngredients: ['Kangkong', 'Choy Sum', 'Chicken Thigh', 'Tofu', 'Prawns', 'Brown Rice']
  }
];

export const CURRENCY_SYMBOLS: Record<CurrencyCode, string> = {
  PHP: '₱',
  USD: '$',
  EUR: '€',
  GBP: '£',
  CAD: 'CA$',
  AUD: 'AU$',
  JPY: '¥',
  SGD: 'S$'
};
