import { Recipe } from '../types';

export const RECIPES: Recipe[] = [
  {
    id: 'tinola-chicken-malunggay',
    title: 'Chicken Tinola with Sayote & Malunggay',
    filipinoName: 'Tinolang Manok',
    description: 'A comforting, ginger-rich Filipino soup loaded with nutrient-dense moringa (malunggay) leaves and tender chayote squash.',
    cuisine: 'filipino',
    prepTimeMinutes: 15,
    cookTimeMinutes: 30,
    servings: 4,
    difficulty: 'Beginner',
    budgetTier: 'budget',
    fitnessGoals: ['calorie_deficit', 'new_to_balanced', 'general_healthy', 'build_muscle', 'weight_management', 'high_protein', 'general_health'],
    dietaryTags: ['High Protein', 'Budget Friendly', 'High Fiber'],
    calories: 275,
    proteinGrams: 32,
    carbsGrams: 10,
    fatGrams: 11,
    fiberGrams: 3,
    baseCostPhp: 65,
    imageEmoji: '🍲',
    hasRealPhoto: true,
    imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/c/cb/Tinola.jpg',
    imageAlt: 'Authentic Filipino Chicken Tinola soup with chicken pieces, sayote squash, and green malunggay leaves in ginger broth',
    photoCredit: {
      photographer: 'Wikimedia Commons Contributor',
      source: 'Wikimedia Commons (Public Domain)',
      sourceUrl: 'https://commons.wikimedia.org/wiki/File:Tinola.jpg'
    },
    accentColor: '#2D5A46',
    ingredients: [
      { id: 't1', name: 'Chicken breast or bone-in thighs', category: 'meat_seafood', amountMetric: 500, unitMetric: 'g', amountCustomary: 1.1, unitCustomary: 'lb', estimatedCostPhp: 130 },
      { id: 't2', name: 'Fresh ginger, sliced thinly', category: 'produce', amountMetric: 40, unitMetric: 'g', amountCustomary: 1.4, unitCustomary: 'oz', estimatedCostPhp: 15 },
      { id: 't3', name: 'Sayote (Chayote), cubed', category: 'produce', amountMetric: 1, unitMetric: 'pc', amountCustomary: 1, unitCustomary: 'pc', estimatedCostPhp: 25 },
      { id: 't4', name: 'Fresh Malunggay (Moringa) leaves', category: 'produce', amountMetric: 80, unitMetric: 'g', amountCustomary: 2, unitCustomary: 'cup', estimatedCostPhp: 15 },
      { id: 't5', name: 'Garlic & Onion', category: 'produce', amountMetric: 4, unitMetric: 'clove', amountCustomary: 4, unitCustomary: 'clove', estimatedCostPhp: 12 },
      { id: 't6', name: 'Fish sauce (Patis) or low-sodium soy sauce', category: 'seasoning_oil', amountMetric: 15, unitMetric: 'ml', amountCustomary: 1, unitCustomary: 'tbsp', estimatedCostPhp: 8 },
      { id: 't7', name: 'Canola oil or olive oil', category: 'seasoning_oil', amountMetric: 10, unitMetric: 'ml', amountCustomary: 2, unitCustomary: 'tsp', estimatedCostPhp: 5 },
      { id: 't8', name: 'Water or rice-washing water', category: 'pantry_grains', amountMetric: 1000, unitMetric: 'ml', amountCustomary: 4, unitCustomary: 'cup', estimatedCostPhp: 0 }
    ],
    instructions: [
      'In a medium stockpot, heat oil over medium heat. Sauté sliced ginger, minced garlic, and sliced onion until fragrant and slightly golden (3-4 minutes).',
      'Add chicken pieces and sear for 4-5 minutes until the outer edges turn opaque. Add fish sauce and gently stir to infuse flavors.',
      'Pour in 4 cups of water or rice-washing water. Bring to a rapid boil, skim off any surface foam, then lower heat to a gentle simmer. Cover and cook for 15 minutes.',
      'Add cubed sayote (or green papaya) and simmer for another 6-8 minutes until tender-crisp.',
      'Turn off the heat, stir in fresh malunggay leaves, cover the pot, and let steam for 2 minutes before serving hot.'
    ],
    swaps: [
      {
        id: 'swap-t1',
        originalIngredient: 'Chicken Breast (500g)',
        swapIngredient: 'Firm Tofu + Hard-Boiled Eggs',
        savingsPhpPerServing: 22,
        reason: 'Tofu and eggs provide high-quality protein at almost half the cost in wet markets.',
        culinaryTip: 'Cube firm tofu and lightly pan-sear before adding to the broth to retain texture.'
      },
      {
        id: 'swap-t2',
        originalIngredient: 'Malunggay (bought)',
        swapIngredient: 'Spinach, Kangkong, or Backyard Moringa',
        savingsPhpPerServing: 5,
        reason: 'Malunggay often grows wild in Philippine neighborhoods or kangkong is readily available.',
        culinaryTip: 'Add kangkong stalks 1 minute before leaves so they cook evenly.'
      }
    ],
    beginnerTip: 'Do not overcook malunggay leaves! Always stir them in after turning off the burner to keep their vibrant green color and preserve heat-sensitive vitamins.',
    commonMistakes: [
      'Boiling malunggay with vigorous heat, which causes bitter notes and turns greens brown.',
      'Skipping the ginger sauté step, which is essential to eliminate any raw poultry odor.'
    ],
    servingSuggestions: 'Serve steaming hot in a deep ceramic bowl alongside half a cup of warm brown rice or Philippine adlai.',
    storageAdvice: 'Store in an airtight container in the refrigerator for up to 3 days. Broth deepens in flavor overnight.',
    reheatingAdvice: 'Reheat on the stovetop over medium heat until gently bubbling. If reheating in a microwave, heat covered for 2-3 minutes.'
  },
  {
    id: 'healthy-chicken-adobo',
    title: 'Balanced Chicken & Egg Adobo',
    filipinoName: 'Adobong Manok at Itlog',
    description: 'A lighter, lower-sodium interpretation of the quintessential Filipino classic, enriched with protein from hard-boiled eggs and simmered with cider vinegar and whole peppercorns.',
    cuisine: 'filipino',
    prepTimeMinutes: 10,
    cookTimeMinutes: 35,
    servings: 4,
    difficulty: 'Beginner',
    budgetTier: 'budget',
    fitnessGoals: ['build_muscle', 'calorie_deficit', 'general_healthy', 'high_protein', 'muscle_building', 'weight_management'],
    dietaryTags: ['High Protein', 'Budget Friendly'],
    calories: 330,
    proteinGrams: 38,
    carbsGrams: 6,
    fatGrams: 16,
    fiberGrams: 1,
    baseCostPhp: 72,
    imageEmoji: '🍗',
    hasRealPhoto: true,
    imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/thumb/3/38/Chicken_adobo.jpg/960px-Chicken_adobo.jpg',
    imageAlt: 'Authentic Filipino Chicken Adobo with chicken pieces braised in rich, dark savory soy sauce, vinegar, crushed garlic, and peppercorns',
    photoCredit: {
      photographer: 'Obsidian Soul',
      source: 'Wikimedia Commons (CC BY-SA 3.0)',
      sourceUrl: 'https://commons.wikimedia.org/wiki/File:Chicken_adobo_on_plate.jpg'
    },
    accentColor: '#3C402E',
    ingredients: [
      { id: 'a1', name: 'Skinless chicken thighs or breast', category: 'meat_seafood', amountMetric: 500, unitMetric: 'g', amountCustomary: 1.1, unitCustomary: 'lb', estimatedCostPhp: 135 },
      { id: 'a2', name: 'Hard-boiled eggs, peeled', category: 'meat_seafood', amountMetric: 4, unitMetric: 'pc', amountCustomary: 4, unitCustomary: 'pc', estimatedCostPhp: 36 },
      { id: 'a3', name: 'Low-sodium soy sauce or coconut aminos', category: 'seasoning_oil', amountMetric: 45, unitMetric: 'ml', amountCustomary: 3, unitCustomary: 'tbsp', estimatedCostPhp: 15 },
      { id: 'a4', name: 'Cane vinegar or apple cider vinegar', category: 'seasoning_oil', amountMetric: 60, unitMetric: 'ml', amountCustomary: 0.25, unitCustomary: 'cup', estimatedCostPhp: 12 },
      { id: 'a5', name: 'Crushed garlic cloves', category: 'produce', amountMetric: 6, unitMetric: 'clove', amountCustomary: 6, unitCustomary: 'clove', estimatedCostPhp: 10 },
      { id: 'a6', name: 'Bay leaves (Laurel) & black peppercorns', category: 'seasoning_oil', amountMetric: 3, unitMetric: 'pc', amountCustomary: 3, unitCustomary: 'pc', estimatedCostPhp: 5 },
      { id: 'a7', name: 'Water', category: 'pantry_grains', amountMetric: 180, unitMetric: 'ml', amountCustomary: 0.75, unitCustomary: 'cup', estimatedCostPhp: 0 }
    ],
    instructions: [
      'Marinate chicken pieces in soy sauce, vinegar, crushed garlic, and black peppercorns in a bowl for 15 minutes.',
      'Transfer the chicken, marinade, bay leaves, and water into a deep pan or pot. Bring to a gentle simmer over medium heat without stirring the vinegar for 5 minutes (this mellows the acidity).',
      'Cover with a lid and simmer gently for 20 minutes until chicken is tender.',
      'Gently fold in the peeled hard-boiled eggs so they soak up the rich savory sauce.',
      'Uncover and let the sauce reduce to your preferred consistency (approx 5-7 minutes).'
    ],
    swaps: [
      {
        id: 'swap-a1',
        originalIngredient: 'Skinless Chicken (500g)',
        swapIngredient: 'Half Chicken + Extra Firm Tofu cubes',
        savingsPhpPerServing: 18,
        reason: 'Swapping half the poultry with fried or air-fried tofu stretches the protein budget significantly.',
        culinaryTip: 'Tofu absorbs adobo vinegar sauce deliciously.'
      }
    ],
    beginnerTip: 'Resist stirring immediately after pouring vinegar; let it steam uncovered for 3-5 minutes so the raw vinegar smell evaporates into sweet, tangy aroma.',
    commonMistakes: [
      'Stirring the pot the moment vinegar is added; this creates a harsh raw acidity instead of smooth glaze.',
      'Using high heat which can toughen chicken breast; keep on a steady, gentle simmer.'
    ],
    servingSuggestions: 'Top with toasted garlic chips and spoon sauce over steamed cauliflower rice or garlic brown rice.',
    storageAdvice: 'Adobo is famous for tasting even better on days 2 and 3 as the meat marinates in vinegar. Keeps 5 days refrigerated.',
    reheatingAdvice: 'Reheat in a small pan on low heat with 1 tablespoon of water to revive the glossy sauce.'
  },
  {
    id: 'sinigang-bangus-kangkong',
    title: 'Milkfish Tamarind Soup with Kangkong',
    filipinoName: 'Sinigang na Bangus',
    description: 'A tangy, heart-healthy fish soup featuring milkfish (bangus), water spinach (kangkong), radish, and fresh tomatoes in a natural tamarind broth.',
    cuisine: 'filipino',
    prepTimeMinutes: 15,
    cookTimeMinutes: 20,
    servings: 4,
    difficulty: 'Beginner',
    budgetTier: 'mid',
    fitnessGoals: ['calorie_deficit', 'general_healthy', 'new_to_balanced', 'weight_management', 'general_health', 'high_protein'],
    dietaryTags: ['High Protein', 'Low Carb', 'High Fiber'],
    calories: 240,
    proteinGrams: 28,
    carbsGrams: 9,
    fatGrams: 10,
    fiberGrams: 3,
    baseCostPhp: 85,
    imageEmoji: '🐟',
    hasRealPhoto: true,
    imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/thumb/4/46/Sinigang_na_bangus_at_santol_%28sinigang_with_milkfish_and_santol%29.jpg/960px-Sinigang_na_bangus_at_santol_%28sinigang_with_milkfish_and_santol%29.jpg',
    imageAlt: 'Authentic Filipino Sinigang na Bangus milkfish steaks simmered in sour tamarind broth with fresh vegetables',
    photoCredit: {
      photographer: 'Judgefloro',
      source: 'Wikimedia Commons (CC BY-SA 4.0)',
      sourceUrl: 'https://commons.wikimedia.org/wiki/File:Sinigang_na_bangus_at_santol_(sinigang_with_milkfish_and_santol).jpg'
    },
    accentColor: '#1E3A2B',
    ingredients: [
      { id: 's1', name: 'Fresh Bangus (Milkfish), sliced into steaks', category: 'meat_seafood', amountMetric: 500, unitMetric: 'g', amountCustomary: 1.1, unitCustomary: 'lb', estimatedCostPhp: 170 },
      { id: 's2', name: 'Kangkong (Water spinach) bundle, trimmed', category: 'produce', amountMetric: 150, unitMetric: 'g', amountCustomary: 5, unitCustomary: 'oz', estimatedCostPhp: 20 },
      { id: 's3', name: 'White radish (Labanos), sliced into rounds', category: 'produce', amountMetric: 1, unitMetric: 'pc', amountCustomary: 1, unitCustomary: 'pc', estimatedCostPhp: 20 },
      { id: 's4', name: 'Ripe red tomatoes, quartered', category: 'produce', amountMetric: 2, unitMetric: 'pc', amountCustomary: 2, unitCustomary: 'pc', estimatedCostPhp: 16 },
      { id: 's5', name: 'Red onion & green finger chilies (siling haba)', category: 'produce', amountMetric: 1, unitMetric: 'pc', amountCustomary: 1, unitCustomary: 'pc', estimatedCostPhp: 12 },
      { id: 's6', name: 'Tamarind pulp or natural sinigang mix', category: 'seasoning_oil', amountMetric: 25, unitMetric: 'g', amountCustomary: 1, unitCustomary: 'oz', estimatedCostPhp: 18 },
      { id: 's7', name: 'Water', category: 'pantry_grains', amountMetric: 1200, unitMetric: 'ml', amountCustomary: 5, unitCustomary: 'cup', estimatedCostPhp: 0 }
    ],
    instructions: [
      'In a medium soup pot, combine water, quartered tomatoes, and sliced onion. Bring to a rolling boil for 6-8 minutes until tomatoes soften.',
      'Add sliced radish (labanos) and whole green finger chili. Cook for 3 minutes.',
      'Gently lower the clean bangus slices into the boiling broth. Lower heat to medium and simmer for 5-7 minutes until fish flakes easily.',
      'Stir in tamarind souring agent or natural pulp. Season with a touch of patis or sea salt to taste.',
      'Add the kangkong stalks and leaves. Push down into hot soup and turn off heat immediately. Serve hot.'
    ],
    swaps: [
      {
        id: 'swap-s1',
        originalIngredient: 'Fresh Bangus Steaks',
        swapIngredient: 'Tilapia Fillet or Canned Tuna in Water',
        savingsPhpPerServing: 28,
        reason: 'Tilapia is often 30-40% more budget-friendly than milkfish and has lower prep time.',
        culinaryTip: 'Canned tuna in spring water added in the last 2 minutes makes an ultra-fast emergency sinigang!'
      },
      {
        id: 'swap-s2',
        originalIngredient: 'Kangkong bundle',
        swapIngredient: 'Bok Choy or Savoy Cabbage',
        savingsPhpPerServing: 0,
        reason: 'Great international substitute when leafy water spinach is unavailable outside Southeast Asia.',
        culinaryTip: 'Bok choy offers the same crisp stem and tender leaf contrast.'
      }
    ],
    beginnerTip: 'Fish cooks very quickly! Remove the pot from heat as soon as the fish meat turns opaque white to prevent it from breaking apart.',
    commonMistakes: [
      'Over-stirring the pot after adding fish, which breaks delicate fish flakes into the soup.',
      'Adding tamarind too early before tomatoes release their natural sweetness.'
    ],
    servingSuggestions: 'Serve with a small dipping saucer of calamansi, crushed chili, and low-sodium fish sauce.',
    storageAdvice: 'Refrigerate for up to 2 days. Fish soups are best consumed fresh to prevent fishy flavor buildup.',
    reheatingAdvice: 'Reheat gently on low heat until broth is hot; do not boil vigorously or fish will disintegrate.'
  },
  {
    id: 'ginisang-monggo-tofu',
    title: 'Ginisang Mung Bean Soup with Tofu & Spinach',
    filipinoName: 'Ginisang Monggo',
    description: 'The golden Filipino comfort staple: protein-rich mung beans simmered till creamy with pan-seared crispy tofu cubes and fresh leafy greens.',
    cuisine: 'filipino',
    prepTimeMinutes: 10,
    cookTimeMinutes: 40,
    servings: 4,
    difficulty: 'Beginner',
    budgetTier: 'budget',
    fitnessGoals: ['new_to_balanced', 'general_healthy', 'calorie_deficit', 'build_muscle', 'weight_management', 'high_protein', 'general_health'],
    dietaryTags: ['High Fiber', 'Budget Friendly', 'High Protein', 'Vegetarian'],
    calories: 260,
    proteinGrams: 20,
    carbsGrams: 34,
    fatGrams: 5,
    fiberGrams: 11,
    baseCostPhp: 42,
    imageEmoji: '🥣',
    hasRealPhoto: true,
    imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/thumb/c/c4/Ginisang_munggo_with_fried_bangus.jpg/960px-Ginisang_munggo_with_fried_bangus.jpg',
    imageAlt: 'Authentic Filipino Ginisang Monggo savory mung bean stew with fresh green leaves',
    photoCredit: {
      photographer: 'Judgefloro',
      source: 'Wikimedia Commons (CC BY-SA 4.0)',
      sourceUrl: 'https://commons.wikimedia.org/wiki/File:Ginisang_munggo_with_fried_bangus.jpg'
    },
    accentColor: '#4A6B48',
    ingredients: [
      { id: 'm1', name: 'Green mung beans (monggo), washed', category: 'pantry_grains', amountMetric: 200, unitMetric: 'g', amountCustomary: 1, unitCustomary: 'cup', estimatedCostPhp: 35 },
      { id: 'm2', name: 'Firm white tofu (tokwa), cubed', category: 'meat_seafood', amountMetric: 250, unitMetric: 'g', amountCustomary: 9, unitCustomary: 'oz', estimatedCostPhp: 35 },
      { id: 'm3', name: 'Malunggay leaves or baby spinach', category: 'produce', amountMetric: 100, unitMetric: 'g', amountCustomary: 2.5, unitCustomary: 'cup', estimatedCostPhp: 20 },
      { id: 'm4', name: 'Garlic, onion, and ripe tomato', category: 'produce', amountMetric: 3, unitMetric: 'pc', amountCustomary: 3, unitCustomary: 'pc', estimatedCostPhp: 18 },
      { id: 'm5', name: 'Canola oil or sesame oil', category: 'seasoning_oil', amountMetric: 10, unitMetric: 'ml', amountCustomary: 2, unitCustomary: 'tsp', estimatedCostPhp: 5 },
      { id: 'm6', name: 'Water or vegetable broth', category: 'pantry_grains', amountMetric: 1200, unitMetric: 'ml', amountCustomary: 5, unitCustomary: 'cup', estimatedCostPhp: 0 }
    ],
    instructions: [
      'In a pot, combine washed mung beans with 4 cups of water. Boil over medium heat for 30 minutes until beans pop open and become soft and creamy.',
      'In a separate skillet, pan-sear cubed tofu with 1 tsp oil until golden crisp on all sides. Set aside.',
      'In the same skillet, sauté garlic, onion, and diced tomatoes until fragrant and soft.',
      'Pour the sautéed mixture and crispy tofu into the cooked mung bean pot. Stir well and simmer for 5 minutes so beans absorb the aromatics.',
      'Fold in the fresh malunggay or spinach leaves. Turn off burner and cover for 2 minutes to gently wilt.'
    ],
    swaps: [
      {
        id: 'swap-m1',
        originalIngredient: 'Green Mung Beans',
        swapIngredient: 'Red or Brown Lentils',
        savingsPhpPerServing: 0,
        reason: 'Lentils cook in just 15 minutes without pre-soaking and are available in any international grocery.',
        culinaryTip: 'Red lentils break down into the exact same rich, creamy stew texture.'
      }
    ],
    beginnerTip: 'Soaking mung beans in warm water for 30 minutes before cooking cuts boiling time nearly in half.',
    commonMistakes: [
      'Not boiling the beans until completely soft before adding seasonings; salt can slightly slow down bean softening.',
      'Letting the pot boil dry; add warm water whenever liquid drops below bean level.'
    ],
    servingSuggestions: 'Pairs perfectly with steamed red or brown rice and a side of sliced fresh tomatoes.',
    storageAdvice: 'Keeps wonderfully in the fridge for up to 4 days, or freeze in portions for up to 2 months.',
    reheatingAdvice: 'Mung beans thicken as they cool; stir in 2-3 tablespoons of water when reheating on the stove.'
  },
  {
    id: 'pinakbet-tilapia',
    title: 'Pinakbet Tagalog with Pan-Seared Tilapia',
    filipinoName: 'Pinakbet Tagalog',
    description: 'A colorful medley of squash, yardlong string beans, eggplant, and okra cooked with a hint of fermented paste, topped with crisp tilapia.',
    cuisine: 'filipino',
    prepTimeMinutes: 15,
    cookTimeMinutes: 25,
    servings: 4,
    difficulty: 'Beginner',
    budgetTier: 'budget',
    fitnessGoals: ['calorie_deficit', 'general_healthy', 'new_to_balanced', 'weight_management', 'general_health', 'high_protein'],
    dietaryTags: ['High Fiber', 'Budget Friendly', 'High Protein'],
    calories: 285,
    proteinGrams: 26,
    carbsGrams: 22,
    fatGrams: 9,
    fiberGrams: 6,
    baseCostPhp: 68,
    imageEmoji: '🍆',
    hasRealPhoto: true,
    imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/thumb/6/61/Pinakbet.jpg/960px-Pinakbet.jpg',
    imageAlt: 'Authentic Filipino Pinakbet Tagalog simmered vegetable medley with squash, yardlong beans, and eggplant',
    photoCredit: {
      photographer: 'Wikimedia Commons Contributor',
      source: 'Wikimedia Commons (CC BY-SA 2.0)',
      sourceUrl: 'https://commons.wikimedia.org/wiki/File:Pinakbet.jpg'
    },
    accentColor: '#3B5838',
    ingredients: [
      { id: 'p1', name: 'Tilapia fillet or cleaned whole tilapia', category: 'meat_seafood', amountMetric: 400, unitMetric: 'g', amountCustomary: 14, unitCustomary: 'oz', estimatedCostPhp: 110 },
      { id: 'p2', name: 'Kabasaya (Squash / Kalabasa), cubed', category: 'produce', amountMetric: 200, unitMetric: 'g', amountCustomary: 7, unitCustomary: 'oz', estimatedCostPhp: 25 },
      { id: 'p3', name: 'Sitaw (Yardlong beans), cut into 2-inch pieces', category: 'produce', amountMetric: 100, unitMetric: 'g', amountCustomary: 3.5, unitCustomary: 'oz', estimatedCostPhp: 20 },
      { id: 'p4', name: 'Eggplant (Talong) & Okra', category: 'produce', amountMetric: 200, unitMetric: 'g', amountCustomary: 7, unitCustomary: 'oz', estimatedCostPhp: 30 },
      { id: 'p5', name: 'Garlic, onion & chopped tomatoes', category: 'produce', amountMetric: 3, unitMetric: 'pc', amountCustomary: 3, unitCustomary: 'pc', estimatedCostPhp: 18 },
      { id: 'p6', name: 'Bagoong alamang (shrimp paste) or low-salt fish sauce', category: 'seasoning_oil', amountMetric: 15, unitMetric: 'g', amountCustomary: 1, unitCustomary: 'tbsp', estimatedCostPhp: 10 },
      { id: 'p7', name: 'Cooking oil', category: 'seasoning_oil', amountMetric: 15, unitMetric: 'ml', amountCustomary: 1, unitCustomary: 'tbsp', estimatedCostPhp: 6 }
    ],
    instructions: [
      'Season tilapia lightly with salt and pepper. Pan-sear in a skillet with 1 tsp oil until cooked through and golden (3-4 mins per side). Set aside.',
      'In a wide pan, sauté garlic, onions, and tomatoes until tomatoes collapse. Add bagoong or fish sauce.',
      'Add cubed squash and 1/2 cup of water. Cover and cook for 5 minutes until squash begins to soften.',
      'Add string beans, eggplant slices, and trimmed okra. Cover and steam over medium-low heat for 6-8 minutes until tender-crisp.',
      'Plate the steamed vegetables and top with warm pan-seared tilapia.'
    ],
    swaps: [
      {
        id: 'swap-p1',
        originalIngredient: 'Yardlong beans (Sitaw)',
        swapIngredient: 'Green French Green Beans',
        savingsPhpPerServing: 0,
        reason: 'Standard green beans replicate sitaw perfectly in international markets.',
        culinaryTip: 'Snap edges and cook for 4-5 minutes.'
      }
    ],
    beginnerTip: 'Cut vegetables uniformly so the squash, eggplant, and green beans soften together at the same time.',
    commonMistakes: [
      'Overcooking the okra which makes the dish overly slimy; keep lid on and avoid excessive stirring.',
      'Cutting squash pieces too large, which delays overall cooking.'
    ],
    servingSuggestions: 'Serve with steamed brown rice and a slice of calamansi over the fish.',
    storageAdvice: 'Store vegetables and fish in separate containers in the fridge for up to 3 days.',
    reheatingAdvice: 'Reheat vegetables gently in microwave; crisp the tilapia in a toaster oven or skillet.'
  },
  {
    id: 'tortang-talong-chicken',
    title: 'Protein-Boosted Tortang Talong',
    filipinoName: 'Tortang Talong na may Giniling',
    description: 'Roasted smoked eggplant flattened and dipped in whisked eggs with savory lean chicken or turkey mince, pan-seared with minimal oil.',
    cuisine: 'filipino',
    prepTimeMinutes: 15,
    cookTimeMinutes: 15,
    servings: 2,
    difficulty: 'Beginner',
    budgetTier: 'budget',
    fitnessGoals: ['calorie_deficit', 'build_muscle', 'new_to_balanced', 'high_protein', 'weight_management', 'muscle_building'],
    dietaryTags: ['High Protein', 'Low Carb', 'Budget Friendly'],
    calories: 290,
    proteinGrams: 28,
    carbsGrams: 9,
    fatGrams: 14,
    fiberGrams: 4,
    baseCostPhp: 55,
    imageEmoji: '🍳',
    hasRealPhoto: true,
    imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/thumb/1/1e/EGGPLANT_TORTA.jpg/960px-EGGPLANT_TORTA.jpg',
    imageAlt: 'Authentic Filipino Tortang Talong pan-fried whole roasted eggplant omelet with stem intact',
    photoCredit: {
      photographer: 'Wikimedia Commons Contributor',
      source: 'Wikimedia Commons (CC BY-SA 3.0)',
      sourceUrl: 'https://commons.wikimedia.org/wiki/File:EGGPLANT_TORTA.jpg'
    },
    accentColor: '#534B36',
    ingredients: [
      { id: 'tt1', name: 'Long Asian eggplants', category: 'produce', amountMetric: 2, unitMetric: 'pc', amountCustomary: 2, unitCustomary: 'pc', estimatedCostPhp: 25 },
      { id: 'tt2', name: 'Eggs, beaten', category: 'meat_seafood', amountMetric: 3, unitMetric: 'pc', amountCustomary: 3, unitCustomary: 'pc', estimatedCostPhp: 27 },
      { id: 'tt3', name: 'Lean ground chicken or turkey', category: 'meat_seafood', amountMetric: 150, unitMetric: 'g', amountCustomary: 5.3, unitCustomary: 'oz', estimatedCostPhp: 45 },
      { id: 'tt4', name: 'Minced garlic and green onions', category: 'produce', amountMetric: 2, unitMetric: 'clove', amountCustomary: 2, unitCustomary: 'clove', estimatedCostPhp: 8 },
      { id: 'tt5', name: 'Cooking spray or light olive oil', category: 'seasoning_oil', amountMetric: 5, unitMetric: 'ml', amountCustomary: 1, unitCustomary: 'tsp', estimatedCostPhp: 5 }
    ],
    instructions: [
      'Char eggplants over open flame, stove burner, or oven broiler for 8-10 minutes until skin is blackened and flesh is very soft. Let cool, peel off blackened skin, leaving the green stem intact.',
      'In a non-stick pan, sauté minced garlic and lean ground chicken with a pinch of black pepper until cooked through (4 minutes). Let cool slightly and stir into the beaten eggs.',
      'Gently flatten the peeled eggplant with a fork on a flat plate.',
      'Heat 1 tsp oil in the pan over medium heat. Dip the flattened eggplant into the egg and chicken mixture, then slide carefully into the hot pan. Pour remaining chicken-egg mixture over top.',
      'Cook for 3-4 minutes until bottom is golden and set. Carefully flip and cook the other side for 2 minutes.'
    ],
    swaps: [
      {
        id: 'swap-tt1',
        originalIngredient: 'Ground Chicken',
        swapIngredient: 'Crumbled Firm Tofu or Canned Sardines in Tomato',
        savingsPhpPerServing: 15,
        reason: 'Sardines in tomato sauce or pressed tofu provide fantastic low-cost savory filling.',
        culinaryTip: 'Drain sardines slightly before crumbling into the eggs.'
      }
    ],
    beginnerTip: 'Leave the stem on the eggplant! It gives you a clean handle to lift and flip the eggplant easily.',
    commonMistakes: [
      'Flipping too early before egg is fully set on the bottom; wait until the edges pull away easily.',
      'Using a deep frying pan with excess oil; a light non-stick spray is all you need.'
    ],
    servingSuggestions: 'Serve with spicy banana ketchup or sliced fresh tomatoes and vinegar.',
    storageAdvice: 'Best eaten immediately, but leftovers can be kept in a covered dish in the fridge for up to 2 days.',
    reheatingAdvice: 'Reheat in a dry non-stick skillet for 2 minutes on each side to restore crisp edges.'
  },
  {
    id: 'chicken-inasal-rice',
    title: 'Bacolod-Style Chicken Inasal Breast with Garlic Brown Rice',
    filipinoName: 'Chicken Inasal at Sinangag',
    description: 'Tender chicken breast marinated in calamansi, lemongrass, ginger, and garlic, grilled and brushed with annatto-infused olive oil.',
    cuisine: 'filipino',
    prepTimeMinutes: 20,
    cookTimeMinutes: 20,
    servings: 3,
    difficulty: 'Intermediate',
    budgetTier: 'mid',
    fitnessGoals: ['build_muscle', 'general_healthy', 'high_protein', 'muscle_building', 'weight_management'],
    dietaryTags: ['High Protein', 'Gluten-Free'],
    calories: 410,
    proteinGrams: 42,
    carbsGrams: 38,
    fatGrams: 10,
    fiberGrams: 4,
    baseCostPhp: 89,
    imageEmoji: '🍗',
    hasRealPhoto: true,
    imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/thumb/a/a9/Chicken_Inasal.JPG/960px-Chicken_Inasal.JPG',
    imageAlt: 'Authentic Bacolod Chicken Inasal grilled chicken with golden annatto-calamansi glaze on a plate',
    photoCredit: {
      photographer: 'Obsidian Soul',
      source: 'Wikimedia Commons (CC BY-SA 3.0)',
      sourceUrl: 'https://commons.wikimedia.org/wiki/File:Chicken_Inasal.JPG'
    },
    accentColor: '#7A431D',
    ingredients: [
      { id: 'ci1', name: 'Boneless chicken breast, butterflied', category: 'meat_seafood', amountMetric: 500, unitMetric: 'g', amountCustomary: 1.1, unitCustomary: 'lb', estimatedCostPhp: 135 },
      { id: 'ci2', name: 'Calamansi juice or fresh lime juice', category: 'produce', amountMetric: 30, unitMetric: 'ml', amountCustomary: 2, unitCustomary: 'tbsp', estimatedCostPhp: 15 },
      { id: 'ci3', name: 'Fresh lemongrass (Tanglad), bruised & minced', category: 'produce', amountMetric: 20, unitMetric: 'g', amountCustomary: 0.7, unitCustomary: 'oz', estimatedCostPhp: 12 },
      { id: 'ci4', name: 'Garlic cloves, minced', category: 'produce', amountMetric: 5, unitMetric: 'clove', amountCustomary: 5, unitCustomary: 'clove', estimatedCostPhp: 10 },
      { id: 'ci5', name: 'Coconut or cane vinegar', category: 'seasoning_oil', amountMetric: 30, unitMetric: 'ml', amountCustomary: 2, unitCustomary: 'tbsp', estimatedCostPhp: 8 },
      { id: 'ci6', name: 'Annatto seeds (Atsuete) in 1 tbsp warm oil (basting)', category: 'seasoning_oil', amountMetric: 15, unitMetric: 'ml', amountCustomary: 1, unitCustomary: 'tbsp', estimatedCostPhp: 12 },
      { id: 'ci7', name: 'Cooked brown rice or red rice', category: 'pantry_grains', amountMetric: 300, unitMetric: 'g', amountCustomary: 2, unitCustomary: 'cup', estimatedCostPhp: 25 }
    ],
    instructions: [
      'Combine calamansi or lime juice, vinegar, minced garlic, ginger, bruised lemongrass, and a pinch of salt. Marinate butterflied chicken for at least 20 minutes (or up to 4 hours in the fridge).',
      'Heat oil with annatto seeds over low heat for 2 minutes to extract the rich golden-orange color. Discard seeds.',
      'Preheat a grill pan or cast-iron skillet over medium-high heat. Grill chicken for 5-6 minutes per side, brushing with annatto oil, until internal temperature reaches 74°C (165°F).',
      'Sauté minced garlic in a non-stick pan until light golden, toss in cooked warm brown rice, and stir-fry for 3 minutes.',
      'Serve grilled inasal with garlic brown rice and a side of calamansi-soy dipping sauce.'
    ],
    swaps: [
      {
        id: 'swap-ci1',
        originalIngredient: 'Calamansi Juice',
        swapIngredient: 'Fresh Lime or Lemon Juice',
        savingsPhpPerServing: 0,
        reason: 'Limes and lemons provide identical bright citrus acidity outside the Philippines.',
        culinaryTip: 'Use 2 parts lime juice to 1 part orange juice for an authentic sweet-tart profile.'
      }
    ],
    beginnerTip: 'Butterflying thick chicken breasts ensures even cooking so they stay juicy rather than drying out.',
    commonMistakes: [
      'Marinating chicken breast in acidic lime juice for more than 4 hours, which breaks down meat fibers into mush.',
      'Cooking over smoking oil without letting the grill pan heat evenly.'
    ],
    servingSuggestions: 'Serve with extra calamansi wedges, sinamak (spiced vinegar), and cucumber slices.',
    storageAdvice: 'Refrigerate grilled breasts in an airtight container for up to 4 days for easy meal prep.',
    reheatingAdvice: 'Warm in a skillet with a lid and 1 tsp water to keep meat succulent.'
  },
  {
    id: 'beef-nilaga-cabbage',
    title: 'Lean Beef & Cabbage Nilaga Broth',
    filipinoName: 'Nilagang Baka',
    description: 'A hearty, nourishing clear soup with lean beef shank or brisket, sweet corn on the cob, green beans, and fresh cabbage.',
    cuisine: 'filipino',
    prepTimeMinutes: 15,
    cookTimeMinutes: 60,
    servings: 4,
    difficulty: 'Beginner',
    budgetTier: 'mid',
    fitnessGoals: ['omad', 'build_muscle', 'general_healthy', 'muscle_building', 'high_protein'],
    dietaryTags: ['High Protein', 'Gluten-Free', 'High Fiber'],
    calories: 420,
    proteinGrams: 44,
    carbsGrams: 20,
    fatGrams: 16,
    fiberGrams: 5,
    baseCostPhp: 115,
    imageEmoji: '🥩',
    hasRealPhoto: true,
    imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/thumb/6/66/Bulalo_%28Philippines%29.jpg/960px-Bulalo_%28Philippines%29.jpg',
    imageAlt: 'Authentic Philippine Nilaga and Bulalo beef soup with sweet corn on the cob, vegetables, and clear simmering broth',
    photoCredit: {
      photographer: 'Wikimedia Commons Contributor',
      source: 'Wikimedia Commons (Public Domain CC0)',
      sourceUrl: 'https://commons.wikimedia.org/wiki/File:Bulalo_(Philippines).jpg'
    },
    accentColor: '#364B3B',
    ingredients: [
      { id: 'bn1', name: 'Lean beef shank or stew cubes', category: 'meat_seafood', amountMetric: 500, unitMetric: 'g', amountCustomary: 1.1, unitCustomary: 'lb', estimatedCostPhp: 260 },
      { id: 'bn2', name: 'Sweet corn on the cob, cut into rounds', category: 'produce', amountMetric: 1, unitMetric: 'pc', amountCustomary: 1, unitCustomary: 'pc', estimatedCostPhp: 35 },
      { id: 'bn3', name: 'Green cabbage, cut into wedges', category: 'produce', amountMetric: 250, unitMetric: 'g', amountCustomary: 8.8, unitCustomary: 'oz', estimatedCostPhp: 30 },
      { id: 'bn4', name: 'Green beans or Baguio beans', category: 'produce', amountMetric: 100, unitMetric: 'g', amountCustomary: 3.5, unitCustomary: 'oz', estimatedCostPhp: 25 },
      { id: 'bn5', name: 'Whole black peppercorns & white onion', category: 'produce', amountMetric: 1, unitMetric: 'pc', amountCustomary: 1, unitCustomary: 'pc', estimatedCostPhp: 15 },
      { id: 'bn6', name: 'Fish sauce (Patis) & water', category: 'seasoning_oil', amountMetric: 1500, unitMetric: 'ml', amountCustomary: 6, unitCustomary: 'cup', estimatedCostPhp: 10 }
    ],
    instructions: [
      'Place beef cubes in a pot covered with water. Bring to a rolling boil for 5 minutes, then drain and rinse the meat (this removes impurities for a crystal-clear broth).',
      'Return beef to pot with 6 cups fresh water, quartered onion, and black peppercorns. Bring to boil, reduce to low simmer, cover, and gently cook for 50-60 minutes (or 20 mins in a pressure cooker) until fork-tender.',
      'Add sweet corn rounds and simmer for 8 minutes to sweeten the broth.',
      'Add green beans and season with 1 tbsp fish sauce.',
      'Add cabbage wedges on top, turn off heat, and cover for 3 minutes so cabbage turns tender-crisp.'
    ],
    swaps: [
      {
        id: 'swap-bn1',
        originalIngredient: 'Beef Shank (500g)',
        swapIngredient: 'Skinless Chicken Thighs or Pork Tenderloin',
        savingsPhpPerServing: 35,
        reason: 'Poultry reduces recipe cost by 35% and cuts cooking time by half.',
        culinaryTip: 'Chicken Nilaga (Nilagang Manok) follows the exact same seasoning steps.'
      }
    ],
    beginnerTip: 'Blanching and rinsing the beef first is the chef secret to getting a clear, appetizing soup without grease scum.',
    commonMistakes: [
      'Overcooking cabbage into soggy leaves; let residual steam cook the cabbage after turning off heat.',
      'Boiling beef on high flame, which causes tough, stringy texture; keep it at a gentle simmer.'
    ],
    servingSuggestions: 'Ladle hot broth and tender vegetables into a large bowl with patis-calamansi dipping sauce.',
    storageAdvice: 'Cooled broth can be refrigerated for 4 days or frozen for 3 months. Skim any solidified top fat before reheating.',
    reheatingAdvice: 'Bring to boil on the stove. If adding fresh cabbage, toss it into the soup during the final 2 minutes of heating.'
  },
  {
    id: 'tuna-kangkong-gata',
    title: 'Light Coconut Stew with Tuna & Kangkong',
    filipinoName: 'Ginataang Kangkong at Tuna',
    description: 'Tender water spinach leaves and flaked tuna simmered in light coconut milk infused with ginger, garlic, and fresh chili.',
    cuisine: 'filipino',
    prepTimeMinutes: 10,
    cookTimeMinutes: 15,
    servings: 3,
    difficulty: 'Beginner',
    budgetTier: 'budget',
    fitnessGoals: ['calorie_deficit', 'general_healthy', 'new_to_balanced', 'weight_management', 'high_protein', 'general_health'],
    dietaryTags: ['High Protein', 'Budget Friendly', 'Quick & Easy', 'Low Carb'],
    calories: 220,
    proteinGrams: 24,
    carbsGrams: 7,
    fatGrams: 11,
    fiberGrams: 3,
    baseCostPhp: 48,
    imageEmoji: '🥥',
    hasRealPhoto: false, // Strict accuracy: Authentic Ginataang Kangkong with tuna pending authentic photography
    accentColor: '#284E3C',
    ingredients: [
      { id: 'tg1', name: 'Canned tuna flakes in water, drained', category: 'meat_seafood', amountMetric: 2, unitMetric: 'pc', amountCustomary: 2, unitCustomary: 'can', estimatedCostPhp: 65 },
      { id: 'tg2', name: 'Kangkong (Water spinach) leaves and tender stems', category: 'produce', amountMetric: 200, unitMetric: 'g', amountCustomary: 7, unitCustomary: 'oz', estimatedCostPhp: 25 },
      { id: 'tg3', name: 'Light coconut milk (gata) or coconut milk diluted with water', category: 'pantry_grains', amountMetric: 200, unitMetric: 'ml', amountCustomary: 0.8, unitCustomary: 'cup', estimatedCostPhp: 35 },
      { id: 'tg4', name: 'Ginger, garlic, onion, and red chili', category: 'produce', amountMetric: 4, unitMetric: 'pc', amountCustomary: 4, unitCustomary: 'pc', estimatedCostPhp: 15 },
      { id: 'tg5', name: 'Fish sauce or sea salt', category: 'seasoning_oil', amountMetric: 10, unitMetric: 'ml', amountCustomary: 2, unitCustomary: 'tsp', estimatedCostPhp: 5 }
    ],
    instructions: [
      'In a wide skillet, heat 1 tsp oil. Sauté sliced ginger, garlic, and onion until aromatic (2 minutes).',
      'Pour in the light coconut milk and bring to a very gentle simmer over low-medium heat. Do not boil vigorously to prevent separation.',
      'Add the kangkong stems and cook for 2 minutes.',
      'Fold in drained tuna flakes and sliced red chili. Simmer gently for 2 minutes to let tuna absorb the coconut flavor.',
      'Add kangkong leaves, season with fish sauce, stir once, and remove from heat.'
    ],
    swaps: [
      {
        id: 'swap-tg1',
        originalIngredient: 'Light Coconut Milk',
        swapIngredient: 'Low-Fat Milk + 1 drop coconut extract or almond milk',
        savingsPhpPerServing: 8,
        reason: 'Cuts saturated fats and utilizes pantry staple dairy.',
        culinaryTip: 'Simmer on low so dairy milk does not curdle.'
      }
    ],
    beginnerTip: 'Add kangkong stems first since they need 2 minutes longer to cook than the delicate leafy tops.',
    commonMistakes: [
      'Boiling coconut milk on high heat which makes it curdle and separate into oil droplets.',
      'Using oil-packed tuna without draining, which significantly adds unnecessary calories.'
    ],
    servingSuggestions: 'Serve warm over brown rice, steamed sweet potato slices, or riced cauliflower.',
    storageAdvice: 'Refrigerate in a sealed glass container for up to 2 days.',
    reheatingAdvice: 'Reheat gently over low heat, stirring continuously so coconut milk stays velvety.'
  },
  {
    id: 'arroz-caldo-oats',
    title: 'High-Fiber Chicken Ginger Porridge',
    filipinoName: 'Oat Arroz Caldo',
    description: 'A modern, gut-friendly twist on beloved Arroz Caldo using whole rolled oats cooked in golden ginger chicken broth topped with toasted garlic.',
    cuisine: 'filipino',
    prepTimeMinutes: 10,
    cookTimeMinutes: 20,
    servings: 3,
    difficulty: 'Beginner',
    budgetTier: 'budget',
    fitnessGoals: ['calorie_deficit', 'new_to_balanced', 'general_healthy', 'weight_management', 'general_health', 'high_protein'],
    dietaryTags: ['High Fiber', 'Budget Friendly', 'Quick & Easy'],
    calories: 295,
    proteinGrams: 28,
    carbsGrams: 32,
    fatGrams: 6,
    fiberGrams: 5,
    baseCostPhp: 52,
    imageEmoji: '🥣',
    hasRealPhoto: true,
    imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/thumb/b/b5/Arroz_Caldo.jpg/960px-Arroz_Caldo.jpg',
    imageAlt: 'Authentic Filipino Arroz Caldo ginger chicken porridge topped with golden fried garlic and sliced scallions',
    photoCredit: {
      photographer: 'Wikimedia Commons Contributor',
      source: 'Wikimedia Commons (CC BY-SA 3.0)',
      sourceUrl: 'https://commons.wikimedia.org/wiki/File:Arroz_Caldo.jpg'
    },
    accentColor: '#4A623A',
    ingredients: [
      { id: 'ao1', name: 'Rolled oats or quick-cooking oats', category: 'pantry_grains', amountMetric: 120, unitMetric: 'g', amountCustomary: 1.3, unitCustomary: 'cup', estimatedCostPhp: 25 },
      { id: 'ao2', name: 'Skinless chicken breast or thigh, diced', category: 'meat_seafood', amountMetric: 300, unitMetric: 'g', amountCustomary: 10.5, unitCustomary: 'oz', estimatedCostPhp: 80 },
      { id: 'ao3', name: 'Ginger, cut into thin matchsticks', category: 'produce', amountMetric: 30, unitMetric: 'g', amountCustomary: 1, unitCustomary: 'oz', estimatedCostPhp: 12 },
      { id: 'ao4', name: 'Garlic (fried for topping) and spring onions', category: 'produce', amountMetric: 5, unitMetric: 'clove', amountCustomary: 5, unitCustomary: 'clove', estimatedCostPhp: 15 },
      { id: 'ao5', name: 'Calamansi or lemon wedges', category: 'produce', amountMetric: 2, unitMetric: 'pc', amountCustomary: 2, unitCustomary: 'pc', estimatedCostPhp: 6 },
      { id: 'ao6', name: 'Chicken broth or water', category: 'pantry_grains', amountMetric: 800, unitMetric: 'ml', amountCustomary: 3.5, unitCustomary: 'cup', estimatedCostPhp: 10 }
    ],
    instructions: [
      'In a pot, toast minced garlic in 1 tsp oil until golden brown. Scoop out half the crispy garlic and reserve for topping.',
      'Add ginger matchsticks, sliced onions, and diced chicken to the pot. Sauté for 4 minutes until chicken is seared.',
      'Pour in chicken broth and bring to a boil. Lower heat and simmer for 5 minutes.',
      'Stir in rolled oats. Simmer for 5-7 minutes, stirring occasionally, until oats swell into a rich, velvety porridge.',
      'Ladle into bowls, top with crispy toasted garlic, sliced scallions, and a squeeze of fresh calamansi.'
    ],
    swaps: [
      {
        id: 'swap-ao1',
        originalIngredient: 'Rolled Oats',
        swapIngredient: 'Brown Rice or White Rice',
        savingsPhpPerServing: 4,
        reason: 'Using leftover cooked rice is traditional and zero-waste.',
        culinaryTip: 'Mash cooked rice slightly with a ladle while simmering to release starches.'
      }
    ],
    beginnerTip: 'Oats absorb liquid quickly as they cool; if porridge becomes too thick, whisk in 2 tablespoons of warm water.',
    commonMistakes: [
      'Burning the minced garlic; take it out when pale golden as it keeps browning in hot oil.',
      'Neglecting to stir oats while simmering, which can cause them to stick to the bottom.'
    ],
    servingSuggestions: 'Garnish with a sliced hard-boiled egg for an additional 6g protein.',
    storageAdvice: 'Refrigerate in a sealed container for up to 3 days.',
    reheatingAdvice: 'Reheat on the stove with a splash of hot water or broth to loosen the porridge.'
  },
  {
    id: 'ensaladang-talong-egg',
    title: 'Smoked Eggplant & Tomato Salad with Egg',
    filipinoName: 'Ensaladang Talong',
    description: 'Char-grilled eggplant mashed with juicy native tomatoes, red onions, calamansi dressing, and sliced boiled egg for complete vegetarian protein.',
    cuisine: 'filipino',
    prepTimeMinutes: 15,
    cookTimeMinutes: 10,
    servings: 2,
    difficulty: 'Beginner',
    budgetTier: 'budget',
    fitnessGoals: ['calorie_deficit', 'new_to_balanced', 'general_healthy', 'weight_management', 'general_health', 'high_protein'],
    dietaryTags: ['Vegetarian', 'Budget Friendly', 'Quick & Easy', 'Low Carb'],
    calories: 185,
    proteinGrams: 11,
    carbsGrams: 14,
    fatGrams: 9,
    fiberGrams: 5,
    baseCostPhp: 38,
    imageEmoji: '🥗',
    hasRealPhoto: false, // Strict accuracy: Waiting for verified photograph of authentic mashed smoked eggplant salad with native tomatoes
    accentColor: '#385338',
    ingredients: [
      { id: 'et1', name: 'Asian eggplants, charred & peeled', category: 'produce', amountMetric: 2, unitMetric: 'pc', amountCustomary: 2, unitCustomary: 'pc', estimatedCostPhp: 25 },
      { id: 'et2', name: 'Hard-boiled eggs, sliced', category: 'meat_seafood', amountMetric: 2, unitMetric: 'pc', amountCustomary: 2, unitCustomary: 'pc', estimatedCostPhp: 18 },
      { id: 'et3', name: 'Ripe tomatoes, diced', category: 'produce', amountMetric: 2, unitMetric: 'pc', amountCustomary: 2, unitCustomary: 'pc', estimatedCostPhp: 16 },
      { id: 'et4', name: 'Red onion, thinly sliced', category: 'produce', amountMetric: 1, unitMetric: 'pc', amountCustomary: 1, unitCustomary: 'pc', estimatedCostPhp: 8 },
      { id: 'et5', name: 'Calamansi juice or cane vinegar', category: 'seasoning_oil', amountMetric: 20, unitMetric: 'ml', amountCustomary: 4, unitCustomary: 'tsp', estimatedCostPhp: 6 }
    ],
    instructions: [
      'Roast eggplants over flame or under the broiler until skin is wrinkled and charred. Cool, peel skin, and trim stem.',
      'Place peeled eggplant flesh on a serving plate and gently mash with the tines of a fork.',
      'Top with diced fresh tomatoes and sliced red onion.',
      'Drizzle with fresh calamansi juice and a light sprinkle of sea salt.',
      'Garnish with sliced hard-boiled eggs.'
    ],
    swaps: [
      {
        id: 'swap-et1',
        originalIngredient: 'Hard-boiled eggs',
        swapIngredient: 'Salted duck egg (Itlog na Maalat) or Crumbled Tofu',
        savingsPhpPerServing: 2,
        reason: 'Salted egg provides classic punchy savory contrast.',
        culinaryTip: 'If using salted egg, skip adding extra table salt.'
      }
    ],
    beginnerTip: 'Soaking sliced raw onions in cold water for 5 minutes takes away their harsh bite and keeps them sweet and crunchy.',
    commonMistakes: [
      'Peeling eggplant when still hot; wait 5 minutes in a covered bowl so steam loosens skin naturally.',
      'Dressing the salad hours before serving, which draws out excess water from tomatoes.'
    ],
    servingSuggestions: 'Serve alongside grilled fish or as a refreshing high-fiber side dish.',
    storageAdvice: 'Keep mashed eggplant separate from tomatoes in the fridge for up to 2 days.',
    reheatingAdvice: 'Enjoy at room temperature or chilled; no reheating needed.'
  },
  {
    id: 'mediterranean-salmon-quinoa',
    title: 'Mediterranean Pan-Seared Salmon & Quinoa',
    filipinoName: 'Salmon at Quinoa Bowl',
    description: 'Crispy pan-seared salmon fillet served over fluffy herb quinoa, cucumber, cherry tomatoes, and a light lemon extra-virgin olive oil drizzle.',
    cuisine: 'mediterranean',
    prepTimeMinutes: 15,
    cookTimeMinutes: 15,
    servings: 2,
    difficulty: 'Intermediate',
    budgetTier: 'premium',
    fitnessGoals: ['build_muscle', 'general_healthy', 'calorie_deficit', 'high_protein', 'muscle_building', 'weight_management', 'general_health'],
    dietaryTags: ['High Protein', 'Gluten-Free'],
    calories: 460,
    proteinGrams: 39,
    carbsGrams: 30,
    fatGrams: 20,
    fiberGrams: 4,
    baseCostPhp: 210,
    imageEmoji: '🍣',
    hasRealPhoto: true,
    imageUrl: 'https://images.unsplash.com/photo-1467003909585-2f8a72700288?auto=format&fit=crop&w=1000&q=80',
    imageAlt: 'Golden crispy skin salmon fillet plated over fluffy quinoa salad with cucumber and cherry tomatoes',
    photoCredit: {
      photographer: 'Caroline Attwood',
      source: 'Unsplash',
      sourceUrl: 'https://unsplash.com'
    },
    accentColor: '#2B4A3C',
    ingredients: [
      { id: 'ms1', name: 'Fresh salmon fillets', category: 'meat_seafood', amountMetric: 300, unitMetric: 'g', amountCustomary: 10.5, unitCustomary: 'oz', estimatedCostPhp: 320 },
      { id: 'ms2', name: 'Quinoa or brown rice, cooked', category: 'pantry_grains', amountMetric: 180, unitMetric: 'g', amountCustomary: 1, unitCustomary: 'cup', estimatedCostPhp: 45 },
      { id: 'ms3', name: 'Cucumber and cherry tomatoes, diced', category: 'produce', amountMetric: 150, unitMetric: 'g', amountCustomary: 5, unitCustomary: 'oz', estimatedCostPhp: 35 },
      { id: 'ms4', name: 'Extra virgin olive oil', category: 'seasoning_oil', amountMetric: 15, unitMetric: 'ml', amountCustomary: 1, unitCustomary: 'tbsp', estimatedCostPhp: 15 },
      { id: 'ms5', name: 'Fresh lemon juice, parsley, and garlic', category: 'produce', amountMetric: 1, unitMetric: 'pc', amountCustomary: 1, unitCustomary: 'pc', estimatedCostPhp: 15 }
    ],
    instructions: [
      'Pat salmon skin dry with paper towels; season flesh with salt, black pepper, and dried oregano.',
      'Heat 1 tsp olive oil in a skillet over medium-high heat. Place salmon skin-side down and press gently with spatula for 20 seconds.',
      'Cook for 4-5 minutes until skin is crackling crisp, flip and cook 2-3 minutes for medium doneness.',
      'In a bowl, toss warm cooked quinoa with diced cucumber, halved cherry tomatoes, chopped parsley, and lemon juice.',
      'Nestle the crispy salmon on top of the vibrant salad bowl.'
    ],
    swaps: [
      {
        id: 'swap-ms1',
        originalIngredient: 'Salmon Fillet (300g)',
        swapIngredient: 'Boneless Bangus Belly or Tilapia Fillet',
        savingsPhpPerServing: 85,
        reason: 'Milkfish belly (Bangus) offers rich Omega-3 fatty acids at less than half salmon price in Southeast Asia.',
        culinaryTip: 'Pan-sear bangus belly skin-side down until blistered and golden.'
      },
      {
        id: 'swap-ms2',
        originalIngredient: 'Quinoa',
        swapIngredient: 'Philippine Adlai grain or Brown Rice',
        savingsPhpPerServing: 18,
        reason: 'Local adlai grain has a delightful nutty chew with identical low-glycemic benefits.',
        culinaryTip: 'Cook adlai 1:2 with water for 30 minutes.'
      }
    ],
    beginnerTip: 'A dry fish skin equals crispy skin! Always pat fish thoroughly with a clean paper towel before it touches the skillet.',
    commonMistakes: [
      'Moving the fish around in the pan too early; let the skin release naturally from the skillet.',
      'Overcooking salmon until white albumin pushes out; take off heat when center is barely pink.'
    ],
    servingSuggestions: 'Serve with fresh lemon wedges and a light sprinkle of coarse sea salt.',
    storageAdvice: 'Best enjoyed immediately. Keep leftovers in the fridge for up to 2 days.',
    reheatingAdvice: 'Reheat skin-side down in a dry skillet for 3 minutes over low heat to restore skin crispness.'
  },
  {
    id: 'greek-lemon-chicken-zucchini',
    title: 'Greek Lemon Herb Chicken & Roasted Zucchini',
    filipinoName: 'Griyegong Manok at Zucchini',
    description: 'Juicy chicken breast infused with oregano, garlic, and fresh lemon zest, pan-roasted with sweet bell peppers and tender zucchini.',
    cuisine: 'mediterranean',
    prepTimeMinutes: 15,
    cookTimeMinutes: 20,
    servings: 3,
    difficulty: 'Beginner',
    budgetTier: 'mid',
    fitnessGoals: ['build_muscle', 'calorie_deficit', 'general_healthy', 'high_protein', 'weight_management', 'muscle_building'],
    dietaryTags: ['High Protein', 'Low Carb', 'Gluten-Free'],
    calories: 310,
    proteinGrams: 36,
    carbsGrams: 9,
    fatGrams: 14,
    fiberGrams: 3,
    baseCostPhp: 88,
    imageEmoji: '🍋',
    hasRealPhoto: false, // Strict accuracy: Fried chicken wings photo removed, displaying Photo unavailable until verified Greek lemon herb chicken photo is added
    accentColor: '#365A42',
    ingredients: [
      { id: 'gc1', name: 'Chicken breast fillets', category: 'meat_seafood', amountMetric: 450, unitMetric: 'g', amountCustomary: 1, unitCustomary: 'lb', estimatedCostPhp: 120 },
      { id: 'gc2', name: 'Zucchini or Sayote, cut into half moons', category: 'produce', amountMetric: 250, unitMetric: 'g', amountCustomary: 9, unitCustomary: 'oz', estimatedCostPhp: 40 },
      { id: 'gc3', name: 'Red bell pepper & red onion', category: 'produce', amountMetric: 200, unitMetric: 'g', amountCustomary: 7, unitCustomary: 'oz', estimatedCostPhp: 50 },
      { id: 'gc4', name: 'Olive oil or canola oil', category: 'seasoning_oil', amountMetric: 20, unitMetric: 'ml', amountCustomary: 4, unitCustomary: 'tsp', estimatedCostPhp: 18 },
      { id: 'gc5', name: 'Dried oregano, garlic, salt, and lemon', category: 'seasoning_oil', amountMetric: 10, unitMetric: 'g', amountCustomary: 1, unitCustomary: 'tbsp', estimatedCostPhp: 15 }
    ],
    instructions: [
      'Toss chicken with 1 tbsp olive oil, dried oregano, minced garlic, lemon juice, salt, and pepper.',
      'Heat skillet or roasting pan over medium heat. Sear chicken breasts for 5-6 minutes per side until golden and cooked through. Remove to rest.',
      'In the same flavorful skillet, add zucchini, red bell pepper, and sliced onion.',
      'Sauté vegetables for 6-8 minutes until slightly charred on the edges yet tender-crisp.',
      'Slice chicken across the grain and serve beside the warm Mediterranean vegetables.'
    ],
    swaps: [
      {
        id: 'swap-gc1',
        originalIngredient: 'Zucchini (Sayote substitute)',
        swapIngredient: 'Sayote (Chayote) or Green Eggplant',
        savingsPhpPerServing: 12,
        reason: 'Sayote absorbs garlic and lemon herbs beautifully at a fraction of zucchini prices.',
        culinaryTip: 'Slice sayote into thin batons so it sautés quickly.'
      }
    ],
    beginnerTip: 'Let the chicken rest for 5 minutes after cooking before slicing so the flavorful juices stay locked inside.',
    commonMistakes: [
      'Crowding the pan with chicken and vegetables all at once, which steams meat instead of searing.',
      'Over-sautéing zucchini until watery.'
    ],
    servingSuggestions: 'Serve with whole grain pita or roasted baby potatoes and a dollop of tzatziki or Greek yogurt.',
    storageAdvice: 'Excellent for meal prep; stores well in glass containers for up to 4 days.',
    reheatingAdvice: 'Reheat in a microwave covered with a damp paper towel for 90 seconds to preserve moisture.'
  },
  {
    id: 'tuscan-white-bean-stew',
    title: 'Rustic Tuscan White Bean & Tomato Stew',
    filipinoName: 'Tuscan Bean Stew',
    description: 'Hearty white cannellini beans or chickpea simmered in garlic, crushed Italian tomatoes, fresh greens, and rosemary.',
    cuisine: 'mediterranean',
    prepTimeMinutes: 10,
    cookTimeMinutes: 20,
    servings: 3,
    difficulty: 'Beginner',
    budgetTier: 'budget',
    fitnessGoals: ['new_to_balanced', 'general_healthy', 'calorie_deficit', 'weight_management', 'general_health', 'high_protein'],
    dietaryTags: ['High Fiber', 'Vegetarian', 'Budget Friendly', 'High Protein'],
    calories: 270,
    proteinGrams: 15,
    carbsGrams: 42,
    fatGrams: 5,
    fiberGrams: 12,
    baseCostPhp: 55,
    imageEmoji: '🍲',
    hasRealPhoto: true,
    imageUrl: 'https://images.unsplash.com/photo-1541832676-9b763b0239ab?auto=format&fit=crop&w=1000&q=80',
    imageAlt: 'Rich slow-simmered Tuscan white beans in rustic herb tomato sauce with wilted greens',
    photoCredit: {
      photographer: 'Calum Lewis',
      source: 'Unsplash',
      sourceUrl: 'https://unsplash.com'
    },
    accentColor: '#305844',
    ingredients: [
      { id: 'tw1', name: 'Cannellini white beans or chickpeas, cooked/canned', category: 'pantry_grains', amountMetric: 400, unitMetric: 'g', amountCustomary: 1, unitCustomary: 'can', estimatedCostPhp: 65 },
      { id: 'tw2', name: 'Crushed peeled tomatoes', category: 'pantry_grains', amountMetric: 250, unitMetric: 'g', amountCustomary: 1, unitCustomary: 'cup', estimatedCostPhp: 40 },
      { id: 'tw3', name: 'Fresh spinach or kangkong leaves', category: 'produce', amountMetric: 120, unitMetric: 'g', amountCustomary: 3, unitCustomary: 'cup', estimatedCostPhp: 25 },
      { id: 'tw4', name: 'Garlic cloves, sliced & olive oil', category: 'produce', amountMetric: 4, unitMetric: 'clove', amountCustomary: 4, unitCustomary: 'clove', estimatedCostPhp: 15 },
      { id: 'tw5', name: 'Vegetable broth or water', category: 'pantry_grains', amountMetric: 300, unitMetric: 'ml', amountCustomary: 1.25, unitCustomary: 'cup', estimatedCostPhp: 0 }
    ],
    instructions: [
      'Heat olive oil in a soup pot. Gently fry sliced garlic and a pinch of chili flakes until golden and aromatic (2 minutes).',
      'Pour in crushed tomatoes, vegetable broth, and drained white beans. Bring to a simmer.',
      'Using the back of a wooden spoon, crush 1/3 of the beans against the side of the pot (this naturally thickens the sauce without flour).',
      'Simmer for 10 minutes until sauce is glossy and rich.',
      'Fold in fresh greens until wilted. Season with black pepper and a drizzle of olive oil.'
    ],
    swaps: [
      {
        id: 'swap-tw1',
        originalIngredient: 'Canned Cannellini Beans',
        swapIngredient: 'Local White Kidney Beans or Chickpeas soaked overnight',
        savingsPhpPerServing: 14,
        reason: 'Dry beans cooked at home are up to 70% cheaper than canned imported goods.',
        culinaryTip: 'Cook a big batch of dry beans on Sunday and freeze in portions.'
      }
    ],
    beginnerTip: 'Mashing a small handful of beans right in the pot creates an instant luxurious, creamy sauce.',
    commonMistakes: [
      'Burning garlic chips by using high heat; garlic turns bitter in seconds.',
      'Adding acidic tomatoes before dried beans are fully soft (if cooking from dry).'
    ],
    servingSuggestions: 'Drizzle with extra virgin olive oil and serve with a toasted slice of whole grain sourdough.',
    storageAdvice: 'Stores exceptionally well in the fridge for up to 5 days; flavors meld and improve over time.',
    reheatingAdvice: 'Warm in a saucepan on low heat with a splash of water.'
  },
  {
    id: 'shakshuka-poached-eggs',
    title: 'Classic Shakshuka with Poached Farm Eggs',
    filipinoName: 'Shakshuka',
    description: 'Farm fresh eggs gently poached in a spiced, bubbling sauce of crushed tomatoes, sweet bell peppers, cumin, and cilantro.',
    cuisine: 'mediterranean',
    prepTimeMinutes: 10,
    cookTimeMinutes: 20,
    servings: 2,
    difficulty: 'Beginner',
    budgetTier: 'budget',
    fitnessGoals: ['calorie_deficit', 'new_to_balanced', 'general_healthy', 'high_protein', 'weight_management', 'general_health'],
    dietaryTags: ['High Protein', 'Vegetarian', 'Quick & Easy', 'Budget Friendly'],
    calories: 250,
    proteinGrams: 17,
    carbsGrams: 15,
    fatGrams: 14,
    fiberGrams: 4,
    baseCostPhp: 49,
    imageEmoji: '🍳',
    hasRealPhoto: true,
    imageUrl: 'https://images.unsplash.com/photo-1590412200988-a436970781fa?auto=format&fit=crop&w=1000&q=80',
    imageAlt: 'Cast-iron skillet of spiced tomato bell pepper sauce with poached eggs and fresh chopped herbs',
    photoCredit: {
      photographer: 'Monika Grabkowska',
      source: 'Unsplash',
      sourceUrl: 'https://unsplash.com'
    },
    accentColor: '#6B3828',
    ingredients: [
      { id: 'sh1', name: 'Fresh large eggs', category: 'meat_seafood', amountMetric: 4, unitMetric: 'pc', amountCustomary: 4, unitCustomary: 'pc', estimatedCostPhp: 36 },
      { id: 'sh2', name: 'Chopped tomatoes or canned tomatoes', category: 'produce', amountMetric: 300, unitMetric: 'g', amountCustomary: 1.2, unitCustomary: 'cup', estimatedCostPhp: 30 },
      { id: 'sh3', name: 'Bell pepper, finely diced', category: 'produce', amountMetric: 1, unitMetric: 'pc', amountCustomary: 1, unitCustomary: 'pc', estimatedCostPhp: 20 },
      { id: 'sh4', name: 'Garlic, onion, ground cumin, and paprika', category: 'seasoning_oil', amountMetric: 10, unitMetric: 'g', amountCustomary: 1, unitCustomary: 'tbsp', estimatedCostPhp: 12 }
    ],
    instructions: [
      'Sauté diced onion and bell pepper in 1 tsp olive oil until tender (5 minutes). Add minced garlic, cumin, and paprika.',
      'Add tomatoes, season with salt and pepper, and simmer for 8 minutes until the sauce thickens.',
      'Use a spoon to create 4 small wells in the sauce. Crack an egg into each well.',
      'Cover the pan with a lid and cook on low heat for 5-7 minutes until egg whites are set and yolks are gently runny.',
      'Garnish with chopped parsley or cilantro.'
    ],
    swaps: [
      {
        id: 'swap-sh1',
        originalIngredient: 'Fresh Bell Pepper',
        swapIngredient: 'Local green finger chili (seeds removed) + extra onion',
        savingsPhpPerServing: 8,
        reason: 'Local green peppers deliver aromatic warmth at a fraction of bell pepper costs.',
        culinaryTip: 'Scrape seeds thoroughly to control heat level.'
      }
    ],
    beginnerTip: 'Keep the burner low once eggs are added so the whites gently poach in steam without overcooking the yolks.',
    commonMistakes: [
      'Simmering with the lid off after adding eggs, which causes the tops of egg whites to stay raw.',
      'Leaving the heat on high, which scorches the tomato base before eggs cook.'
    ],
    servingSuggestions: 'Serve straight from the warm skillet with toasted whole wheat pita bread.',
    storageAdvice: 'Best eaten right away while egg yolks are runny. Sauce can be prepared ahead and kept for 4 days.',
    reheatingAdvice: 'If storing sauce ahead, gently heat the tomato base, then crack fresh eggs to poach.'
  },
  {
    id: 'teriyaki-tofu-edamame',
    title: 'Japanese Teriyaki Tofu & Steamed Edamame Bowl',
    filipinoName: 'Teriyaki Tofu Bowl',
    description: 'Golden pan-crisped tofu cubes glazed in homemade low-sugar teriyaki sauce over brown rice with steamed edamame and sesame seeds.',
    cuisine: 'asian',
    prepTimeMinutes: 15,
    cookTimeMinutes: 15,
    servings: 2,
    difficulty: 'Beginner',
    budgetTier: 'budget',
    fitnessGoals: ['new_to_balanced', 'general_healthy', 'calorie_deficit', 'high_protein', 'weight_management', 'general_health'],
    dietaryTags: ['High Protein', 'Vegetarian', 'Budget Friendly', 'High Fiber'],
    calories: 380,
    proteinGrams: 24,
    carbsGrams: 46,
    fatGrams: 11,
    fiberGrams: 7,
    baseCostPhp: 58,
    imageEmoji: '🥢',
    hasRealPhoto: false, // Strict accuracy: Unverified photo removed, displaying Photo unavailable
    accentColor: '#30523C',
    ingredients: [
      { id: 'tt1', name: 'Extra firm tofu, pressed and cubed', category: 'meat_seafood', amountMetric: 300, unitMetric: 'g', amountCustomary: 10.5, unitCustomary: 'oz', estimatedCostPhp: 40 },
      { id: 'tt2', name: 'Shelled edamame or sweet green peas', category: 'produce', amountMetric: 100, unitMetric: 'g', amountCustomary: 3.5, unitCustomary: 'oz', estimatedCostPhp: 35 },
      { id: 'tt3', name: 'Steamed brown rice', category: 'pantry_grains', amountMetric: 200, unitMetric: 'g', amountCustomary: 1.3, unitCustomary: 'cup', estimatedCostPhp: 18 },
      { id: 'tt4', name: 'Low-sodium soy sauce, honey/mirin, grated ginger', category: 'seasoning_oil', amountMetric: 30, unitMetric: 'ml', amountCustomary: 2, unitCustomary: 'tbsp', estimatedCostPhp: 15 },
      { id: 'tt5', name: 'Sesame seeds and sliced green scallions', category: 'seasoning_oil', amountMetric: 5, unitMetric: 'g', amountCustomary: 1, unitCustomary: 'tsp', estimatedCostPhp: 8 }
    ],
    instructions: [
      'Press tofu between paper towels with a heavy plate for 10 minutes to extract excess moisture. Cut into bite-sized cubes.',
      'Pan-fry tofu in 1 tsp oil over medium heat for 8 minutes, turning frequently until all sides are crunchy golden.',
      'Whisk soy sauce, 1 tsp honey, grated ginger, and 2 tbsp water. Pour into the skillet over hot tofu; it will sizzle and glaze the cubes in 60 seconds.',
      'Steam edamame or green peas for 3 minutes.',
      'Serve glazed tofu over brown rice with steamed edamame, sprinkled with sesame seeds.'
    ],
    swaps: [
      {
        id: 'swap-tt1',
        originalIngredient: 'Shelled Edamame',
        swapIngredient: 'Sweet Green Peas or Yardlong Beans',
        savingsPhpPerServing: 12,
        reason: 'Frozen sweet green peas offer plant protein and natural sweetness affordably.',
        culinaryTip: 'Toss green peas straight from frozen into the hot pan in the last minute.'
      }
    ],
    beginnerTip: 'Pressing your tofu dry before frying is the number one secret to getting crunchy, restaurant-style edges without deep frying.',
    commonMistakes: [
      'Using soft or silken tofu which will crumble in the pan; always look for "Extra Firm".',
      'Adding sugar-heavy sauce too early, which causes it to burn before tofu turns crispy.'
    ],
    servingSuggestions: 'Sprinkle with toasted white and black sesame seeds, plus a dash of chili flakes.',
    storageAdvice: 'Refrigerate components separately for up to 4 days for meal prep.',
    reheatingAdvice: 'Reheat tofu in an air fryer or toaster oven at 180°C for 4 minutes to restore crunch.'
  },
  {
    id: 'sesame-chicken-bokchoy',
    title: 'Ginger Sesame Chicken Breast with Bok Choy',
    filipinoName: 'Sesame Chicken at Bok Choy',
    description: 'Lean tender chicken breast strips wok-tossed with ginger, garlic, sesame oil, and crunchy baby bok choy greens.',
    cuisine: 'asian',
    prepTimeMinutes: 10,
    cookTimeMinutes: 12,
    servings: 2,
    difficulty: 'Beginner',
    budgetTier: 'budget',
    fitnessGoals: ['calorie_deficit', 'build_muscle', 'new_to_balanced', 'high_protein', 'weight_management', 'muscle_building'],
    dietaryTags: ['High Protein', 'Low Carb', 'Quick & Easy', 'Budget Friendly'],
    calories: 280,
    proteinGrams: 36,
    carbsGrams: 8,
    fatGrams: 11,
    fiberGrams: 3,
    baseCostPhp: 62,
    imageEmoji: '🥬',
    hasRealPhoto: false, // Strict accuracy: Unverified photo removed, displaying Photo unavailable
    accentColor: '#284E38',
    ingredients: [
      { id: 'sc1', name: 'Chicken breast, sliced into thin strips', category: 'meat_seafood', amountMetric: 350, unitMetric: 'g', amountCustomary: 12, unitCustomary: 'oz', estimatedCostPhp: 95 },
      { id: 'sc2', name: 'Baby bok choy, halved lengthwise', category: 'produce', amountMetric: 200, unitMetric: 'g', amountCustomary: 7, unitCustomary: 'oz', estimatedCostPhp: 25 },
      { id: 'sc3', name: 'Garlic, ginger, and scallions', category: 'produce', amountMetric: 4, unitMetric: 'clove', amountCustomary: 4, unitCustomary: 'clove', estimatedCostPhp: 10 },
      { id: 'sc4', name: 'Toasted sesame oil & low sodium soy sauce', category: 'seasoning_oil', amountMetric: 15, unitMetric: 'ml', amountCustomary: 1, unitCustomary: 'tbsp', estimatedCostPhp: 12 }
    ],
    instructions: [
      'Toss chicken breast strips with 1 tsp soy sauce and a pinch of cornstarch or black pepper.',
      'Heat skillet or wok on high heat with 1 tsp oil. Sear chicken for 4-5 minutes until cooked through. Transfer to plate.',
      'Add minced ginger and garlic to the wok for 30 seconds until fragrant.',
      'Add halved baby bok choy and 2 tbsp water; cover immediately with a lid to steam-fry for 2 minutes until bright emerald.',
      'Toss chicken back in, drizzle with toasted sesame oil, and serve.'
    ],
    swaps: [
      {
        id: 'swap-sc1',
        originalIngredient: 'Baby Bok Choy',
        swapIngredient: 'Pechay Tagalog or Kangkong Stems',
        savingsPhpPerServing: 8,
        reason: 'Local Pechay Tagalog is universally available across Philippine wet markets for pennies.',
        culinaryTip: 'Cook pechay stems 1 minute before adding the tender leaves.'
      }
    ],
    beginnerTip: 'High heat and fast cooking keeps bok choy crisp and prevents chicken breast from drying out.',
    commonMistakes: [
      'Overcooking the bok choy into limp grey stems; 2 minutes of steam is plenty.',
      'Sautéing sesame oil on high heat; always drizzle toasted sesame oil right at the finish.'
    ],
    servingSuggestions: 'Serve with steamed jasmine or brown rice, or over shirataki low-calorie noodles.',
    storageAdvice: 'Refrigerate in a sealed container for up to 3 days.',
    reheatingAdvice: 'Reheat in a hot skillet for 2 minutes with 1 teaspoon of water to revive crispness.'
  },
  {
    id: 'thai-chickpea-curry',
    title: 'Thai Coconut Chickpea & Cauliflower Curry',
    filipinoName: 'Thai Chickpea Curry',
    description: 'Fragrant yellow Thai curry with tender chickpeas, cauliflower florets, and baby spinach simmered in creamy light coconut milk.',
    cuisine: 'asian',
    prepTimeMinutes: 15,
    cookTimeMinutes: 20,
    servings: 3,
    difficulty: 'Beginner',
    budgetTier: 'mid',
    fitnessGoals: ['general_healthy', 'new_to_balanced', 'calorie_deficit', 'weight_management', 'high_protein'],
    dietaryTags: ['High Fiber', 'Vegetarian', 'Gluten-Free'],
    calories: 320,
    proteinGrams: 14,
    carbsGrams: 36,
    fatGrams: 14,
    fiberGrams: 8,
    baseCostPhp: 75,
    imageEmoji: '🍛',
    hasRealPhoto: false, // Strict accuracy: Mismatched image removed, displaying Photo unavailable
    accentColor: '#755828',
    ingredients: [
      { id: 'tc1', name: 'Cooked chickpeas (Garbanzos)', category: 'pantry_grains', amountMetric: 300, unitMetric: 'g', amountCustomary: 1.5, unitCustomary: 'cup', estimatedCostPhp: 55 },
      { id: 'tc2', name: 'Cauliflower florets', category: 'produce', amountMetric: 200, unitMetric: 'g', amountCustomary: 7, unitCustomary: 'oz', estimatedCostPhp: 45 },
      { id: 'tc3', name: 'Light coconut milk', category: 'pantry_grains', amountMetric: 250, unitMetric: 'ml', amountCustomary: 1, unitCustomary: 'cup', estimatedCostPhp: 40 },
      { id: 'tc4', name: 'Yellow or red Thai curry paste', category: 'seasoning_oil', amountMetric: 25, unitMetric: 'g', amountCustomary: 1.5, unitCustomary: 'tbsp', estimatedCostPhp: 25 },
      { id: 'tc5', name: 'Fresh baby spinach or malunggay', category: 'produce', amountMetric: 80, unitMetric: 'g', amountCustomary: 2, unitCustomary: 'cup', estimatedCostPhp: 15 }
    ],
    instructions: [
      'In a medium saucepan, gently heat 1 tbsp coconut cream with curry paste for 2 minutes until fragrant oils release.',
      'Pour in remaining coconut milk and 1/2 cup water. Bring to a simmer.',
      'Add cauliflower florets and chickpeas. Cook over medium-low heat for 12-15 minutes until cauliflower is tender.',
      'Fold in baby spinach until wilted (1 minute).',
      'Season with a squeeze of fresh lime juice and serve warm with brown rice.'
    ],
    swaps: [
      {
        id: 'swap-tc1',
        originalIngredient: 'Cauliflower',
        swapIngredient: 'Sayote (Chayote) or Kalabasa (Squash)',
        savingsPhpPerServing: 16,
        reason: 'Local squash lends natural sweetness and a gorgeous golden curry hue.',
        culinaryTip: 'Cube squash and simmer until easily pierced with a fork.'
      }
    ],
    beginnerTip: 'Blooming curry paste in warm coconut fat first unlocks complex spices that boiling alone cannot release.',
    commonMistakes: [
      'Boiling vigorously which causes coconut milk to separate.',
      'Over-simmering cauliflower until it dissolves into mush; keep it tender-crisp.'
    ],
    servingSuggestions: 'Garnish with fresh cilantro leaves, sliced red chili, and a wedge of fresh lime.',
    storageAdvice: 'Refrigerate for up to 4 days. Curries often taste deeper on the next day.',
    reheatingAdvice: 'Reheat on medium heat on the stove, stirring gently until hot.'
  },
  {
    id: 'korean-bibimbap-bowl',
    title: 'Balanced Bibimbap Brown Rice & Sunny Egg Bowl',
    filipinoName: 'Korean Bibimbap Bowl',
    description: 'Nutrient-rich Korean comfort: seasoned sautéed carrots, spinach, bean sprouts, and kimchi over warm brown rice, crowned with a sunny fried egg.',
    cuisine: 'asian',
    prepTimeMinutes: 20,
    cookTimeMinutes: 15,
    servings: 2,
    difficulty: 'Intermediate',
    budgetTier: 'mid',
    fitnessGoals: ['build_muscle', 'general_healthy', 'new_to_balanced', 'high_protein', 'weight_management'],
    dietaryTags: ['High Fiber', 'Vegetarian', 'High Protein'],
    calories: 390,
    proteinGrams: 19,
    carbsGrams: 52,
    fatGrams: 12,
    fiberGrams: 7,
    baseCostPhp: 78,
    imageEmoji: '🍳',
    hasRealPhoto: true,
    imageUrl: 'https://images.unsplash.com/photo-1553163147-622ab57be1c7?auto=format&fit=crop&w=1000&q=80',
    imageAlt: 'Vibrant Korean bibimbap bowl with colorful mounds of seasoned spinach, carrots, bean sprouts, kimchi and egg',
    photoCredit: {
      photographer: 'Jakub Kapusnak',
      source: 'Unsplash',
      sourceUrl: 'https://unsplash.com'
    },
    accentColor: '#5C382A',
    ingredients: [
      { id: 'kb1', name: 'Cooked brown or white rice', category: 'pantry_grains', amountMetric: 250, unitMetric: 'g', amountCustomary: 1.5, unitCustomary: 'cup', estimatedCostPhp: 22 },
      { id: 'kb2', name: 'Fresh eggs', category: 'meat_seafood', amountMetric: 2, unitMetric: 'pc', amountCustomary: 2, unitCustomary: 'pc', estimatedCostPhp: 18 },
      { id: 'kb3', name: 'Mung bean sprouts (Togue)', category: 'produce', amountMetric: 150, unitMetric: 'g', amountCustomary: 5, unitCustomary: 'oz', estimatedCostPhp: 15 },
      { id: 'kb4', name: 'Carrot (julienned) and spinach/kangkong', category: 'produce', amountMetric: 150, unitMetric: 'g', amountCustomary: 5, unitCustomary: 'oz', estimatedCostPhp: 25 },
      { id: 'kb5', name: 'Kimchi or pickled vegetables', category: 'produce', amountMetric: 60, unitMetric: 'g', amountCustomary: 0.25, unitCustomary: 'cup', estimatedCostPhp: 25 },
      { id: 'kb6', name: 'Gochujang or chili paste with sesame oil', category: 'seasoning_oil', amountMetric: 15, unitMetric: 'g', amountCustomary: 1, unitCustomary: 'tbsp', estimatedCostPhp: 15 }
    ],
    instructions: [
      'Lightly blanch bean sprouts (togue) for 90 seconds in boiling water. Drain, toss with a drop of sesame oil and pinch of salt.',
      'Sauté julienned carrots in 1/2 tsp oil for 2 minutes until tender. Sauté spinach for 1 minute.',
      'Fry eggs sunny side up so the yolk stays golden and molten.',
      'Divide warm rice into bowls. Arrange seasoned vegetables, bean sprouts, and kimchi in distinct colorful segments.',
      'Top with sunny egg and a dollop of chili paste; mix thoroughly before eating!'
    ],
    swaps: [
      {
        id: 'swap-kb1',
        originalIngredient: 'Kimchi',
        swapIngredient: 'Atcharang Papaya (Filipino Pickled Papaya)',
        savingsPhpPerServing: 6,
        reason: 'Atchara offers a crisp, sweet-tart contrast that balances the egg yolk beautifully.',
        culinaryTip: 'Drain excess pickling liquid before arranging.'
      }
    ],
    beginnerTip: 'Cook each vegetable quickly in the same pan one after the other to minimize washing dishes!',
    commonMistakes: [
      'Overcooking the egg yolk; runny yolk acts as a natural creamy sauce when mixed into the rice.',
      'Letting bean sprouts sit in hot water too long which destroys their signature crunch.'
    ],
    servingSuggestions: 'Drizzle with 1 teaspoon toasted sesame oil and sprinkle with toasted sesame seeds.',
    storageAdvice: 'Keep cooked vegetables in separate compartments of a meal prep container for up to 4 days.',
    reheatingAdvice: 'Warm the rice and vegetables in the microwave, then fry a fresh sunny egg right before dining.'
  },
  {
    id: 'turkey-sweet-potato-skillet',
    title: 'Lean Turkey & Sweet Potato Breakfast Skillet',
    filipinoName: 'Turkey & Camote Skillet',
    description: 'Ground turkey or lean chicken minced with caramelized cubed sweet potatoes (camote), bell peppers, and fresh herbs.',
    cuisine: 'american',
    prepTimeMinutes: 15,
    cookTimeMinutes: 20,
    servings: 3,
    difficulty: 'Beginner',
    budgetTier: 'mid',
    fitnessGoals: ['build_muscle', 'calorie_deficit', 'general_healthy', 'high_protein', 'muscle_building', 'weight_management'],
    dietaryTags: ['High Protein', 'Gluten-Free', 'High Fiber'],
    calories: 360,
    proteinGrams: 35,
    carbsGrams: 34,
    fatGrams: 9,
    fiberGrams: 5,
    baseCostPhp: 92,
    imageEmoji: '🍠',
    hasRealPhoto: false, // Strict accuracy: Generic photo removed, displaying Photo unavailable
    accentColor: '#6B4024',
    ingredients: [
      { id: 'tp1', name: 'Lean ground turkey or chicken', category: 'meat_seafood', amountMetric: 400, unitMetric: 'g', amountCustomary: 14, unitCustomary: 'oz', estimatedCostPhp: 120 },
      { id: 'tp2', name: 'Sweet potato (Camote), peeled and diced small', category: 'produce', amountMetric: 300, unitMetric: 'g', amountCustomary: 10.5, unitCustomary: 'oz', estimatedCostPhp: 35 },
      { id: 'tp3', name: 'Bell pepper and yellow onion, diced', category: 'produce', amountMetric: 150, unitMetric: 'g', amountCustomary: 5, unitCustomary: 'oz', estimatedCostPhp: 35 },
      { id: 'tp4', name: 'Smoked paprika, garlic powder, black pepper', category: 'seasoning_oil', amountMetric: 10, unitMetric: 'g', amountCustomary: 1, unitCustomary: 'tbsp', estimatedCostPhp: 12 },
      { id: 'tp5', name: 'Olive oil', category: 'seasoning_oil', amountMetric: 10, unitMetric: 'ml', amountCustomary: 2, unitCustomary: 'tsp', estimatedCostPhp: 10 }
    ],
    instructions: [
      'In a wide skillet, heat oil over medium heat. Add diced sweet potatoes with 2 tablespoons of water. Cover and steam for 8 minutes until tender-crisp.',
      'Uncover, push potatoes to the side, and add ground turkey, onions, and bell peppers.',
      'Break up meat with a spatula and cook until browned (6 minutes).',
      'Season with smoked paprika, garlic powder, salt, and pepper. Toss sweet potatoes and turkey together until caramelized.',
      'Serve warm as a high-protein power breakfast or meal-prep staple.'
    ],
    swaps: [
      {
        id: 'swap-tp1',
        originalIngredient: 'Ground Turkey',
        swapIngredient: 'Lean Ground Pork or Chicken',
        savingsPhpPerServing: 20,
        reason: 'Ground chicken breast or 90% lean ground pork are readily available at lower prices.',
        culinaryTip: 'Drain any rendered liquid to keep sweet potatoes nicely caramelized.'
      }
    ],
    beginnerTip: 'Dicing sweet potatoes into small 1/2-inch cubes cuts cooking time down to under 10 minutes.',
    commonMistakes: [
      'Not covering the sweet potatoes at first; steaming them with 2 tbsp water speeds up cooking dramatically.',
      'Stirring constantly; let the sweet potatoes sit untouched for 2 minutes to get golden caramelization.'
    ],
    servingSuggestions: 'Top with a fried egg or sliced avocado and hot sauce.',
    storageAdvice: 'Refrigerates exceptionally well for up to 5 days; perfect for weekly breakfast meal prep.',
    reheatingAdvice: 'Reheat in a hot skillet for 3 minutes for crisp edges, or microwave for 90 seconds.'
  },
  {
    id: 'power-omad-feast-bowl',
    title: 'High-Protein OMAD Feast Bowl with Avocado & Eggs',
    filipinoName: 'OMAD Power Bowl',
    description: 'Designed specifically for One-Meal-A-Day schedules: high nutrient density, 64g protein, healthy fats from avocado and eggs, and complex carbs.',
    cuisine: 'other',
    prepTimeMinutes: 15,
    cookTimeMinutes: 20,
    servings: 1,
    difficulty: 'Intermediate',
    budgetTier: 'premium',
    fitnessGoals: ['omad', 'build_muscle', 'muscle_building', 'high_protein'],
    dietaryTags: ['High Protein', 'Gluten-Free', 'High Fiber'],
    calories: 920,
    proteinGrams: 64,
    carbsGrams: 72,
    fatGrams: 42,
    fiberGrams: 14,
    baseCostPhp: 195,
    imageEmoji: '🥑',
    hasRealPhoto: false, // Strict accuracy: Mismatched image removed, displaying Photo unavailable
    accentColor: '#344C33',
    ingredients: [
      { id: 'om1', name: 'Grilled chicken breast or beef strips', category: 'meat_seafood', amountMetric: 250, unitMetric: 'g', amountCustomary: 8.8, unitCustomary: 'oz', estimatedCostPhp: 85 },
      { id: 'om2', name: 'Eggs (poached or soft-boiled)', category: 'meat_seafood', amountMetric: 2, unitMetric: 'pc', amountCustomary: 2, unitCustomary: 'pc', estimatedCostPhp: 18 },
      { id: 'om3', name: 'Fresh avocado, sliced', category: 'produce', amountMetric: 0.5, unitMetric: 'pc', amountCustomary: 0.5, unitCustomary: 'pc', estimatedCostPhp: 35 },
      { id: 'om4', name: 'Steamed quinoa or brown rice', category: 'pantry_grains', amountMetric: 200, unitMetric: 'g', amountCustomary: 1.3, unitCustomary: 'cup', estimatedCostPhp: 30 },
      { id: 'om5', name: 'Sautéed mushrooms, spinach, and tomatoes', category: 'produce', amountMetric: 150, unitMetric: 'g', amountCustomary: 5, unitCustomary: 'oz', estimatedCostPhp: 30 },
      { id: 'om6', name: 'Pumpkin seeds or crushed walnuts', category: 'pantry_grains', amountMetric: 15, unitMetric: 'g', amountCustomary: 1, unitCustomary: 'tbsp', estimatedCostPhp: 15 }
    ],
    instructions: [
      'Sear seasoned chicken or beef strips in a hot skillet with 1 tsp olive oil until thoroughly cooked (6-8 minutes).',
      'In the same pan, quickly sauté sliced mushrooms and fresh spinach until wilted.',
      'Boil or poach eggs for 6 minutes for jammy yolks.',
      'Assemble in a large bowl: brown rice base, surrounded by grilled chicken, warm mushrooms, fresh spinach, sliced avocado, and halved eggs.',
      'Sprinkle with toasted pumpkin seeds and a splash of lemon juice.'
    ],
    swaps: [
      {
        id: 'swap-om1',
        originalIngredient: 'Avocado',
        swapIngredient: 'Hard-boiled egg yolk + 1 tsp Olive Oil / Peanut Butter',
        savingsPhpPerServing: 20,
        reason: 'When avocados are out of season, eggs and olive oil provide great lipid profiles.',
        culinaryTip: 'Drizzle 1 tsp olive oil over warm rice.'
      }
    ],
    beginnerTip: 'OMAD meals require balanced micronutrients and healthy fats so you stay comfortably satiated throughout your fasting window.',
    commonMistakes: [
      'Relying on empty carbs for the meal; keep the emphasis on complete protein, diverse vegetables, and quality fats.',
      'Eating too quickly; take 25-30 minutes to enjoy this substantial nutrient feast.'
    ],
    servingSuggestions: 'Pair with a large glass of water with lemon and a pinch of electrolyte salt.',
    storageAdvice: 'Cooked proteins and grains can be prepared in advance for up to 3 days; slice avocado right before serving.',
    reheatingAdvice: 'Warm chicken, grains, and sautéed greens before adding cool avocado slices and soft-boiled eggs.'
  },
  {
    id: 'overnight-chia-oat-bowl',
    title: 'Protein Overnight Chia & Oat Bowl with Banana',
    filipinoName: 'Overnight Oats at Saging',
    description: 'No-cook, high-fiber breakfast: rolled oats and chia seeds soaked in milk with peanut butter and sweet local banana slices.',
    cuisine: 'other',
    prepTimeMinutes: 5,
    cookTimeMinutes: 0,
    servings: 2,
    difficulty: 'Beginner',
    budgetTier: 'budget',
    fitnessGoals: ['calorie_deficit', 'new_to_balanced', 'general_healthy', 'weight_management', 'general_health', 'high_protein'],
    dietaryTags: ['High Fiber', 'Vegetarian', 'Quick & Easy', 'Budget Friendly'],
    calories: 310,
    proteinGrams: 16,
    carbsGrams: 45,
    fatGrams: 9,
    fiberGrams: 8,
    baseCostPhp: 34,
    imageEmoji: '🍌',
    hasRealPhoto: false, // Strict accuracy: Unverified photo removed, displaying Photo unavailable
    accentColor: '#6B5834',
    ingredients: [
      { id: 'oo1', name: 'Rolled oats', category: 'pantry_grains', amountMetric: 90, unitMetric: 'g', amountCustomary: 1, unitCustomary: 'cup', estimatedCostPhp: 20 },
      { id: 'oo2', name: 'Milk (dairy, soy, or almond)', category: 'dairy_alt', amountMetric: 250, unitMetric: 'ml', amountCustomary: 1, unitCustomary: 'cup', estimatedCostPhp: 25 },
      { id: 'oo3', name: 'Chia seeds or flaxseeds', category: 'pantry_grains', amountMetric: 15, unitMetric: 'g', amountCustomary: 1, unitCustomary: 'tbsp', estimatedCostPhp: 12 },
      { id: 'oo4', name: 'Natural peanut butter', category: 'pantry_grains', amountMetric: 20, unitMetric: 'g', amountCustomary: 1, unitCustomary: 'tbsp', estimatedCostPhp: 12 },
      { id: 'oo5', name: 'Ripe banana (Saba or Lakatan), sliced', category: 'produce', amountMetric: 1, unitMetric: 'pc', amountCustomary: 1, unitCustomary: 'pc', estimatedCostPhp: 8 }
    ],
    instructions: [
      'In a jar or container, mix rolled oats, chia seeds, peanut butter, and milk thoroughly.',
      'Cover with lid and refrigerate overnight (or at least 4 hours) to allow oats and chia seeds to soften into a pudding texture.',
      'In the morning, stir once. If too thick, splash 1 tablespoon of milk.',
      'Top with fresh sliced bananas and enjoy chilled.'
    ],
    swaps: [
      {
        id: 'swap-oo1',
        originalIngredient: 'Chia Seeds',
        swapIngredient: 'Extra Peanut Butter or Crushed Peanuts',
        savingsPhpPerServing: 5,
        reason: 'Local roasted peanuts offer great healthy fats and crunch at very low cost.',
        culinaryTip: 'Crush roasted peanuts right before serving for extra crunch.'
      }
    ],
    beginnerTip: 'Make 3 or 4 jars on Sunday night for an effortless grab-and-go weekday breakfast!',
    commonMistakes: [
      'Using steel-cut oats instead of rolled oats; steel-cut oats require cooking and will stay hard overnight.',
      'Adding banana slices before overnight storage; bananas brown quickly, so always add them fresh in the morning.'
    ],
    servingSuggestions: 'Sprinkle with ground cinnamon or unsweetened cocoa powder for a dessert-like finish.',
    storageAdvice: 'Keeps in sealed mason jars in the refrigerator for up to 5 days.',
    reheatingAdvice: 'Can be enjoyed cold right from the fridge or microwaved for 60 seconds if you prefer warm porridge.'
  }
];
