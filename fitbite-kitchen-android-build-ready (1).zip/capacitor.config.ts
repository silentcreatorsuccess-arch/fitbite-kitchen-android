import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.fitbite.kitchen',
  appName: 'FitBite Kitchen',
  webDir: 'dist',
  bundledWebRuntime: false
};

export default config;
